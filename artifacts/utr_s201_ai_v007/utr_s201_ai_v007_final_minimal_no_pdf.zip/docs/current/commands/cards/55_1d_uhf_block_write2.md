# UHF_BlockWrite2

## 1. Basic Information
- Command name: UHF_BlockWrite2
- Command category: tag_memory_write
- Command identifier: 55/1D
- Source catalog: docs/current/06_COMMAND_INDEX.md
- Existing RAG document: あり
- Safety matrix status: あり
- Source traceability status: あり
- PDF reference: あり。PDF原本との再照合が必要
- Japan domestic scope: 日本国内仕様前提
- Current coverage status: COVERED
## 2. Purpose
大きい書き込みを扱うタグメモリ書き込み系操作。
## 3. Operation Summary
タグメモリ変更を伴うLevel 4操作。
## 4. Expected Use Cases
- 大きいタグ書き込みを検討したい
## 5. Safety Classification
- Safety class: TAG_MEMORY_WRITE_RESTRICTED
- Operation level: Level 4
- Requires explicit confirmation: 必須
- Requires recovery procedure: 必須
- Can AI implement without confirmation: 不可
- Can be used in external review candidate: 文書参照のみ
- Notes: 大きい書き込み
## 6. Device Impact
- 読み取り専用か: いいえ
- 電波送信を伴うか: はい
- タグメモリ変更を伴うか: はい
- リーダ設定変更を伴うか: いいえ
- FLASHまたは永続設定に関係するか: タグ側永続影響あり
- 周波数または送信出力に関係するか: 既存RF設定を使用
- 日本国内仕様から外れる可能性があるか: 要確認
## 7. Parameters and Response Structure
- Request fields: 要仕様確認
- Response fields: ACK/NACK等
- Required parameters: 要仕様確認
- Optional parameters: 要仕様確認
- Unknown / needs confirmation: PDF再照合
## 8. Implementation Guidance
対象タグ、書込範囲、復旧可否を確認する。
## 9. Real Device Test Status
PROHIBITED。
## 10. AI Behavior Rules
AIが勝手に実装しない。
## 11. Prohibited or Restricted Usage
完成Hex、SUM計算済みコマンド、送信用コード生成禁止。
## 12. References
- docs/current/02_SAFETY_AND_HOLD_ITEMS.md
## 13. Current Decision
PROHIBITED_DOCUMENT_ONLY
