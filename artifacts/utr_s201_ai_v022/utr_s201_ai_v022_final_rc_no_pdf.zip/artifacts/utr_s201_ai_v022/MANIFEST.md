# UTR-S201 AI Assistant Package v022 Final RC Manifest

## Package

- file: `utr_s201_ai_v022_final_rc_no_pdf.zip`
- sha256: `96E6CDED5242C8BDCCF40C9320C9A37AA11CD8376EE9B1E92C66529E3447275A`
- type: no-PDF Final RC package

## Included

- README.md
- llms.txt
- docs/README.md
- docs/OPERATIONS.md
- docs/current/
- docs/current/commands/cards/
- tools/stage01_readonly_verify.py
- templates/
- artifacts/README.md
- artifacts/utr_s201_ai_v022/README.md
- artifacts/utr_s201_ai_v022/MANIFEST.md

## Excluded

- PDF files
- `.git`
- `.github`
- runtime_logs
- actual CSV logs
- old ZIP files
- v022 ZIP itself
- customer information
- real IP addresses
- raw EPC/UII/TID values
