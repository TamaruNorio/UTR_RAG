---
title: "55 41 UHF_GetInventoryParam"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "medium"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "not_antenna_specific"
command_name: "UHF_GetInventoryParam"
command_label: "55 41"
detail_command: "41h"
source_section: "7.4.3"
source_pages: "157-160"
operation_type: "read_inventory_parameter"
risk_level: "low"
safety_class: "read_setting_no_persistent_change"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_with_caution"
automatic_send_allowed: "true"
persistent_effect: "false"
requires_explicit_user_permission: "false"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_41_UHF_GetInventoryParam.md"
---

# 55 41 UHF_GetInventoryParam

## 用途
Inventoryパラメータの現在値を読み取るコマンドです。設定変更は行いません。

## AI向け注意
- 55 31 UHF_SetInventoryParam と混同しないでください。
- 読み取り対象がコマンドモード用、自動読み取りモード用、FLASHデータのどれかを明示してください。
- 読み取った値を根拠にコード生成する場合も、PDF正本でbit定義を再確認する扱いにします。

## 参照関係
- 対になる書き込み: 55 31 UHF_SetInventoryParam
- 影響先: 55 10 UHF_Inventory
- 構造化定義: 03_structured_data/uhf_inventory_param_bitfields.yml

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
