---
title: "55 33 02 周波数設定の書き込み"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "not_antenna_specific"
command_name: "WriteFrequencySetting"
command_label: "55 33 02"
detail_command: "33h/02h"
source_section: "7.4"
source_pages: "要PDF確認"
operation_type: "write_frequency_setting"
source_status: pdf_cross_checked
risk_level: "critical"
safety_class: "frequency_change_prohibited_without_explicit_permission"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "implementation_prohibited_by_default"
automatic_send_allowed: "false"
requires_actual_device_check: true
persistent_effect: "conditional"
requires_explicit_user_permission: "true"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_02_周波数設定の書き込み.md"
safety_profile_ref: "03_structured_data/command_safety_matrix.yml#commands.WRITE_FREQUENCY"
executable_hex_output: prohibited
checksum_policy: placeholder_only
response_mode_allowed: "high_risk_safety_output"
source_traceability_ref: "03_structured_data/source_traceability_matrix.yml#WRITE_FREQUENCY"
---
## R6 integration note

This chunk now references the central command safety matrix and source traceability matrix. If local metadata conflicts with the matrix, use the stricter safety profile.


# 55 33 02 周波数設定の書き込み

## 用途
周波数設定を書き込む高リスク操作です。

## AI向け停止条件
- 明示許可なしにコード生成、送信処理、自動送信を行いません。
- 電波法・地域設定・現場条件に影響するため、PDF正本と社内確認を前提にします。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
