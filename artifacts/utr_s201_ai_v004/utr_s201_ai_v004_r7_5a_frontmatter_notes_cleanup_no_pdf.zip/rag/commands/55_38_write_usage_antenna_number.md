---
title: "55 38 使用アンテナ番号の書き込み"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "external_8ch_or_unit_8ch"
command_name: "WriteUsageAntennaNumber"
command_label: "55 38"
detail_command: "38h"
source_section: "7.3"
source_pages: "要PDF確認"
operation_type: "write_usage_antenna_number_command_mode"
risk_level: "high"
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "derived command RAG; source original chunk carries section metadata; no R7-5A single source_traceability_matrix trace item"
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.WRITE_USAGE_ANTENNA_NUMBER
pdf_cross_checked: false
pdf_cross_checked_note: "not directly registered as a single R7-5A source trace item; section metadata preserved"
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
safety_class: "temporary_antenna_selection_requires_restore_plan"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_only_with_restore_guard"
automatic_send_allowed: "false"
persistent_effect: "false_if_command_mode_only"
requires_explicit_user_permission: "true"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_38_使用アンテナ番号の書き込み.md"
---

# 55 38 使用アンテナ番号の書き込み

## 用途
使用アンテナ番号を設定する機種依存コマンドです。

## AI向け停止条件
- 対象機種、ROMシリーズ、アンテナ構成が未確定なら実装しません。
- UTR-SUN02-8CH / USM08 の ANT1=00h, ANT2=20h... の体系を、UTR-SUN02V-8CH / USM06 へ流用しません。
- 実装する場合は、開始前の使用アンテナ番号読み取り、異常終了時の復元、受信バッファクリア、復元失敗時の警告を必須にします。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
