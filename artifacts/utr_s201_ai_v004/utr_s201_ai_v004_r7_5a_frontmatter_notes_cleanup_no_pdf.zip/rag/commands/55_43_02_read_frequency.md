---
title: "55 43 02 周波数設定の読み取り"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "medium"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "not_antenna_specific"
command_name: "ReadFrequencySetting"
command_label: "55 43 02"
detail_command: "43h/02h"
source_section: "7.4"
source_pages: "要PDF確認"
operation_type: "read_frequency_setting"
risk_level: "low"
safety_class: "read_setting_no_persistent_change"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_with_caution"
automatic_send_allowed: "true"
persistent_effect: "false"
requires_explicit_user_permission: "false"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_02_周波数設定の読み取り.md"
---

# 55 43 02 周波数設定の読み取り

## 用途
周波数設定の現在値を読み取ります。

## AI向け注意
- 読み取りと書き込みを混同しません。
- 周波数設定は電波法・地域条件に関係するため、読み取り結果の解釈でもPDF正本を優先します。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
