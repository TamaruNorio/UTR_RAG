---
title: "55 33 01 出力設定の書き込み"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "not_antenna_specific"
command_name: "WriteOutputPowerSetting"
command_label: "55 33 01"
detail_command: "33h/01h"
source_section: "7.4"
source_pages: "要PDF確認"
operation_type: "write_output_power_setting"
source_status: pdf_cross_checked
risk_level: "critical"
safety_class: "output_power_change_requires_explicit_permission"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "implementation_prohibited_by_default"
automatic_send_allowed: "false"
requires_actual_device_check: true
persistent_effect: "conditional"
requires_explicit_user_permission: "true"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_01_出力設定の書き込み.md"
safety_profile_ref: "03_structured_data/command_safety_matrix.yml#commands.WRITE_OUTPUT_POWER"
executable_hex_output: prohibited
checksum_policy: placeholder_only
response_mode_allowed: "high_risk_safety_output"
source_traceability_ref: "03_structured_data/source_traceability_matrix.yml#WRITE_OUTPUT_POWER"
---
## R6 integration note

This chunk now references the central command safety matrix and source traceability matrix. If local metadata conflicts with the matrix, use the stricter safety profile.


# 55 33 01 出力設定の書き込み

## 用途
送信出力設定を書き込む高リスク操作です。

## AI向け停止条件
- 明示許可なしに実装しません。
- FLASH向け書き込みは許可しません。
- 実装する場合は、変更前読み取り、復元計画、finally復元、復元後読み戻し、実機確認手順を必須にします。

## GitHub USB版での扱い
UTR-SUN02-4CH / USM02 に限定し、コマンドモード用パラメータのみの一時変更として扱います。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
