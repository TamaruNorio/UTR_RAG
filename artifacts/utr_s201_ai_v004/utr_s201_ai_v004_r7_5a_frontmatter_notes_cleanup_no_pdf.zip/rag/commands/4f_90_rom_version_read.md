---
title: "4F 90 ROMバージョンの読み取り"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "medium"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "model_identification"
command_name: "ROM_VERSION_CHECK"
command_label: "4F 90"
detail_command: "90h"
source_section: "7.3"
source_pages: "要PDF確認"
operation_type: "read_rom_version"
risk_level: "low"
safety_class: "read_model_identity"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_with_caution"
automatic_send_allowed: "true"
persistent_effect: "false"
requires_explicit_user_permission: "false"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_90_ROMバージョンの読み取り.md"
---

# 4F 90 ROMバージョンの読み取り

## 用途
ROMバージョンとROMシリーズ名を読み取り、対象機種スコープを確定するための基本コマンドです。

## AI向け注意
- ROMシリーズ名から機種を推測で拡張しません。対応表にない場合は unknown とします。
- UTR-S201とUTR-S202の差分が不明な場合は同一扱いしません。
- 機種依存コマンドの前に、対象機種・ROMシリーズ・アンテナ構成を確認します。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
