---
title: "55 44 UHF_CheckAntenna"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "model_dependent"
command_name: "UHF_CheckAntenna"
command_label: "55 44"
detail_command: "44h"
source_section: "7.3"
source_pages: "要PDF確認"
operation_type: "read_antenna_connection_status"
risk_level: "medium"
safety_class: "antenna_model_dependent_read_check"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_with_model_scope"
automatic_send_allowed: "true"
persistent_effect: "false"
requires_explicit_user_permission: "false"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_44_UHF_CheckAntenna.md"
---

# 55 44 UHF_CheckAntenna

## 用途
アンテナ接続状態を確認する読み取り系コマンドです。

## AI向け注意
- UHF_CheckAntennaのアンテナ番号と、使用アンテナ番号の体系を混同しません。
- 4CHでは 00h-03h、8CHでは 00h-07h を確認対象として扱う可能性がありますが、対象機種とROMシリーズで確認します。
- 接続OKアンテナだけを候補にする実装は可能ですが、機種が未確定ならアンテナ制御コードは生成しません。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
