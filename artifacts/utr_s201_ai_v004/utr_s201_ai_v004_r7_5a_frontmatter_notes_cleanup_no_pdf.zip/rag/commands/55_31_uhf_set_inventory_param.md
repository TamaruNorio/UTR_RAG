---
title: "55 31 UHF_SetInventoryParam"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "not_antenna_specific"
command_name: "UHF_SetInventoryParam"
command_label: "55 31"
detail_command: "31h"
source_section: "7.4.18"
source_pages: "197-204"
operation_type: "write_inventory_parameter"
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_SET_INVENTORY_PARAM
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_SET_INVENTORY_PARAM
executable_hex_output: prohibited
checksum_policy: placeholder_only
risk_level: "high"
safety_class: "write_inventory_parameter_requires_permission"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "explanation_only_by_default"
automatic_send_allowed: "false"
requires_actual_device_check: true
persistent_effect: "conditional"
requires_explicit_user_permission: "true"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_31_UHF_SetInventoryParam.md"
---

# 55 31 UHF_SetInventoryParam

## 用途
Inventoryパラメータを書き込む高リスクコマンドです。

## AI向け停止条件
- 明示許可なしにコード生成、送信処理、自動送信を行いません。
- パラメータ種類 02h はFLASHデータに関係するため、永続変更リスクとして扱います。
- UTR-S201とUTR-S202、4CH、8CHで安全に同一視できると推測しません。

## 安全な既定動作
読み取り値の説明、bit定義の確認、影響範囲の説明までに留めます。実装が必要な場合は、対象機種、ROMシリーズ、インターフェース、アンテナ構成、変更値、復元方法、実機確認手順を固定します。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
