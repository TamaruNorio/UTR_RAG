---
title: "RAG command README"
category: "readme"
chunk_type: "readme"
rag_priority: "skip"
search_target: false
operation_type: "readme"
target_models:
- UTR-S201
- UTR-S202
- UTR-SHR201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
---
# RAG commands

このフォルダは、RAG登録時に検索しやすいよう、主要コマンドを `1ファイル = 1コマンド` に近い単位で再分割した補助チャンクです。

- PDF正本を置き換えません。
- 既存の章構成ファイルは残し、ここでは検索用の薄い入口を提供します。
- 機種依存・高リスク操作は front matter の `risk_level`、`target_models`、`antenna_profile`、`automatic_send_allowed` を必ず確認します。
