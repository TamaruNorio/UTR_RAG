---
title: "55 43 01 出力設定の読み取り"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "medium"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "not_antenna_specific"
command_name: "ReadOutputPowerSetting"
command_label: "55 43 01"
detail_command: "43h/01h"
source_section: "7.4"
source_pages: "要PDF確認"
operation_type: "read_output_power_setting"
risk_level: "low"
safety_class: "read_setting_no_persistent_change"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_with_caution"
automatic_send_allowed: "true"
persistent_effect: "false"
requires_explicit_user_permission: "false"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_01_出力設定の読み取り.md"
---

# 55 43 01 出力設定の読み取り

## 用途
送信出力設定などの現在値を読み取ります。設定変更は行いません。

## AI向け注意
- 読み取り結果の説明は可能です。
- 55 33 01 出力設定の書き込みとは明確に分けます。
- GitHub USB版では、送信出力一時変更前後の確認に利用されています。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
