---
title: "55 48 使用アンテナ番号の読み取り"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "medium"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "external_8ch_or_unit_8ch"
command_name: "ReadUsageAntennaNumber"
command_label: "55 48"
detail_command: "48h"
source_section: "7.3"
source_pages: "要PDF確認"
operation_type: "read_usage_antenna_number"
risk_level: "low"
safety_class: "read_usage_antenna_no_persistent_change"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_with_model_scope"
automatic_send_allowed: "true"
persistent_effect: "false"
requires_explicit_user_permission: "false"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_48_使用アンテナ番号の読み取り.md"
---

# 55 48 使用アンテナ番号の読み取り

## 用途
現在選択されている使用アンテナ番号を読み取ります。8CH順次Inventoryでは、終了時に元へ戻すための事前読み取りとして重要です。

## AI向け注意
- UTR-SUN02-8CH / USM08 と UTR-SUN02V-8CH / USM06 を同一視しません。
- 読み取った内部アンテナ番号・外部アンテナ番号を保持し、復元時は開始前の値へ戻します。
- 値の意味はPDF正本と対象機種スコープで確認します。

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
