---
title: "55 10 UHF_Inventory"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "medium"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: "possible"
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "model_dependent"
command_name: "UHF_Inventory"
command_label: "55 10"
detail_command: "10h"
source_section: "7.5.1"
source_pages: "262-265"
operation_type: "read_inventory"
risk_level: "low"
safety_class: "read_inventory_no_persistent_change"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "allowed_with_caution"
automatic_send_allowed: "true"
persistent_effect: "false"
requires_explicit_user_permission: "false"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
source_original_chunk: "rag/07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_10_UHF_Inventory.md"
---

# 55 10 UHF_Inventory

## 用途
RFタグをInventoryし、PC+UII / PC+EPC、RSSI、読み取りチャンネルなどを取得するための読み取り系コマンドです。

## AI向け注意
- 読み取り系ですが、事前のInventoryパラメータ、Selectパラメータ、アンテナ設定により挙動が変わります。
- UTR-S201とUTR-S202を同一仕様と仮定して、機種依存の応答差分を補完しないでください。
- PC+UII / PC+EPC は実タグIDを含む可能性があるため、公開ログやGitHubにはマスクして記載します。

## 参照関係
- 関連読み取り: 55 41 UHF_GetInventoryParam
- 挙動に影響: 55 31 UHF_SetInventoryParam、55 30 UHF_SetSelectParam
- 実装例: GitHub USB版の標準Inventoryフロー

## 不明時の扱い
PDF正本または構造化データに根拠がない場合は、推測せず「要PDF確認」「実機確認が必要」と回答します。
