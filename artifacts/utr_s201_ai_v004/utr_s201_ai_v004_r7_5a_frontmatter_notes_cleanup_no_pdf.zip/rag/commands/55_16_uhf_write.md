---
title: "55 16 UHF_Write"
category: "command_rag"
chunk_type: "command_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
rom_series: "model_dependent"
rom_dependency:
  has_rom_dependency: true
  confirmed_versions: []
  requires_pdf_confirmation: true
  future_version_policy: "do_not_assume_supported"
  unknown_version_action: "explain_only_do_not_implement"
interface: "USB_or_LAN_frame_common_connection_differs"
antenna_profile: "model_dependent"
command_name: "UHF_Write"
command_label: "55 16"
source_section: "要PDF確認"
source_pages: "要PDF確認"
operation_type: "uhf_tag_write"
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_WRITE
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_WRITE
executable_hex_output: prohibited
checksum_policy: placeholder_only
risk_level: "critical"
safety_class: "tag_write_requires_explicit_permission"
model_specific: "true"
cross_model_reuse: "prohibited"
ai_code_generation: "implementation_prohibited_by_default"
automatic_send_allowed: "false"
requires_actual_device_check: true
requires_explicit_user_permission: "true"
requires_pdf_confirmation: "true"
requires_single_tag_assumption: "true"
multi_tag_environment_risk: "collision"
source_of_truth: "PDF正本"
markdown_is_authoritative: "false"
---

# 55 16 UHF_Write

## 用途

RFタグのメモリへデータを書き込む高リスク操作です。

## 安全ガード

明示許可なしに実装しません。完成Hex、SUM計算済みフレーム、自動送信コード、Codex実装依頼文を生成しません。

複数タグ混在環境では、Select等の前提確認なしに直接Write実装を提案しません。

## 不明時の扱い

対象タグ、メモリバンク、アドレス、パスワード、単一タグ前提、ROMバージョンが未確定の場合は、実装せず説明と確認手順に留めます。
