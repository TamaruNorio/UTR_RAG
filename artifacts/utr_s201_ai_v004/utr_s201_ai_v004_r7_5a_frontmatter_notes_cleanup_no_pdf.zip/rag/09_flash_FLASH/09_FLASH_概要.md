---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 09_FLASH_概要
topic: 章概要
chapter: '9'
source_section: 第9章
source_pages: '342'
category: 章概要
chunk_type: chapter_overview
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- FLASH
- FLASH_
- ROM
- AI
- RF
- RAG
- RAM
- リーダライタ
- RFタグ
- アンテナ
- キャリアセンス
- ROMバージョン
- 設定保存
- FLASH設定値
- 電源再投入
- 初期化
- アンテナ番号
- アンテナ自動切替
- 断線確認
- UHF_CheckAntenna
- ファームウェア
- USM01
- USM02
- USM05
- USM06
- USM08
- リスタート
- 再起動
- 2秒待機
- FLASH読込
- UHFタグ
- タグ
- Reader Writer
- RW
- コマンド
- command
- frame
aliases:
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- FLASH
- FLASH_
- FLASH設定値
- UHF_CheckAntenna
- FLASH読込
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 09_FLASH/公開_UTR版_第9章_FLASH_概要.md
optimized_path: 09_flash_FLASH/09_FLASH_概要.md
chapter_title: FLASH
rag_ready: true
---
    # 第9章 FLASH

    ## この章の要約

    FLASHのアドレス一覧を記載した章です。FLASH設定値変更後はリーダライタをリスタートする必要があります。

    ## 何に使う章か

    FLASH設定値を読み書きする際に、アドレス、bit、初期値、ROMバージョン条件を確認するために使います。

    ## この章の構成

    - 9.1 FLASHアドレス一覧

    ## 生成AI回答時の注意

    - 本章は実用手順・設定表・参考値を扱います。コマンド仕様の厳密なバイト定義は第7章の該当コマンドも併せて確認してください。
    - 数値例や実測値は、実環境での動作保証値ではありません。対象RFタグ、設置環境、アンテナ、出力、周囲ノイズで変わります。
    - 書き込み、ロック、FLASH変更、複数リーダライタ運用では、検証環境で確認してから本番適用する前提で回答してください。

    ## RAG検索キーワード

    ```text
    FLASH アドレス 初期値 リスタート RAM 1バイトアクセス タイムアウト キャリアセンス 汎用ポート 拡張ポート
    ```

    ## 公式仕様抜粋

    ```text
    341 

第9章 FLASH 

本章では、FLASH のアドレス一覧を記載しています。 
FLASH の設定値変更後は、リーダライタをリスタートする必要があります。
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / FLASH / FLASH_ / ROM / AI / RF / RAG / RAM / リーダライタ / RFタグ / アンテナ / キャリアセンス / ROMバージョン / 設定保存 / FLASH設定値 / 電源再投入 / 初期化 / アンテナ番号 / アンテナ自動切替 / 断線確認 / UHF_CheckAntenna / ファームウェア / USM01 / USM02 / USM05 / USM06 / USM08 / リスタート / 再起動 / 2秒待機 / FLASH読込 / UHFタグ / タグ / Reader Writer / RW / コマンド / command / frame
