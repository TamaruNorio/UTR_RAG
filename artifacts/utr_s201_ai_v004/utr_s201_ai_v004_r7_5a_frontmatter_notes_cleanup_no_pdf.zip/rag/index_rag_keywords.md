---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
title: RAG検索キーワード索引
chunk_type: keyword_index
rag_priority: high
keywords:
- UTR
- RAG
- 検索キーワード
- キーワード索引
- 同義語
- コマンド検索
---
# RAG検索キーワード索引

C工程で各MarkdownのYAML front matterへ付与したキーワードを、逆引きできるように整理した索引です。

## 0
- **00H**: `00_common_knowledge_共通知識/05_SUM計算方法.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`
- **01H**: `00_common_knowledge_共通知識/05_SUM計算方法.md`
- **02H**: `00_common_knowledge_共通知識/05_SUM計算方法.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`
- **03H**: `05_frame_format_通信フォーマット/05_通信フォーマット.md`
- **0DH**: `05_frame_format_通信フォーマット/05_通信フォーマット.md`
## 1
- **1CH**: `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **1EH**: `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
## 2
- **20H**: `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **21H**: `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **22H**: `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **24H**: `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **25H**: `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **28H**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
## 4
- **41H**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- **4CH**: `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`, `99_change_history_変更履歴/99_変更履歴.md`
- **4FH**: `00_common_knowledge_共通知識/05_SUM計算方法.md`
## 6
- **60H**: `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`
## 7
- **76H**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
## 8
- **8AH**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- **8CH**: `99_change_history_変更履歴/99_変更履歴.md`
## A
- **AB**: `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md`, `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md`, `08_rf_tag_control_RFタグ制御方法/8.7_RFタグのメモリロックを解除する.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.2_各種コマンドの実行時間.md`
- **ACK**: `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `00_index.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md` ほか48件
- **ACK_NACK**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_index.md`
- **AFI**: `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`
- **AI**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md` ほか62件
- **ALN**: `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **ANGLE**: `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`
- **ANT1**: `00_common_knowledge_共通知識/11_アンテナ番号.md`
- **ANT2**: `00_common_knowledge_共通知識/11_アンテナ番号.md`
- **ANT3**: `00_common_knowledge_共通知識/11_アンテナ番号.md`
- **ANT4**: `00_common_knowledge_共通知識/11_アンテナ番号.md`
- **ANT5**: `00_common_knowledge_共通知識/11_アンテナ番号.md`
- **ANT6**: `00_common_knowledge_共通知識/11_アンテナ番号.md`
- **ANT7**: `00_common_knowledge_共通知識/11_アンテナ番号.md`
- **API**: `01_interface_通信インターフェース/01_通信インターフェース.md`
## B
- **BD**: `08_rf_tag_control_RFタグ制御方法/8.4_RFタグにデータを書き込む.md`
- **BF**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- **BFh**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- **BFH**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
## C
- **CD**: `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md`, `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md`, `08_rf_tag_control_RFタグ制御方法/8.7_RFタグのメモリロックを解除する.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.2_各種コマンドの実行時間.md`
- **CE**: `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md`
- **CH**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `00_common_knowledge_共通知識/11_アンテナ番号.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_47_外部アンテナ自動切替設定の読み取り.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md` ほか1件
- **CMD_CRC_ERROR**: `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`
- **CMD_LBT_ERROR**: `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`
- **CMD_RX_ERROR**: `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`
- **CMD_TIME_OVER**: `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`
- **CMOS**: `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **COM**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **command**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- **CPU**: `01_interface_通信インターフェース/01_通信インターフェース.md`
- **CR**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_00_リーダライタ動作モードの読み取り.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_9F_汎用ポート値の読み取り.md` ほか5件
- **CRC**: `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`, `08_rf_tag_control_RFタグ制御方法/8.2_RFタグのデータをコマンド制御で読み取る.md`, `08_rf_tag_control_RFタグ制御方法/8.4_RFタグにデータを書き込む.md`
## D
- **D8H**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- **dBm**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- **DOWN**: `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`
## E
- **E710ではない**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか67件
- **EC**: `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_90_チップバージョンの読み取り.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **ED**: `08_rf_tag_control_RFタグ制御方法/8.4_RFタグにデータを書き込む.md`
- **EPC**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md` ほか18件
- **EPCglobal**: `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`
- **EPCglobal Class1 Generation2**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **ETX**: `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md` ほか47件
## F
- **FD**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- **FD76**: `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- **FE**: `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `08_rf_tag_control_RFタグ制御方法/8.2_RFタグのデータをコマンド制御で読み取る.md`
- **FF**: `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`
- **FF12**: `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`
- **FF_UHF_ThroughCmd**: `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`
- **FFh**: `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`
- **FFH**: `05_frame_format_通信フォーマット/05_通信フォーマット.md`
- **FLASH**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `00_index.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md` ほか34件
- **FLASH_**: `09_flash_FLASH/09_FLASH_概要.md`
- **FLASH設定値**: `09_flash_FLASH/09_FLASH_概要.md`, `10_reference_参考資料/10_参考資料_概要.md`
- **frame**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
## G
- **GT**: `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
## I
- **ID**: `00_common_knowledge_共通知識/04_通信フォーマット.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_UHF連続インベントリモード.md`, `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **IEC**: `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`
- **IF**: `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`
- **Inventoried**: `10_reference_参考資料/10_参考資料_概要.md`
- **Inventory**: `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`
- **IP**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **ISO**: `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`
- **ISO18000**: `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`, `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`
- **ISO18000-63**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
## L
- **LAN**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **LED**: `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`, `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **Lock**: `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`
## M
- **MNL**: `00_index.md`, `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_UHF連続インベントリモード.md`, `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_UHF連続インベントリリードモード.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9E_RF送信信号の制御.md` ほか51件
- **MS710**: `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`
- **MS710ではない**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか67件
- **MSB**: `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_15_UHF_Read.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1A_UHF_BlockWrite.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1B_UHF_BlockErase.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1D_UHF_BlockWrite2.md`
- **mW**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
## N
- **NACK**: `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `00_index.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md` ほか53件
## O
- **OFF**: `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md`, `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`, `08_rf_tag_control_RFタグ制御方法/8.8_複数のリーダライタを同じ周波数で動作させる.md`, `09_flash_FLASH/9.1_FLASHアドレス一覧.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **ON**: `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`, `08_rf_tag_control_RFタグ制御方法/8.8_複数のリーダライタを同じ周波数で動作させる.md`, `09_flash_FLASH/9.1_FLASHアドレス一覧.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
## P
- **PC**: `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`, `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_UHF連続インベントリモード.md` ほか4件
- **PDF**: `00_index.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9E_RF送信信号の制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_80_エラー情報の読み取り.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_90_ROMバージョンの読み取り.md` ほか28件
- **PLC**: `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **PRC**: `00_index.md`, `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_UHF連続インベントリモード.md`, `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_UHF連続インベントリリードモード.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9E_RF送信信号の制御.md` ほか50件
## Q
- **QT**: `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **Q値**: `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`, `10_reference_参考資料/10_参考資料_概要.md`
## R
- **R2000**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **RAG**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md` ほか49件
- **RAM**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_index.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_38_使用アンテナ番号の書き込み.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_00-10_リーダライタ動作モードの書き込み.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_9F_汎用ポート値の書き込み.md` ほか25件
- **Reader Writer**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- **README**: `README.md`
- **RF**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/11_アンテナ番号.md`, `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md` ほか42件
- **RFID**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **RFU**: `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`
- **RFタグ**: `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`, `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`, `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md`, `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md`, `08_rf_tag_control_RFタグ制御方法/8.7_RFタグのメモリロックを解除する.md` ほか4件
- **ROM**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_90_ROMバージョンの読み取り.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_4A_アンテナ個別送信出力設定の読み取り.md` ほか11件
- **ROMバージョン**: `09_flash_FLASH/09_FLASH_概要.md`
- **RS**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **RSSI**: `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_39_RSSIフィルタ設定の書き込み.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_49_RSSIフィルタ設定の読み取り.md`, `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`, `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`, `10_reference_参考資料/10_参考資料_概要.md` ほか1件
- **RSSI_ANGLE**: `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`
- **RTF**: `02_operation_modes_動作モード/02_リーダライタの動作モード.md`
- **RW**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- **RX**: `10_reference_参考資料/10.2_reference_measurements/10.2.2_各種コマンドの実行時間.md`
## S
- **SHR201**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/11_アンテナ番号.md`, `99_change_history_変更履歴/99_変更履歴.md`
- **SL**: `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`, `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **STX**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md` ほか49件
- **SUM**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_index.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`, `05_frame_format_通信フォーマット/05_通信フォーマット.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md` ほか59件
- **SUM_ERROR**: `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`
- **SUN02**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `00_common_knowledge_共通知識/11_アンテナ番号.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`, `99_change_history_変更履歴/99_変更履歴.md`
- **SUN02V**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/11_アンテナ番号.md`, `99_change_history_変更履歴/99_変更履歴.md`
## T
- **TA2**: `08_rf_tag_control_RFタグ制御方法/8.8_複数のリーダライタを同じ周波数で動作させる.md`
- **Target**: `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`
- **TB2**: `08_rf_tag_control_RFタグ制御方法/8.8_複数のリーダライタを同じ周波数で動作させる.md`
- **TCP**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **TDR**: `00_index.md`, `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_UHF連続インベントリモード.md`, `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_UHF連続インベントリリードモード.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9E_RF送信信号の制御.md` ほか51件
- **TDR-MNL-PRC-UTR-S201-117**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **TID**: `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`, `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_UHF連続インベントリリードモード.md` ほか3件
- **TR3XMではない**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか67件
- **TX**: `10_reference_参考資料/10.2_reference_measurements/10.2.2_各種コマンドの実行時間.md`
## U
- **UA1709**: `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`
- **UCODE**: `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **UCODE7**: `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **UCODE8**: `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **UCODE9**: `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- **UHF**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UHF_BlockErase**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1B_UHF_BlockErase.md`
- **UHF_BlockWrite**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_18_UHF_Lock.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1A_UHF_BlockWrite.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1B_UHF_BlockErase.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1D_UHF_BlockWrite2.md` ほか4件
- **UHF_BlockWrite2**: `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1D_UHF_BlockWrite2.md`, `07_command_format_コマンドフォーマット/7.6_nack_error_codes/7.6_NACKレスポンスとエラーコード.md`, `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- **UHF_CheckAntenna**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_44_UHF_CheckAntenna.md`
- **UHF_Encode**: `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1A_UHF_BlockWrite.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1B_UHF_BlockErase.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1E_UHF_Encode.md` ほか2件
- **UHF_GetExpandSelectParam**: `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_42_UHF_GetExpandSelectParam.md`
- **UHF_GetHandle**: `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_46_UHF_GetHandle.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`, `99_change_history_変更履歴/99_変更履歴.md`
- **UHF_GetInventoryParam**: `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_41_UHF_GetInventoryParam.md`
- **UHF_GetSelectParam**: `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_40_UHF_GetSelectParam.md`
- **UHF_IC**: `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `07_command_format_コマンドフォーマット/7.6_nack_error_codes/7.6_NACKレスポンスとエラーコード.md`
- **UHF_Inventory**: `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `00_index.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_80_エラー情報の読み取り.md` ほか10件
- **UHF_InventoryRead**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_00_アンテナ切替設定の書き込み.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_04_RFタグ通信関連パラメータの書き込み.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_05_EPC(UII)関連パラメータの書き込み.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_39_RSSIフィルタ設定の書き込み.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_49_RSSIフィルタ設定の読み取り.md` ほか5件
- **UHF_Kill**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md`
- **UHF_Lock**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_18_UHF_Lock.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1E_UHF_Encode.md`, `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`, `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md` ほか2件
- **UHF_Read**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `00_index.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_15_UHF_Read.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md`, `08_rf_tag_control_RFタグ制御方法/8.2_RFタグのデータをコマンド制御で読み取る.md` ほか1件
- **UHF_SetExpandSelectParam**: `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_32_UHF_SetExpandSelectParam.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_42_UHF_GetExpandSelectParam.md`
- **UHF_SetInventoryParam**: `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_UHF連続インベントリリードモード.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_30_UHF_SetSelectParam.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_31_UHF_SetInventoryParam.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_10_UHF_Inventory.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_14_UHF_InventoryRead.md`, `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md`
- **UHF_SetSelectParam**: `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_30_UHF_SetSelectParam.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_32_UHF_SetExpandSelectParam.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_40_UHF_GetSelectParam.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_10_UHF_Inventory.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_14_UHF_InventoryRead.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_15_UHF_Read.md`
- **UHF_ThroughCmd**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_46_UHF_GetHandle.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`, `99_change_history_変更履歴/99_変更履歴.md`
- **UHF_Write**: `00_common_knowledge_共通知識/07_コマンド逆引き.md`, `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `00_index.md`, `06_command_list_対応表/06_コマンド一覧_対応表.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md`, `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_18_UHF_Lock.md` ほか2件
- **UHF_WriteBlock**: `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md`
- **UII**: `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`, `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_UHF連続インベントリモード.md`, `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_UHF連続インベントリリードモード.md`, `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_05_EPC(UII)関連パラメータの書き込み.md` ほか9件
- **UMI**: `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`
- **UP**: `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`
- **URL**: `99_change_history_変更履歴/99_変更履歴.md`
- **USB**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`, `01_interface_通信インターフェース/01_通信インターフェース.md`
- **UTF**: `README.md`
- **UTR**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UTR-S201**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UTR-S201シリーズ**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UTR-SHR201**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UTR-SUN02-4CH**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UTR-SUN02-8CH**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UTR-SUN02V-8CH**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
- **UTR_S201_protocol_md_RAG**: `README.md`
- **UTRRWManager**: `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.2_各種コマンドの実行時間.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`, `10_reference_参考資料/10_参考資料_概要.md`
- **UTRX**: `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`, `00_index.md`
- **UTRXではない**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか67件
## V
- **Ver.1.17**: `00_common_knowledge_共通知識/00_index.md`, `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`, `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`, `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/04_通信フォーマット.md`, `00_common_knowledge_共通知識/05_SUM計算方法.md`, `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`, `00_common_knowledge_共通知識/07_コマンド逆引き.md` ほか92件
## X
- **XI**: `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`, `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md`
- **XPC**: `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`
## ア
- **アンテナ**: `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`, `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`, `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md`, `08_rf_tag_control_RFタグ制御方法/8.7_RFタグのメモリロックを解除する.md`, `09_flash_FLASH/09_FLASH_概要.md`, `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md` ほか2件
- **アンテナ番号**: `99_change_history_変更履歴/99_変更履歴.md`
- **アンテナ自動切替**: `99_change_history_変更履歴/99_変更履歴.md`
## キ
- **キャリア**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- **キャリアセンス**: `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`, `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`, `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md`, `09_flash_FLASH/09_FLASH_概要.md`
## コ
- **コマンド**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- **コマンドモード**: `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`
## パ
- **パスワード**: `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`
## メ
- **メモリロック**: `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`
## リ
- **リーダライタ**: `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`, `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`, `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md`, `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md` ほか6件
## 出
- **出力設定**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
## 初
- **初期化**: `09_flash_FLASH/09_FLASH_概要.md`
## 動
- **動作モード**: `00_common_knowledge_共通知識/03_動作モード.md`, `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`
## 周
- **周波数**: `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`
## 自
- **自動読み取りモード**: `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `02_operation_modes_動作モード/02_リーダライタの動作モード.md`, `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md`, `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md`, `08_rf_tag_control_RFタグ制御方法/8.8_複数のリーダライタを同じ周波数で動作させる.md`
## 設
- **設定保存**: `09_flash_FLASH/09_FLASH_概要.md`, `10_reference_参考資料/10_参考資料_概要.md`
## 送
- **送信出力**: `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`, `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`, `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`, `10_reference_参考資料/10_参考資料_概要.md`
## 電
- **電波法**: `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- **電源再投入**: `09_flash_FLASH/09_FLASH_概要.md`, `10_reference_参考資料/10_参考資料_概要.md`

## RAG検索キーワード（最適化）

UTR / UTR-S201 / R2000 / RAG / 検索キーワード / キーワード索引 / 同義語 / コマンド検索

