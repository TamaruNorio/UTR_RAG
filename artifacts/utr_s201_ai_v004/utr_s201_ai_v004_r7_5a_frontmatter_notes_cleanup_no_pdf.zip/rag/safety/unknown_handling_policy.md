---
title: "不明時の回答ポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
risk_level: "medium"
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "policy_controls_generation"
automatic_send_allowed: "false"
cross_model_reuse: "prohibited"
target_models:
- UTR-S201
- UTR-S202
- UTR-SHR201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
operation_type: unknown_handling_policy
applies_to_all_target_models: true
model_scope_required: false
future_version_policy: "do_not_assume_compatible"
requires_pdf_confirmation: "true"
---

# 不明時の回答ポリシー

AIは、PDF正本、構造化データ、実装例に根拠がない情報を補完しません。

## AIの既定動作
- 「不明」「PDF正本で要確認」「実機確認が必要」と明示します。
- TR3、UTR、LTR、UTR-S201、UTR-S202、4CH、8CH の仕様を推測で横展開しません。
- GitHub実装例とPDF正本が食い違う場合は、PDF正本を優先し、GitHub側を要確認にします。
