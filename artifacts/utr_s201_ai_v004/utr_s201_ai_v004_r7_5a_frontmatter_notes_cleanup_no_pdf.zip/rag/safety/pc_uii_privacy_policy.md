---
title: "PC+UII/EPCプライバシーポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
risk_level: "medium"
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "policy_controls_generation"
automatic_send_allowed: "false"
cross_model_reuse: "prohibited"
target_models:
- UTR-S201
- UTR-S202
- UTR-SHR201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
operation_type: privacy_policy
applies_to_all_target_models: true
model_scope_required: false
future_version_policy: "do_not_assume_compatible"
requires_pdf_confirmation: "true"
---

# PC+UII / PC+EPC プライバシーポリシー

PC+UII / PC+EPC は実タグIDを含む可能性があります。

## AIの既定動作
- GitHub、Issue、PR、公開ログへ実値を載せません。
- サンプル値はマスク値または架空値にします。
- 実機ログを共有する場合は MASKED_PC_UII_001 のような仮名IDを使います。
