---
title: "SUM計算・完成Hexフレームポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
operation_type: "checksum_policy"
risk_level: "medium"
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "explanation_only"
automatic_send_allowed: "false"
requires_explicit_user_permission: "false"
requires_pdf_confirmation: "true"
future_version_policy: "do_not_assume_compatible"
unknown_version_action: "require_verified_recalculation"
---

# SUM計算・完成Hexフレームポリシー

AIはSUM計算を誤る可能性があります。実機送信用の完成HexフレームやSUM値を断定してはいけません。

SUMは検証済みスクリプト、既存コード、または専用ツールで再計算してください。
