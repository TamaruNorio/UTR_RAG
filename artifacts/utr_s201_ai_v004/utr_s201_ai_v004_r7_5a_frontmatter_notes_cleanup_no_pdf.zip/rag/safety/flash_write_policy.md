---
title: "FLASH書き込みポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
risk_level: "high"
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "cross-command safety policy document; no single command mapping"
safety_profile_ref: null
safety_profile_note: "cross-command safety policy; see command_safety_matrix.yml"
pdf_cross_checked: not_applicable
pdf_cross_checked_note: "policy document; verified against safety/source matrices, not a single PDF command section"
policy_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "policy_controls_generation"
automatic_send_allowed: "false"
cross_model_reuse: "prohibited"
target_models:
- UTR-S201
- UTR-S202
- UTR-SHR201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
operation_type: flash_write_policy
applies_to_all_target_models: true
model_scope_required: false
future_version_policy: "do_not_assume_compatible"
requires_pdf_confirmation: "true"
---

# FLASH書き込みポリシー

FLASHデータへの書き込みは、実機に永続的な設定変更を残す可能性があります。

## AIの既定動作
- 明示許可なしに実装しません。
- 自動送信しません。
- 既存安全ガードを削除・緩和しません。
- 必要な場合は、対象機種、ROMシリーズ、変更値、復元可否、実機確認手順、社内承認要否を確認します。
