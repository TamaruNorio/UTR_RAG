---
title: "ROMバージョン依存ポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
operation_type: "rom_version_dependency_policy"
risk_level: "high"
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "cross-command safety policy document; no single command mapping"
safety_profile_ref: null
safety_profile_note: "cross-command safety policy; see command_safety_matrix.yml"
pdf_cross_checked: not_applicable
pdf_cross_checked_note: "policy document; verified against safety/source matrices, not a single PDF command section"
policy_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "explanation_only_until_verified"
automatic_send_allowed: "false"
requires_explicit_user_permission: "true"
requires_pdf_confirmation: "true"
future_version_policy: "do_not_assume_compatible"
unknown_version_action: "stop_before_implementation"
---

# ROMバージョン依存ポリシー

ROMバージョンは将来更新される可能性があります。AIは、既知ROMより新しいROMを上位互換と仮定してはいけません。

## 停止条件

- ROMバージョン未指定
- ROMシリーズ未指定
- 既知マトリクスにないROM
- 将来ROM
- PDF正本または更新資料で未確認

この場合、バージョン依存コマンドの実装、完成Hex、Codex実装依頼文は生成しません。
