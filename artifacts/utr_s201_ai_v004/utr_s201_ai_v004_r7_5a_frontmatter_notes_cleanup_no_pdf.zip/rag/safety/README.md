---
title: "RAG safety README"
category: "readme"
chunk_type: "readme"
rag_priority: "skip"
search_target: false
operation_type: "readme"
target_models:
- UTR-S201
- UTR-S202
- UTR-SHR201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
---
# RAG safety policies

このフォルダは、生成AIが危険操作や機種差分を推測で扱わないための安全ポリシーチャンクです。

- FLASH、送信出力、周波数、InventoryParam、アンテナ制御、Kill/Lock等は明示許可なしに実装しません。
- 不明時は推測せず、PDF正本確認または実機確認へ戻します。
