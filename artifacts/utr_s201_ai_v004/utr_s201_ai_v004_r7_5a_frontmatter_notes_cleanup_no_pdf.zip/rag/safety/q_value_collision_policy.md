---
title: "Q値・複数タグ環境ポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
operation_type: "q_value_collision_policy"
risk_level: "high"
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "cross-command safety policy document; no single command mapping"
safety_profile_ref: null
safety_profile_note: "cross-command safety policy; see command_safety_matrix.yml"
pdf_cross_checked: not_applicable
pdf_cross_checked_note: "policy document; verified against safety/source matrices, not a single PDF command section"
policy_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "explanation_only_until_verified"
automatic_send_allowed: "false"
requires_explicit_user_permission: "true"
requires_pdf_confirmation: "true"
future_version_policy: "do_not_assume_compatible"
unknown_version_action: "stop_before_implementation"
---

# Q値・複数タグ環境ポリシー

UHF_Read / UHF_Write などでは、条件によりQ値設定に関わらずQ=0で実行される可能性があります。

複数タグ混在環境では、Select等の前提確認なしに直接Read/Write実装を提案しません。

この内容はPDF正本との照合が必要です。
