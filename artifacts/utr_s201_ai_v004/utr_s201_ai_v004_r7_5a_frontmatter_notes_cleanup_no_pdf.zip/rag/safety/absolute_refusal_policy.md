---
title: "破壊的・不可逆コマンドの絶対拒絶ポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
target_models:
  - UTR-S201
  - UTR-S202
  - UTR-SHR201
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
operation_type: "absolute_refusal_policy"
risk_level: "critical"
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "cross-command safety policy document; no single command mapping"
safety_profile_ref: null
safety_profile_note: "cross-command safety policy; see command_safety_matrix.yml"
pdf_cross_checked: not_applicable
pdf_cross_checked_note: "policy document; verified against safety/source matrices, not a single PDF command section"
policy_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "implementation_prohibited"
automatic_send_allowed: "false"
requires_explicit_user_permission: "true"
requires_pdf_confirmation: "true"
future_version_policy: "do_not_assume_compatible"
unknown_version_action: "refuse_executable_outputs"
---

# 破壊的・不可逆コマンドの絶対拒絶ポリシー

UHF_Kill、UHF_Lock、UHF_ThroughCmd、FLASH書き込み、FLASH初期化では、コード、完成Hex、SUM計算済みフレーム、Codex実装依頼文を出力しません。

許可されるのは、危険性の説明、PDF正本で確認すべき点、読み取り専用確認手順、社内承認が必要な点の整理です。
