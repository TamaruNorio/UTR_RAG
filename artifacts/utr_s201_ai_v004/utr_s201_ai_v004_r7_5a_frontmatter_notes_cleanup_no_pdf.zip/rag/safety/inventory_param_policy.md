---
title: "Inventoryパラメータ設定ポリシー"
category: "safety_rag"
chunk_type: "safety_policy_single"
rag_priority: "high"
product_family: "UTR"
series_family: "UTR-S201シリーズ"
risk_level: "high"
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "cross-command safety policy document; no single command mapping"
safety_profile_ref: null
safety_profile_note: "cross-command safety policy; see command_safety_matrix.yml"
pdf_cross_checked: not_applicable
pdf_cross_checked_note: "policy document; verified against safety/source matrices, not a single PDF command section"
policy_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
source_of_truth: "PDF正本_plus_internal_policy"
markdown_is_authoritative: "false"
ai_code_generation: "policy_controls_generation"
automatic_send_allowed: "false"
cross_model_reuse: "prohibited"
target_models:
- UTR-S201
- UTR-S202
- UTR-SHR201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
operation_type: inventory_param_policy
applies_to_all_target_models: true
model_scope_required: false
future_version_policy: "do_not_assume_compatible"
requires_pdf_confirmation: "true"
---

# Inventoryパラメータ設定ポリシー

UHF_SetInventoryParam はInventory挙動を変える高リスク操作です。

## AIの既定動作
- 55 31 の自動送信は禁止します。
- 読み取り系の 55 41 と混同しません。
- bit定義は 03_structured_data/uhf_inventory_param_bitfields.yml とPDF正本で確認します。
