---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: '危険操作: Kill / Lock / FLASH初期化'
topic: 危険操作 注意喚起
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: high
risk_level: critical
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "cross-command safety policy document; no single command mapping"
safety_profile_ref: null
safety_profile_note: "cross-command safety policy; see command_safety_matrix.yml"
pdf_cross_checked: not_applicable
pdf_cross_checked_note: "policy document; verified against safety/source matrices, not a single PDF command section"
policy_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
  - 03_structured_data/source_traceability_matrix.yml
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Kill
- UHF_Lock
- FLASH
- RF
- EPC
- UII
- PC
- AI
- TID
- RAG
- リーダライタ
- RFタグ
- MemBank
- パスワード
- Kill
- Lock
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- 危険操作
- Kill Password
- 復旧不能
- メモリロック
- Access Password
- RAM
- 設定保存
- FLASH設定値
- 電源再投入
- 初期化
- Reserved領域
- リスタート
- 再起動
- 2秒待機
- FLASH読込
- PC+EPC
- StoredPC
- EPC(UII)
- UHFタグ
- タグ
- Reader Writer
- RW
- コマンド
- command
- frame
- 実機注意
- 検証用タグ
- 現場投入注意
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Kill
- UHF_Lock
- FLASH
- Kill
- Lock
- Kill Password
- FLASH設定値
- FLASH読込
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md
optimized_path: 00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md
source_chapters:
- 第4章
- 第7章
- 第8章
- 第9章
---
# 危険操作: Kill / Lock / FLASH初期化

## 要約

UTRシリーズのRFタグ通信やリーダライタ設定には、実行後の復旧が難しい操作があります。

特に、UHF_Kill、UHF_Lock、FLASH設定の初期化、パスワード書き込み、EPC書き換えは、顧客環境の実タグ・実機に対して安易に実行しないでください。

## 危険操作一覧

| 操作 | 主なリスク | 事前確認 |
|---|---|---|
| UHF_Kill | RFタグが恒久的に応答しなくなる | 検証用タグか、Kill Passwordが正しいか、復旧不能を理解しているか |
| UHF_Lock | メモリ領域の読み書きが制限される | Access Password、Lock対象、ロック種別を確認する |
| Access Password書き込み | パスワード不明時に解除不能になる可能性 | パスワード管理方法、対象MemBank、検証用タグを確認する |
| Kill Password書き込み | Kill操作が可能な状態になる | 誤Kill防止、パスワード管理を確認する |
| EPC(UII)書き換え | タグ識別情報が変わる | Stored PC、EPC Length、対象タグ1枚化を確認する |
| FLASH設定値の書き込み | 電源再投入後の動作が変わる | 現在値バックアップ、差分確認、書き込み頻度を確認する |
| FLASH設定の初期化 | 設定が初期状態へ戻る | 現場設定、通信設定、復旧手順を確認する |

## UHF_Killの注意

KillされたRFタグは、それ以降すべてのコマンドに応答しません。基本的に元に戻せません。

生成AIがUHF_Killのコードや手順を出す場合は、必ず次の注意を入れます。

```text
この操作はRFタグを復旧不能な状態にする可能性があります。
検証用タグ以外では実行しないでください。
```

## UHF_Lockの注意

Lockは、指定MemBankの読み書き権限を変更します。

Access Passwordを忘れると、ロック解除や再書き込みができなくなる場合があります。恒久ロックやPermaLock系の操作は特に注意します。

## FLASH操作の注意

FLASHは頻繁な書き換えに向きません。

FLASH書き込み処理をアプリに入れる場合は、毎回無条件で書かず、以下の手順にします。

```text
1. 現在のFLASH設定値を読み取る
2. 期待値と比較する
3. 差分がある場合のみ書き込む
4. 書き込み後に再読み取りして確認する
5. 必要に応じてリスタートし、反映を確認する
```

## 顧客環境での作業前チェック

- 検証用タグで手順確認したか。
- 対象タグを1枚に絞れているか。
- パスワードを記録・管理できているか。
- 操作前のEPC、TID、Userデータ、設定値を保存したか。
- 失敗時の復旧手順を説明できるか。
- 操作ログを残す設計になっているか。

## 生成AI向け注意

危険操作のコードを生成する場合、単に「実行できます」と書かず、必ずリスク、前提条件、検証用タグでの確認、ログ出力を含めます。

## RAG検索キーワード

UHF_Kill, UHF_Lock, FLASH初期化, Access Password, Kill Password, EPC書き換え, 復旧不能, 危険操作, PermaLock

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Kill / UHF_Lock / FLASH / RF / EPC / UII / PC / AI / TID / RAG / リーダライタ / RFタグ / MemBank / パスワード / Kill / Lock / 通信 / インターフェース / シリアル通信 / TCP/IP / USB / Bluetooth / Wi-Fi / COMポート / 危険操作 / Kill Password / 復旧不能 / メモリロック / Access Password / RAM / 設定保存 / FLASH設定値 / 電源再投入 / 初期化 / Reserved領域 / リスタート / 再起動 / 2秒待機 / FLASH読込 / PC+EPC / StoredPC / EPC(UII)
