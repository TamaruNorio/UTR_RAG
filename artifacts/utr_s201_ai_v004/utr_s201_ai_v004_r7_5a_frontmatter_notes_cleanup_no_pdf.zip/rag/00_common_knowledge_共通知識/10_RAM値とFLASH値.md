---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: RAM値とFLASH値
topic: RAM FLASH 設定保持
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- RAM
- FLASH
- 'OFF'
- RF
- AI
- RAG
- 動作モード
- コマンドモード
- 自動読み取りモード
- RFタグ
- アンテナ
- 送信出力
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- UHF連続インベントリモード
- 設定保存
- FLASH設定値
- 電源再投入
- 初期化
- アンテナ番号
- アンテナ自動切替
- 断線確認
- UHF_CheckAntenna
- 出力設定
- dBm
- mW
- 電波法
- キャリア
- リスタート
- 再起動
- 2秒待機
- FLASH読込
- UHFタグ
- タグ
- コマンド
- command
- frame
aliases:
- RFタグ
- UHFタグ
- タグ
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- FLASH
- FLASH設定値
- UHF_CheckAntenna
- FLASH読込
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/10_RAM値とFLASH値.md
optimized_path: 00_common_knowledge_共通知識/10_RAM値とFLASH値.md
source_chapters:
- 第3章 3.12
- 第9章
---
# RAM値とFLASH値

## 要約

UTRシリーズの設定値には、RAMに保持される値と、FLASHに保存される値があります。

一時的に変えたい設定はRAM値、電源再投入後も保持したい設定はFLASH値を使います。ただし、FLASHは頻繁な書き換えを想定したものではないため、乱用しない設計が必要です。

## 設定値の種類

| 種類 | 保存先 | 主に参照される場面 | 電源OFF後 |
|---|---|---|---|
| コマンドモード用パラメータ | RAM | コマンドモードでRFタグ通信コマンドを実行する場合 | 消える |
| 自動読み取りモード用パラメータ | RAM | 自動読み取りモードで動作する場合 | 消える |
| FLASHデータ | FLASH | 起動時、リスタート時にRAMへ反映される | 保持される |

## 起動時の考え方

```text
電源投入 / リスタート
  ↓
FLASHデータを読み込む
  ↓
コマンドモード用RAM値、自動読み取りモード用RAM値へ反映
  ↓
設定された動作モードで起動
```

## 使い分け

| 目的 | 推奨 |
|---|---|
| 試験中に送信出力を一時変更したい | RAM値を変更する |
| アプリ起動中だけアンテナを切り替えたい | RAM値を変更する |
| 電源再投入後も同じ設定で起動させたい | FLASH値へ保存する |
| 頻繁に値を変える | FLASHではなくRAMを使う |
| 顧客環境の標準設定を変える | 現在値を読み取ってから、必要時のみFLASHへ書く |

## FLASH書き換え時の注意

- FLASHは不揮発性メモリで、頻繁な書き換えに向きません。
- 上位ソフトが起動するたびに無条件でFLASHを書き換える設計は避けます。
- 書き換え前に現在値を読み取り、差分がある場合だけ書く設計が安全です。
- FLASH初期化は、設定が工場出荷状態へ戻る可能性があるため、顧客環境では事前確認が必須です。

## 生成AI向け注意

設定変更コードを生成するときは、以下をコメントとして入れると現場で安全です。

```text
この処理はRAM値のみを変更します。電源再投入後は元に戻ります。
電源再投入後も保持したい場合は、FLASH設定値の書き込みを別途検討してください。
```

FLASHへ書くコードを生成する場合は、必ず「頻繁に実行しない」「現在値確認後に必要時のみ書く」と明記します。

## RAG検索キーワード

RAM値, FLASH値, FLASH設定, 不揮発, 電源再投入, リスタート, 設定保持, FLASH初期化, 書き換え回数

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / RAM / FLASH / OFF / RF / AI / RAG / 動作モード / コマンドモード / 自動読み取りモード / RFタグ / アンテナ / 送信出力 / 通信 / インターフェース / シリアル通信 / TCP/IP / USB / Bluetooth / Wi-Fi / COMポート / UHF連続インベントリモード / 設定保存 / FLASH設定値 / 電源再投入 / 初期化 / アンテナ番号 / アンテナ自動切替 / 断線確認 / UHF_CheckAntenna / 出力設定 / dBm / mW / 電波法 / キャリア / リスタート / 再起動 / 2秒待機 / FLASH読込 / UHFタグ / タグ / コマンド / command
