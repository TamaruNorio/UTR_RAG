---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: SUM計算方法
topic: SUM計算
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- SUM
- STX
- ETX
- FF
- CR
- AI
- RAG
- SUM_ERROR
- 02H
- 00H
- 4FH
- 01H
- 03H
- 55H
- 4EH
- 9FH
- 45H
- 05H
- 3FH
- 動作モード
- リーダライタ
- チェックサム
- コマンドモード
- 自動読み取りモード
- UHF連続インベントリモード
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- Reader Writer
- RW
- コマンド
- command
- frame
aliases:
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- 4FH
- 55H
- 4EH
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/05_SUM計算方法.md
optimized_path: 00_common_knowledge_共通知識/05_SUM計算方法.md
source_chapters:
- 第5章 5.3
---
# SUM計算方法

## 要約

SUM値は、STXからETXまでを1バイト単位で加算し、結果の下位1バイトを使用します。

```text
SUM = (STX + アドレス + コマンド + データ長 + データ部 + ETX) & 0xFF
```

SUM自身とCRは計算に含めません。

## 計算対象

```text
含める:
  STX
  アドレス
  コマンド
  データ長
  データ部
  ETX

含めない:
  SUM
  CR
```

## 例1: リーダライタ動作モードの読み取り

| ラベル | 値 |
|---|---|
| STX | 02h |
| アドレス | 00h |
| コマンド | 4Fh |
| データ長 | 01h |
| データ部 | 00h |
| ETX | 03h |

計算は以下です。

```text
02h + 00h + 4Fh + 01h + 00h + 03h = 55h
```

送信フレームは以下です。

```text
02 00 4F 01 00 03 55 0D
```

## 例2: 桁あふれがある場合

| ラベル | 値 |
|---|---|
| STX | 02h |
| アドレス | 00h |
| コマンド | 4Eh |
| データ長 | 03h |
| データ部1 | 9Fh |
| データ部2 | 45h |
| データ部3 | 05h |
| ETX | 03h |

```text
02h + 00h + 4Eh + 03h + 9Fh + 45h + 05h + 03h = 13Fh
```

下位1バイトのみ使うため、SUMは以下です。

```text
SUM = 3Fh
```

## Pythonでの計算例

```python
def calc_sum(frame_without_sum_cr: bytes) -> int:
    """
    UTRシリーズのSUM値を計算する。

    引数:
        frame_without_sum_cr:
            STXからETXまでを含むbytes。
            SUMとCRは含めない。

    戻り値:
        SUM値。0x00から0xFFまでの整数。
    """
    return sum(frame_without_sum_cr) & 0xFF

# 例: リーダライタ動作モードの読み取り
body = bytes.fromhex("02 00 4F 01 00 03")
sum_value = calc_sum(body)
print(f"SUM = {sum_value:02X}")  # SUM = 55
```

## 受信時の検証例

```python
def verify_sum(frame: bytes) -> bool:
    """
    受信フレームのSUMを検証する。

    UTRの基本フレームは、末尾2バイトがSUMとCRです。
    SUM計算対象は、先頭STXからETXまでです。
    """
    if len(frame) < 7:
        return False
    if frame[0] != 0x02:
        return False
    if frame[-1] != 0x0D:
        return False

    received_sum = frame[-2]
    calculated_sum = sum(frame[:-2]) & 0xFF
    return received_sum == calculated_sum
```

## 生成AI向け注意

SUM計算を説明するときは、必ず「SUM自身とCRは含めない」と明記してください。ここを曖昧にすると、生成された送信コマンドが実機で通りません。現場では1バイトのズレが半日を溶かします。

## RAG検索キーワード

SUM計算, チェックサム, STXからETX, 下位1バイト, 0xFF, CRは含めない, SUM_ERROR

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / SUM / STX / ETX / FF / CR / AI / RAG / SUM_ERROR / 02H / 00H / 4FH / 01H / 03H / 55H / 4EH / 9FH / 45H / 05H / 3FH / 動作モード / リーダライタ / チェックサム / コマンドモード / 自動読み取りモード / UHF連続インベントリモード / SUM計算 / STXからETXまでの合計 / 下位1バイト / Reader Writer / RW / コマンド / command / frame
