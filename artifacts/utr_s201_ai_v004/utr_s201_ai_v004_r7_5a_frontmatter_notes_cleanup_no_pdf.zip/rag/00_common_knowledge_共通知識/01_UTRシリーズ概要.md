---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: UTRシリーズ概要
topic: シリーズ概要
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- AI
- SUN02
- CH
- SUN02V
- SHR201
- COM
- TCP
- IP
- EPC
- TID
- RAM
- FLASH
- ROM
- RF
- ACK
- NACK
- USB
- RS
- LAN
- STX
- SUM
- CR
- RSSI
- ANGLE
- RAG
- 4CH
- 8CH
- 通信フォーマット
- 通信インターフェース
- 動作モード
- コマンドモード
- 自動読み取りモード
- リーダライタ
- RFタグ
- アンテナ
- アンテナ番号
- レスポンス
- MemBank
- ROMバージョン
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- Bluetooth
- Wi-Fi
- COMポート
- 有線LAN
- USB Type-C
- UART
- RS-232C
- UHF連続インベントリモード
- ETX
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- 設定保存
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- FLASH
- ACK
- NACK
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/01_UTRシリーズ概要.md
optimized_path: 00_common_knowledge_共通知識/01_UTRシリーズ概要.md
source_chapters:
- 第1章
- 第2章
- 第6章
---
# UTRシリーズ概要

## 要約

UTRシリーズは、UHF帯RFIDリーダライタを上位機器から制御するための製品群です。本Markdown群では、UTR-S201シリーズ通信プロトコル説明書に基づき、現行UTRシリーズを対象として整理します。

この共通知識ファイルでは、個別コマンドではなく、生成AIが最初に押さえるべき前提をまとめます。

## 対象機種

本Markdown群で主に扱う対象機種は以下です。

| 機種 | 概要 |
|---|---|
| UTR-S201 | 基板モジュール型リーダライタ |
| UTR-SUN02-4CH | 据置型4CH系リーダライタ。内蔵アンテナ1CH、外部アンテナ3CH構成として扱う |
| UTR-SUN02V-8CH | 据置型8CH系リーダライタ |
| UTR-SUN02-8CH | 据置型8CH系リーダライタ |
| UTR-SHR201 | ハンディ型リーダライタ |

## 生成AIが最初に確認すべきこと

UTRシリーズの制御相談では、いきなりコマンド列を作るのではなく、以下を確認します。

| 確認項目 | 理由 |
|---|---|
| 対象機種 | アンテナ番号、対応インターフェース、対応コマンドが変わるため |
| 接続方式 | COMポート制御かTCP/IPソケット制御かが変わるため |
| 動作モード | コマンドモードか自動読み取りモードかで受信処理が変わるため |
| 読み取り対象 | EPCだけか、TID/User領域も必要かで使用コマンドが変わるため |
| 設定変更の保存先 | RAM値だけかFLASH値まで変更するかでリスクが変わるため |
| 実機のROMバージョン | 一部機能・挙動・対応条件がROMバージョンに依存するため |

## 基本的な制御の考え方

UTRシリーズは、上位機器からバイナリの通信フレームを送信し、リーダライタからのレスポンスを受信して制御します。

```text
上位アプリ
  ↓ 接続を開く
リーダライタ
  ↓ コマンド送信
リーダライタ内部処理 / RFタグ通信
  ↓ レスポンス受信
上位アプリでACK/NACK/タグデータを解析
```

接続方式がUSB、RS-232C、Bluetooth、LAN、Wi-Fiのどれであっても、リーダライタへ送るコマンドフレームの基本構造は共通です。

## よく使う章

| 知りたいこと | 参照先 |
|---|---|
| 接続方式 | 第1章 通信インターフェース |
| 動作モード | 第2章 リーダライタの動作モード |
| キャリア、アンテナ、RAM/FLASH | 第3章 リーダライタの機能 |
| RFタグのMemBank | 第4章 RFタグの機能 |
| STX/SUM/CR | 第5章 通信フォーマット |
| コマンド一覧 | 第6章 コマンド一覧/対応表 |
| 個別コマンド仕様 | 第7章 コマンドフォーマット |
| 実用フロー | 第8章 RFタグ制御方法 |
| FLASHアドレス | 第9章 FLASH |
| RSSI/ANGLE、参考値 | 第10章 参考資料 |

## RAG検索キーワード

UTR, UTR-S201, UTR-SUN02-4CH, UTR-SUN02-8CH, UTR-SHR201, UHF RFID, R2000, 通信プロトコル, コマンド制御, RFタグ通信

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / AI / SUN02 / CH / SUN02V / SHR201 / COM / TCP / IP / EPC / TID / RAM / FLASH / ROM / RF / ACK / NACK / USB / RS / LAN / STX / SUM / CR / RSSI / ANGLE / RAG / 4CH / 8CH / 通信フォーマット / 通信インターフェース / 動作モード / コマンドモード / 自動読み取りモード / リーダライタ / RFタグ / アンテナ / アンテナ番号 / レスポンス / MemBank / ROMバージョン / 通信 / インターフェース / シリアル通信
