---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: RSSI/ANGLE値の読み方
topic: RSSI ANGLE 受信解析
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Inventory
- UHF_InventoryRead
- RSSI_ANGLE
- RSSI
- ANGLE
- RF
- FF
- FE
- FFh
- ROM
- RAG
- FF12
- 12H
- FFH
- 30H
- 2FH
- RFタグ
- アンテナ
- レスポンス
- ROMバージョン
- Read
- Inventory
- インベントリ
- EPC
- UII
- Stored PC
- タグ読み取り
- InventoryRead
- インベントリリード
- MemBank
- TID付加読み取り
- UHF_Read
- 読み取り
- WordPtr
- WordCount
- アンテナ番号
- アンテナ自動切替
- 断線確認
- UHF_CheckAntenna
- 受信強度
- 位相
- RSSIフィルタ
- ファームウェア
- USM01
- USM02
- USM05
- USM06
- USM08
- UHFタグ
- タグ
- コマンド
- command
- frame
aliases:
- RFタグ
- UHFタグ
- タグ
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Inventory
- UHF_InventoryRead
- Inventory
- InventoryRead
- UHF_Read
- UHF_CheckAntenna
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/13_RSSI_ANGLE値の読み方.md
optimized_path: 00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md
source_chapters:
- 第7章 7.5
- 第10章
---
# RSSI / ANGLE値の読み方

## 要約

UHF_InventoryやUHF_InventoryReadなどのRFタグデータレスポンスには、RSSI値とANGLE値が含まれる場合があります。

RSSIはRFタグ応答の受信信号レベルを示し、ANGLEは位相情報を角度換算した値として扱います。

## RSSI値の読み方

RSSI値は、レスポンス内では符号付き16ビット整数として扱い、10で割ってdBmに変換します。

```text
RSSI[dBm] = 符号付き16ビット整数 / 10
```

### 例

```text
受信値: FF 12h
符号付き16ビット整数: -238
RSSI: -238 / 10 = -23.8 dBm
```

別例です。

```text
受信値: FE FFh
符号付き16ビット整数: -257
RSSI: -257 / 10 = -25.7 dBm
```

## PythonでのRSSI変換例

```python
def rssi_bytes_to_dbm(high: int, low: int) -> float:
    """
    UTRのRSSI 2バイトをdBmへ変換する。
    レスポンス上の2バイトをbig-endianの符号付き16ビット整数として扱う。
    """
    raw = int.from_bytes(bytes([high, low]), byteorder="big", signed=True)
    return raw / 10.0

print(rssi_bytes_to_dbm(0xFF, 0x12))  # -23.8
```

## ANGLE値の読み方

ANGLE値は、00hから40hの範囲で返る値を、以下の式で度に変換します。

```text
ANGLE[度] = ANGLE値 × 45 / 16
```

### 例

```text
受信値: 30h
10進数: 48
ANGLE: 48 × 45 / 16 = 135度
```

```text
受信値: 2Fh
10進数: 47
ANGLE: 47 × 45 / 16 = 132.1875度
```

## PythonでのANGLE変換例

```python
def angle_byte_to_degree(value: int) -> float:
    """
    UTRのANGLE 1バイトを度へ変換する。
    """
    return value * 45.0 / 16.0

print(angle_byte_to_degree(0x30))  # 135.0
```

## RSSIフィルタとの関係

RSSIフィルタ機能では、読み取ったデータの内容とRSSI閾値を組み合わせて、上位機器へレスポンスを返すかどうかを制御できます。

ただし、RSSIフィルタ設定は対象コマンドやROMバージョン条件を確認してください。UHF_Inventoryでは判定対象にならない旨の注意があります。

## 実務上の注意

- RSSIは絶対的な距離を直接示す値ではありません。
- アンテナ向き、タグ向き、周囲金属、人体、水分、反射の影響を受けます。
- RSSIのしきい値でエリア判定を行う場合は、現場環境で実測して決めます。
- ANGLE値も環境影響を受けるため、単独で位置を断定しないでください。

## RAG検索キーワード

RSSI, RSSI値, dBm, 符号付き16ビット, FF12, ANGLE, 位相, 45/16, UHF_Inventory, UHF_InventoryRead, RSSIフィルタ

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Inventory / UHF_InventoryRead / RSSI_ANGLE / RSSI / ANGLE / RF / FF / FE / FFh / ROM / RAG / FF12 / 12H / FFH / 30H / 2FH / RFタグ / アンテナ / レスポンス / ROMバージョン / Read / Inventory / インベントリ / EPC / UII / Stored PC / タグ読み取り / InventoryRead / インベントリリード / MemBank / TID付加読み取り / UHF_Read / 読み取り / WordPtr / WordCount / アンテナ番号 / アンテナ自動切替 / 断線確認 / UHF_CheckAntenna / 受信強度 / 位相 / RSSIフィルタ
