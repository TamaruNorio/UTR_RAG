---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: UTRとUTRXの違い
topic: シリーズ切り分け
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: medium
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Inventory
- UHF_Read
- UHF_Write
- UHF_Lock
- UHF_Kill
- UTRX
- AI
- RAG
- MS710
- RSSI
- ANGLE
- ACK
- NACK
- FLASH
- DB
- TDR
- MNL
- PRC
- 自動読み取りモード
- アンテナ
- アンテナ番号
- 送信出力
- 出力設定
- レスポンス
- Kill
- Lock
- Read
- Write
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- 30h
- 31h
- エラーコード
- 異常応答
- Inventory
- インベントリ
- EPC
- UII
- Stored PC
- タグ読み取り
- 読み取り
- MemBank
- WordPtr
- WordCount
- 書き込み
- EPC書き換え
- WriteData
- 危険操作
- Kill Password
- 復旧不能
- メモリロック
- Access Password
- RAM
- 設定保存
- FLASH設定値
- 電源再投入
aliases:
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Inventory
- UHF_Read
- UHF_Write
- UHF_Lock
- UHF_Kill
- ACK
- NACK
- FLASH
- Kill
- Lock
- Inventory
- Kill Password
- FLASH設定値
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/15_UTRとUTRXの違い.md
optimized_path: 00_common_knowledge_共通知識/15_UTRとUTRXの違い.md
source_chapters:
- UTR-S201シリーズ通信プロトコル説明書
- UTRXシリーズ通信プロトコル説明書
---
# UTRとUTRXの違い

## 要約

このファイルは、UTRシリーズとUTRXシリーズを生成AI/RAGで混同しないための切り分けメモです。

本パッケージでは、UTR-S201シリーズをR2000系チップセット前提の資料として扱い、UTRXシリーズとは別系統として扱います。

個別コマンド、詳細コマンド、パラメータ、レスポンス形式、エラーコードはシリーズごとに確認してください。

## 基本的な切り分け

| 項目 | UTRシリーズ | UTRXシリーズ |
|---|---|---|
| 位置づけ | 現行UTRシリーズ | UTRXシリーズ |
| 主なチップセット前提 | R2000系 | MS710 / E710系 |
| 参照すべき仕様書 | UTR-S201シリーズ通信プロトコル説明書 | UTRXシリーズ向け通信プロトコル説明書 |
| Markdownフォルダ | UTR版_md | UTRX版_md |
| 回答時の扱い | UTR用仕様として回答 | UTRX用仕様として回答 |

## 混同してはいけないもの

以下は、同じ名前や似た名前でもシリーズごとに仕様確認が必要です。

- UHF_Inventory
- UHF_Read
- UHF_Write
- UHF_Lock
- UHF_Kill
- アンテナ設定
- 送信出力設定
- RSSI / ANGLEの扱い
- ACK/NACKレスポンス
- エラーコード
- FLASH設定値
- 自動読み取りモードの非同期レスポンス

## 生成AI回答時のルール

ユーザーが「UTR」「UTRX」を明示している場合は、そのシリーズのMarkdownだけを根拠に回答します。

ユーザーがシリーズ名を明示していない場合は、次のように確認します。

```text
対象はUTRシリーズでしょうか、UTRXシリーズでしょうか。
通信プロトコルや設定値が異なる可能性があるため、対象機種名を確認させてください。
```

## RAG運用上の推奨

UTR版とUTRX版を同じベクトルDBに入れる場合は、メタデータで必ずシリーズを分けます。

推奨メタデータ例です。

```yaml
series: UTR
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
```

```yaml
series: UTRX
chipset: MS710/E710
manual_id: <UTRX側のマニュアル番号>
```

検索時には、ユーザー質問から対象シリーズを判定し、`series` でフィルタリングしてから回答します。

## 禁止したい回答パターン

```text
UTRの質問に、UTRXのコマンド仕様を混ぜる。
UTRXの質問に、UTRのアンテナ番号体系を当てはめる。
シリーズ不明なのに、コマンドバイト列を断定する。
チップセット差があるのに、レスポンス形式を同一視する。
```

## 実務上の一言

UTRとUTRXは、名前が似ているためAIが混ぜやすい領域です。RAGでは「似ている資料を一緒に入れるほど便利」ですが、RFIDプロトコルでは「似ている資料ほど危険」でもあります。シリーズフィルタは必須です。

## RAG検索キーワード

UTR, UTRX, R2000, MS710, E710, シリーズ違い, 通信プロトコル違い, 混同防止, RAGフィルタ, メタデータ

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Inventory / UHF_Read / UHF_Write / UHF_Lock / UHF_Kill / UTRX / AI / RAG / MS710 / RSSI / ANGLE / ACK / NACK / FLASH / DB / TDR / MNL / PRC / 自動読み取りモード / アンテナ / アンテナ番号 / 送信出力 / 出力設定 / レスポンス / Kill / Lock / Read / Write / 通信 / インターフェース / シリアル通信 / TCP/IP / USB / Bluetooth / Wi-Fi / COMポート / 30h / 31h / エラーコード / 異常応答 / Inventory / インベントリ
