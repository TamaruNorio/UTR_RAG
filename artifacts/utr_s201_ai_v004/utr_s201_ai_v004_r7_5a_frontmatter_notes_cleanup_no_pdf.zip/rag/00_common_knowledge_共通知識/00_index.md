---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: UTR版 共通知識インデックス
topic: 共通知識インデックス
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- RAG
- AI
- USB
- RS
- LAN
- STX
- CR
- SUM
- ACK_NACK
- ROM
- RF
- EPC
- TID
- RAM
- FLASH
- CH
- 'ON'
- 'OFF'
- RSSI_ANGLE
- RSSI
- ANGLE
- UTRX
- ACK
- NACK
- 4CH
- 8CH
- 通信フォーマット
- 動作モード
- コマンドモード
- 自動読み取りモード
- RFタグ
- アンテナ
- アンテナ番号
- キャリアセンス
- 電波法
- レスポンス
- MemBank
- ROMバージョン
- パスワード
- Kill
- Lock
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- Bluetooth
- Wi-Fi
- COMポート
- 通信インターフェース
- 有線LAN
- USB Type-C
- UART
- RS-232C
- UHF連続インベントリモード
- ETX
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- RFタグ
- UHFタグ
- タグ
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- ACK_NACK
- FLASH
- ACK
- NACK
- Kill
- Lock
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/00_index.md
optimized_path: 00_common_knowledge_共通知識/00_index.md
source_chapters:
- 全章
---
# UTR版 共通知識インデックス

## このフォルダの目的

このフォルダは、UTR-S201シリーズ通信プロトコル説明書をRAGや生成AIスキルで使うときに、個別章・個別コマンドをまたいで必要になる前提知識をまとめたものです。

個別仕様を確認するときは、各章ファイルまたは第7章の個別コマンドファイルを参照してください。このフォルダのファイルは、回答時の入口・判断基準・注意事項として使います。

## ファイル一覧

| ファイル | 主な用途 |
|---|---|
| 01_UTRシリーズ概要.md | UTRシリーズ全体の位置づけ、対象機種、開発時の前提を確認する |
| 02_対象機種とインターフェース.md | USB、RS-232C、Bluetooth、LAN、Wi-Fiなど接続方式の確認に使う |
| 03_動作モード.md | コマンドモード、自動読み取りモード、モード遷移の判断に使う |
| 04_通信フォーマット.md | STXからCRまでの共通フレーム構造を確認する |
| 05_SUM計算方法.md | 送信コマンド生成、受信フレーム検証、サンプルコード生成に使う |
| 06_ACK_NACKレスポンス.md | 正常応答と異常応答、エラーコード解析の入口に使う |
| 07_コマンド逆引き.md | やりたいことから該当コマンド・章へ誘導する |
| 08_機種別_バージョン別_対応表.md | 機種差、ROMバージョン条件、対応機能確認に使う |
| 09_RFタグメモリ構造.md | MemBank、Wordアドレス、EPC、TID、User領域を説明する |
| 10_RAM値とFLASH値.md | 一時設定と永続設定、FLASH書き換え注意の説明に使う |
| 11_アンテナ番号.md | 4CH、8CH、モジュール、ハンディのアンテナ番号体系を確認する |
| 12_キャリアセンスと電波法注意.md | キャリアON/OFF、キャリアセンス、送信時間制限の注意に使う |
| 13_RSSI_ANGLE値の読み方.md | RFタグレスポンス内のRSSI/ANGLEを数値化する |
| 14_危険操作_Kill_Lock_FLASH初期化.md | Kill、Lock、FLASH初期化、パスワード操作時の警告に使う |
| 15_UTRとUTRXの違い.md | UTRシリーズとUTRXシリーズを混同しないための切り分けに使う |

## RAGでの使い方

質問に該当する個別コマンドが分かっている場合は、第7章の個別コマンドファイルを優先します。

質問が「通信できない」「タグが読めない」「送信コマンドを作りたい」「レスポンスを解析したい」のように横断的な場合は、まずこの共通知識ファイルを参照し、その後に該当章・該当コマンドへ進めます。

## 生成AI回答時の基本ルール

1. 対象シリーズがUTRかどうかを確認する。
2. 対象機種、接続方式、動作モードを確認する。
3. コマンドを出す場合は、必ずSUM計算とACK/NACK処理まで説明する。
4. RFタグ書き込み、Kill、Lock、FLASH操作は危険操作として明示する。
5. 機種差・ROMバージョン差がある項目は断定せず、該当ファイルを参照する。

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / RAG / AI / USB / RS / LAN / STX / CR / SUM / ACK_NACK / ROM / RF / EPC / TID / RAM / FLASH / CH / ON / OFF / RSSI_ANGLE / RSSI / ANGLE / UTRX / ACK / NACK / 4CH / 8CH / 通信フォーマット / 動作モード / コマンドモード / 自動読み取りモード / RFタグ / アンテナ / アンテナ番号 / キャリアセンス / 電波法 / レスポンス / MemBank / ROMバージョン / パスワード / Kill / Lock / 通信
