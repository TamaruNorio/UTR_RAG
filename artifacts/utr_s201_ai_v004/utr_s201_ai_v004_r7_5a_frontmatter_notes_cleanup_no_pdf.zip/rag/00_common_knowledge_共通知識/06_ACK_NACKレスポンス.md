---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: ACK/NACKレスポンス
topic: ACK NACK エラー
chapter: '00'
category: 共通知識
chunk_type: common_knowledge
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Encode
- UHF_BlockWrite2
- UHF_IC
- ACK_NACK
- ACK
- NACK
- RF
- SUM
- CMD_CRC_ERROR
- CRC
- CMD_TIME_OVER
- CMD_RX_ERROR
- CMD_RXBUSY_ERROR
- CMD_ERROR
- CMD_UHF_IC_ERROR
- CMD_LBT_ERROR
- HARDWARE_ERROR
- CMD_ANT_ERROR
- SUM_ERROR
- FORMAT_ERROR
- STX
- CR
- AI
- RAG
- 30H
- 31H
- 01H
- 02H
- 03H
- 04H
- 07H
- 0AH
- 60H
- 64H
- 68H
- 42H
- 44H
- 0BH
- 20H
- 22H
- 23H
- 80H
- 81H
- 82H
- 90H
- 通信フォーマット
- 動作モード
- RFタグ
- アンテナ
- アンテナ番号
- 断線確認
- キャリアセンス
- レスポンス
- パスワード
- Kill
- Lock
- Write
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
aliases:
- RFタグ
- UHFタグ
- タグ
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Encode
- UHF_BlockWrite2
- UHF_IC
- ACK_NACK
- ACK
- NACK
- CMD_UHF_IC_ERROR
- Kill
- Lock
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_共通知識/06_ACK_NACKレスポンス.md
optimized_path: 00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md
source_chapters:
- 第5章 5.4
- 第7章 7.6
---
# ACK/NACKレスポンス

## 要約

UTRシリーズのレスポンスは、正常時のACKレスポンス、異常時のNACKレスポンス、RFタグデータレスポンスなどに分かれます。

ACK/NACKを正しく判定するには、第5章の通信フォーマットに従ってフレーム全体を受信し、SUMを検証したうえで、コマンド欄とデータ部を確認します。

## ACKレスポンス

ACKレスポンスは、コマンド欄が `30h` です。

個別コマンドにより、ACKのデータ部は異なります。

| 種類 | 例 |
|---|---|
| データなしACK | 書き込み成功などでデータ長00hのACKが返る場合 |
| 詳細コマンド付きACK | コマンド55h系で、データ部に詳細コマンドが返る場合 |
| 設定値付きACK | 読み取り系コマンドで、現在設定値がデータ部に返る場合 |
| RFタグ通信結果付きACK | RFタグ通信コマンドの処理完了を示す場合 |

## NACKレスポンス

NACKレスポンスは、コマンド欄が `31h` です。

NACKレスポンスには、どの詳細コマンドでエラーが発生したか、エラーコード1、必要に応じてエラーコード2以降が含まれます。

### NACKの主な構成

| 項目 | 内容 |
|---|---|
| コマンド | 31h |
| データ部1 | 詳細コマンド。エラー発生に対応する詳細コマンド |
| データ部2 | エラーコード1 |
| データ部3 | エラーコード2。エラーコード1が0Ahの場合などに参照 |
| データ部4以降 | UHF_EncodeやUHF_BlockWrite2など一部コマンドで追加情報を持つ場合あり |

## 主なエラーコード

| エラーコード | シンボル | 主な意味 |
|---|---|---|
| 01h | CMD_CRC_ERROR | RFタグから受信したデータのCRC不一致 |
| 02h | CMD_TIME_OVER | RFタグからの受信データが途中で途切れた |
| 03h | CMD_RX_ERROR | アンチコリジョン処理中のエラー |
| 04h | CMD_RXBUSY_ERROR | RFタグから応答がない |
| 07h | CMD_ERROR | コマンド実行中に内部エラー |
| 0Ah | CMD_UHF_IC_ERROR | RFタグアクセス時の内蔵チップ由来エラー。エラーコード2を確認する |
| 60h | CMD_LBT_ERROR | キャリアセンスでタイムアウトし、キャリア送信できなかった |
| 64h | HARDWARE_ERROR | ハードウェア内部異常 |
| 68h | CMD_ANT_ERROR | アンテナ断線検知時にRFタグ通信コマンドを送信した |
| 42h | SUM_ERROR | 上位機器から送信したコマンドのSUM値が不正 |
| 44h | FORMAT_ERROR | コマンドフォーマットまたはパラメータが不正 |

## RFタグ由来エラーの例

エラーコード1が `0Ah` の場合、エラーコード2を確認します。

| エラーコード2 | 主な意味 |
|---|---|
| 01h | サポートされていない |
| 02h | 権限が不十分 |
| 03h | メモリオーバーラン |
| 04h | メモリロック |
| 0Bh | 不十分な電力 |
| 20h | Writeに失敗 |
| 22h | Killに失敗 |
| 23h | Lockに失敗 |
| 80h | 検出されない |
| 81h | ハンドル取得失敗 |
| 82h | Accessパスワードエラー |
| 90h | CRCエラー |

## 切り分けの考え方

| 現象 | 優先して見る項目 |
|---|---|
| 応答がない | 接続、動作モード、タイムアウト、STX/CR、データ長 |
| NACK 42h | SUM計算範囲、SUM値、16進値の送信形式 |
| NACK 44h | データ長、詳細コマンド、予約領域、パラメータ範囲 |
| NACK 60h | 周囲のUHF機器、キャリアセンス待ち時間、電波環境 |
| NACK 68h | アンテナ接続、アンテナ番号、断線確認結果 |
| NACK 0Ah | RFタグ側のメモリ状態、パスワード、Lock状態、対象タグ有無 |

## 生成AI向け注意

NACKを説明するときは「単に失敗」ではなく、エラーコード1と必要に応じてエラーコード2を分けて解析してください。

## RAG検索キーワード

ACK, NACK, 30h, 31h, エラーコード, SUM_ERROR, FORMAT_ERROR, CMD_LBT_ERROR, CMD_ANT_ERROR, CMD_UHF_IC_ERROR

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Encode / UHF_BlockWrite2 / UHF_IC / ACK_NACK / ACK / NACK / RF / SUM / CMD_CRC_ERROR / CRC / CMD_TIME_OVER / CMD_RX_ERROR / CMD_RXBUSY_ERROR / CMD_ERROR / CMD_UHF_IC_ERROR / CMD_LBT_ERROR / HARDWARE_ERROR / CMD_ANT_ERROR / SUM_ERROR / FORMAT_ERROR / STX / CR / AI / RAG / 30H / 31H / 01H / 02H / 03H / 04H / 07H / 0AH / 60H / 64H / 68H / 42H / 44H / 0BH / 20H / 22H / 23H / 80H
