---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
title: RAG登録用ファイルマニフェスト
chunk_type: rag_manifest
rag_priority: high
keywords:
- UTR
- RAG
- ファイル一覧
- マニフェスト
- 検索キーワード
- YAML front matter
---
# RAG登録用ファイルマニフェスト

このファイルは、C工程で最適化したMarkdownファイルの一覧です。RAG登録時の確認用として使用してください。

| optimized_path | category | chunk_type | priority | risk | command | title |
|---|---|---|---|---|---|---|
| `00_common_knowledge_共通知識/00_index.md` | 共通知識 | common_knowledge | high | low |   | UTR版 共通知識インデックス |
| `00_common_knowledge_共通知識/01_UTRシリーズ概要.md` | 共通知識 | common_knowledge | high | low |   | UTRシリーズ概要 |
| `00_common_knowledge_共通知識/02_対象機種とインターフェース.md` | 共通知識 | common_knowledge | high | low |   | 対象機種とインターフェース |
| `00_common_knowledge_共通知識/03_動作モード.md` | 共通知識 | common_knowledge | high | low |   | 動作モード |
| `00_common_knowledge_共通知識/04_通信フォーマット.md` | 共通知識 | common_knowledge | high | low |   | 通信フォーマット |
| `00_common_knowledge_共通知識/05_SUM計算方法.md` | 共通知識 | common_knowledge | high | low |   | SUM計算方法 |
| `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md` | 共通知識 | common_knowledge | high | low |   | ACK/NACKレスポンス |
| `00_common_knowledge_共通知識/07_コマンド逆引き.md` | 共通知識 | common_knowledge | high | low |   | コマンド逆引き |
| `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md` | 共通知識 | common_knowledge | high | low |   | 機種別・バージョン別対応表 |
| `00_common_knowledge_共通知識/09_RFタグメモリ構造.md` | 共通知識 | common_knowledge | high | low |   | RFタグメモリ構造 |
| `00_common_knowledge_共通知識/10_RAM値とFLASH値.md` | 共通知識 | common_knowledge | high | low |   | RAM値とFLASH値 |
| `00_common_knowledge_共通知識/11_アンテナ番号.md` | 共通知識 | common_knowledge | high | low |   | アンテナ番号 |
| `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md` | 共通知識 | common_knowledge | high | low |   | キャリアセンスと電波法注意 |
| `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md` | 共通知識 | common_knowledge | high | low |   | RSSI/ANGLE値の読み方 |
| `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md` | 共通知識 | common_knowledge | high | critical |   | 危険操作: Kill / Lock / FLASH初期化 |
| `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md` | 共通知識 | common_knowledge | medium | low |   | UTRとUTRXの違い |
| `00_index.md` | 00_index.md | index | high | low |   | UTR版 Markdown 知識ベース index |
| `01_interface_通信インターフェース/01_通信インターフェース.md` | 通信インターフェース | chapter_section | high | low |   | 第1章 通信インターフェース |
| `02_operation_modes_動作モード/02_リーダライタの動作モード.md` | リーダライタの動作モード | chapter_section | high | low |   | 第2章 リーダライタの動作モード |
| `03_reader_functions_リーダライタ機能/03_リーダライタの機能.md` | 機能説明 | chapter_section | high | low |   | 第3章 リーダライタの機能 |
| `04_rf_tag_functions_RFタグ機能/04_RFタグの機能.md` | RFタグ基礎 / メモリ構造 / 状態遷移 | chapter_section | high | low |   | 第4章 RFタグの機能 |
| `05_frame_format_通信フォーマット/05_通信フォーマット.md` | 通信フォーマット / コマンドレスポンス / SUM計算 | chapter_section | high | low |   | 第5章 通信フォーマット |
| `06_command_list_対応表/06_コマンド一覧_対応表.md` | コマンド一覧 / 対応表 / コマンド逆引き | chapter_section | high | low |   | 第6章 コマンド一覧／対応表 |
| `07_command_format_コマンドフォーマット/07_コマンドフォーマット_概要.md` | コマンドフォーマット | chapter_overview | high | medium |   | 第7章 コマンドフォーマット |
| `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_UHF連続インベントリモード.md` | UHF連続インベントリモード | async_response_spec | high | low |   | 7.1 UHF連続インベントリモード |
| `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_UHF連続インベントリリードモード.md` | UHF連続インベントリリードモード | async_response_spec | high | low |   | 7.2 UHF連続インベントリリードモード |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md` | リーダライタ制御コマンド | command_spec | high | medium | 42 ブザーの制御 | 【42】ブザーの制御 |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md` | リーダライタ制御コマンド | command_spec | high | medium | 4E 57 LED&ブザーの制御 | 【4E 57】LED&ブザーの制御 |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md` | リーダライタ制御コマンド | command_spec | high | high | 4E 6F FLASH設定の初期化 | 【4E 6F】FLASH設定の初期化 |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md` | リーダライタ制御コマンド | command_spec | high | high | 4E 9D リスタート | 【4E 9D】リスタート |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9E_RF送信信号の制御.md` | リーダライタ制御コマンド | command_spec | high | medium | 4E 9E RF送信信号の制御 | 【4E 9E】RF送信信号の制御 |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_80_エラー情報の読み取り.md` | リーダライタ制御コマンド | command_spec | high | low | 4F 80 エラー情報の読み取り | 【4F 80】エラー情報の読み取り |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_90_ROMバージョンの読み取り.md` | リーダライタ制御コマンド | command_spec | high | low | 4F 90 ROMバージョンの読み取り | 【4F 90】ROMバージョンの読み取り |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_38_使用アンテナ番号の書き込み.md` | リーダライタ制御コマンド | command_spec | high | medium | 55 38 使用アンテナ番号の書き込み | 【55 38】使用アンテナ番号の書き込み |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_44_UHF_CheckAntenna.md` | リーダライタ制御コマンド | command_spec | high | low | 55 44 UHF_CheckAntenna | 【55 44】UHF_CheckAntenna |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_46_UHF_GetHandle.md` | リーダライタ制御コマンド | command_spec | high | low | 55 46 UHF_GetHandle | 【55 46】UHF_GetHandle |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_48_使用アンテナ番号の読み取り.md` | リーダライタ制御コマンド | command_spec | high | low | 55 48 使用アンテナ番号の読み取り | 【55 48】使用アンテナ番号の読み取り |
| `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_90_チップバージョンの読み取り.md` | リーダライタ制御コマンド | command_spec | high | low | 55 90 チップバージョンの読み取り | 【55 90】チップバージョンの読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_00-10_リーダライタ動作モードの書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 4E 00-10 リーダライタ動作モードの書き込み | 【4E 00-10】リーダライタ動作モードの書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_9F_汎用ポート値の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 4E 9F 汎用ポート値の書き込み | 【4E 9F】汎用ポート値の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_A0_拡張ポート値の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 4E A0 拡張ポート値の書き込み | 【4E A0】拡張ポート値の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_B4_FLASH設定値の書き込み(1バイトアクセス).md` | リーダライタ設定コマンド | command_spec | high | high | 4E B4 FLASH設定値の書き込み(1バイトアクセス) | 【4E B4】FLASH設定値の書き込み(1バイトアクセス) |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_00_リーダライタ動作モードの読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 4F 00 リーダライタ動作モードの読み取り | 【4F 00】リーダライタ動作モードの読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_9F_汎用ポート値の読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 4F 9F 汎用ポート値の読み取り | 【4F 9F】汎用ポート値の読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_A0_拡張ポート値の読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 4F A0 拡張ポート値の読み取り | 【4F A0】拡張ポート値の読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_B4_FLASH設定値の読み取り(1バイトアクセス).md` | リーダライタ設定コマンド | command_spec | high | low | 4F B4 FLASH設定値の読み取り(1バイトアクセス) | 【4F B4】FLASH設定値の読み取り(1バイトアクセス) |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_30_UHF_SetSelectParam.md` | リーダライタ設定コマンド | command_spec | high | low | 55 30 UHF_SetSelectParam | 【55 30】UHF_SetSelectParam |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_31_UHF_SetInventoryParam.md` | リーダライタ設定コマンド | command_spec | high | low | 55 31 UHF_SetInventoryParam | 【55 31】UHF_SetInventoryParam |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_32_UHF_SetExpandSelectParam.md` | リーダライタ設定コマンド | command_spec | high | low | 55 32 UHF_SetExpandSelectParam | 【55 32】UHF_SetExpandSelectParam |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_00_アンテナ切替設定の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 33 00 アンテナ切替設定の書き込み | 【55 33 00】アンテナ切替設定の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_01_出力設定の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 33 01 出力設定の書き込み | 【55 33 01】出力設定の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_02_周波数設定の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 33 02 周波数設定の書き込み | 【55 33 02】周波数設定の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md` | リーダライタ設定コマンド | command_spec | high | high | 55 33 03 Accessパスワードの書き込み | 【55 33 03】Accessパスワードの書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_04_RFタグ通信関連パラメータの書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 33 04 RFタグ通信関連パラメータの書き込み | 【55 33 04】RFタグ通信関連パラメータの書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_05_EPC(UII)関連パラメータの書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 33 05 EPC(UII)関連パラメータの書き込み | 【55 33 05】EPC(UII)関連パラメータの書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_37_外部アンテナ自動切替設定の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 37 外部アンテナ自動切替設定の書き込み | 【55 37】外部アンテナ自動切替設定の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_39_RSSIフィルタ設定の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 39 RSSIフィルタ設定の書き込み | 【55 39】RSSIフィルタ設定の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_3A_アンテナ個別送信出力設定の書き込み.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 3A アンテナ個別送信出力設定の書き込み | 【55 3A】アンテナ個別送信出力設定の書き込み |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_40_UHF_GetSelectParam.md` | リーダライタ設定コマンド | command_spec | high | low | 55 40 UHF_GetSelectParam | 【55 40】UHF_GetSelectParam |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_41_UHF_GetInventoryParam.md` | リーダライタ設定コマンド | command_spec | high | low | 55 41 UHF_GetInventoryParam | 【55 41】UHF_GetInventoryParam |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_42_UHF_GetExpandSelectParam.md` | リーダライタ設定コマンド | command_spec | high | low | 55 42 UHF_GetExpandSelectParam | 【55 42】UHF_GetExpandSelectParam |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_00_アンテナ切替設定の読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 55 43 00 アンテナ切替設定の読み取り | 【55 43 00】アンテナ切替設定の読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_01_出力設定の読み取り.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 43 01 出力設定の読み取り | 【55 43 01】出力設定の読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_02_周波数設定の読み取り.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 43 02 周波数設定の読み取り | 【55 43 02】周波数設定の読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_04_RFタグ通信関連パラメータの読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 55 43 04 RFタグ通信関連パラメータの読み取り | 【55 43 04】RFタグ通信関連パラメータの読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_05_EPC(UII)関連パラメータの読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 55 43 05 EPC(UII)関連パラメータの読み取り | 【55 43 05】EPC(UII)関連パラメータの読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_47_外部アンテナ自動切替設定の読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 55 47 外部アンテナ自動切替設定の読み取り | 【55 47】外部アンテナ自動切替設定の読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_49_RSSIフィルタ設定の読み取り.md` | リーダライタ設定コマンド | command_spec | high | low | 55 49 RSSIフィルタ設定の読み取り | 【55 49】RSSIフィルタ設定の読み取り |
| `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_4A_アンテナ個別送信出力設定の読み取り.md` | リーダライタ設定コマンド | command_spec | high | medium | 55 4A アンテナ個別送信出力設定の読み取り | 【55 4A】アンテナ個別送信出力設定の読み取り |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_10_UHF_Inventory.md` | RFタグ通信コマンド | command_spec | high | low | 55 10 UHF_Inventory | 【55 10】UHF_Inventory |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_14_UHF_InventoryRead.md` | RFタグ通信コマンド | command_spec | high | low | 55 14 UHF_InventoryRead | 【55 14】UHF_InventoryRead |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_15_UHF_Read.md` | RFタグ通信コマンド | command_spec | high | low | 55 15 UHF_Read | 【55 15】UHF_Read |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md` | RFタグ通信コマンド | command_spec | high | medium | 55 16 UHF_Write | 【55 16】UHF_Write |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md` | RFタグ通信コマンド | command_spec | high | critical | 55 17 UHF_Kill | 【55 17】UHF_Kill |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_18_UHF_Lock.md` | RFタグ通信コマンド | command_spec | high | high | 55 18 UHF_Lock | 【55 18】UHF_Lock |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1A_UHF_BlockWrite.md` | RFタグ通信コマンド | command_spec | high | medium | 55 1A UHF_BlockWrite | 【55 1A】UHF_BlockWrite |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1B_UHF_BlockErase.md` | RFタグ通信コマンド | command_spec | high | high | 55 1B UHF_BlockErase | 【55 1B】UHF_BlockErase |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1D_UHF_BlockWrite2.md` | RFタグ通信コマンド | command_spec | high | medium | 55 1D UHF_BlockWrite2 | 【55 1D】UHF_BlockWrite2 |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1E_UHF_Encode.md` | RFタグ通信コマンド | command_spec | high | high | 55 1E UHF_Encode | 【55 1E】UHF_Encode |
| `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md` | RFタグ通信コマンド | command_spec | high | high | 55 FF UHF_ThroughCmd | 【55 FF】UHF_ThroughCmd |
| `07_command_format_コマンドフォーマット/7.6_nack_error_codes/7.6_NACKレスポンスとエラーコード.md` | NACKレスポンスとエラーコード | error_code_spec | high | medium |   | 7.6 NACKレスポンスとエラーコード |
| `08_rf_tag_control_RFタグ制御方法/08_RFタグ制御方法_概要.md` | 章概要 | chapter_overview | high | low |   | 08_RFタグ制御方法_概要 |
| `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | low |   | 8.1_RFタグのデータを自動読み取りモードで読み取る |
| `08_rf_tag_control_RFタグ制御方法/8.2_RFタグのデータをコマンド制御で読み取る.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | low |   | 8.2_RFタグのデータをコマンド制御で読み取る |
| `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | low |   | 8.3_SelectコマンドとTarget_A_B自動切替を使用しない |
| `08_rf_tag_control_RFタグ制御方法/8.4_RFタグにデータを書き込む.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | low |   | 8.4_RFタグにデータを書き込む |
| `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | high |   | 8.5_RFタグにパスワードを書き込む |
| `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | low |   | 8.6_RFタグのメモリをロックする |
| `08_rf_tag_control_RFタグ制御方法/8.7_RFタグのメモリロックを解除する.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | low |   | 8.7_RFタグのメモリロックを解除する |
| `08_rf_tag_control_RFタグ制御方法/8.8_複数のリーダライタを同じ周波数で動作させる.md` | RFタグ制御方法 / 実用手順 | chapter_section | high | low |   | 8.8_複数のリーダライタを同じ周波数で動作させる |
| `09_flash_FLASH/09_FLASH_概要.md` | 章概要 | chapter_overview | high | low |   | 09_FLASH_概要 |
| `09_flash_FLASH/9.1_FLASHアドレス一覧.md` | FLASH / アドレス一覧 / 設定値 | chapter_section | high | low |   | 9.1_FLASHアドレス一覧 |
| `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md` | 参考資料 / 換算表 | chapter_section | medium | low |   | 10.1.1_電力のdBmとmWの換算表 |
| `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md` | 参考資料 / 符号付き整数 / RSSI | chapter_section | medium | low |   | 10.1.2_符号付き16進数整数と10進数の変換 |
| `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md` | 参考資料 / 実測値 / Q値 | chapter_section | medium | low |   | 10.2.1_Q値設定とRFタグ枚数による読取時間および精度 |
| `10_reference_参考資料/10.2_reference_measurements/10.2.2_各種コマンドの実行時間.md` | 参考資料 / 実測値 / コマンド実行時間 | chapter_section | medium | low |   | 10.2.2_各種コマンドの実行時間 |
| `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md` | 参考資料 / 実測値 / Inventoriedフラグ | chapter_section | medium | low |   | 10.2.3_Inventoried_S1フラグの保持時間 |
| `10_reference_参考資料/10_参考資料_概要.md` | 章概要 | chapter_overview | high | low |   | 10_参考資料_概要 |
| `99_change_history_変更履歴/99_変更履歴.md` | 変更履歴 / 版管理 | appendix_history | medium | low |   | 99_変更履歴 |
| `README.md` | README.md | readme | high | low |   | UTR版 Markdown 知識ベース README |

## RAG検索キーワード（最適化）

UTR / UTR-S201 / R2000 / RAG / ファイル一覧 / マニフェスト / YAML front matter / 検索キーワード

