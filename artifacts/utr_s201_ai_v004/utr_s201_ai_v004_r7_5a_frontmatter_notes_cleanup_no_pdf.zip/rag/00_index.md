---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: UTR版 Markdown 知識ベース index
topic: 全体インデックス
chapter: '00'
category: 00_index.md
chunk_type: index
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Inventory
- UHF_Read
- UHF_Write
- PDF
- TDR
- MNL
- PRC
- AI
- FLASH
- UTRX
- SUM
- ACK
- NACK
- ACK_NACK
- RF
- RAM
- RSSI_ANGLE
- USB
- LAN
- COM
- LED
- TID
- SL
- EPC
- UII
- STX
- ETX
- CR
- 通信フォーマット
- 通信インターフェース
- 動作モード
- コマンドモード
- 自動読み取りモード
- リーダライタ
- RFタグ
- アンテナ
- アンテナ番号
- キャリアセンス
- 電波法
- インベントリ
- レスポンス
- MemBank
- RSSI
- ANGLE
- Q値
- Session
- Inventoried
- Target
- SLフラグ
- Kill
- Lock
- Read
- Write
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- Bluetooth
- Wi-Fi
- COMポート
- 有線LAN
- USB Type-C
- UART
- RS-232C
- UHF連続インベントリモード
- データ長
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Inventory
- UHF_Read
- UHF_Write
- FLASH
- ACK
- NACK
- ACK_NACK
- Kill
- Lock
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 00_index.md
optimized_path: 00_index.md
source_chapters:
- 全章
---
# UTR版 Markdown 知識ベース index

対象PDF: `TDR-MNL-PRC-UTR-S201-117 / UTR-S201シリーズ 通信プロトコル説明書 / Ver.1.17`

このindexは、生成AIがどのMarkdownを参照すべきか判断しやすいように、章別の目的、検索キーワード、ファイル一覧をまとめたものです。

## 全体方針

- 共通仕様は第1章〜第6章を参照します。
- 個別コマンド仕様は第7章を参照します。
- 実運用の流れは第8章を参照します。
- FLASH設定値や参考値は第9章〜第10章を参照します。

## 00_common_knowledge_共通知識

目的: 章をまたいで必要になる前提知識、注意事項、混同防止ルールを先に確認する。

主な検索キーワード: UTR / UTRX / R2000 / 通信フォーマット / SUM / ACK / NACK / FLASH / Kill / Lock / アンテナ番号 / キャリアセンス / 電波法

ファイル:
- `00_common_knowledge_共通知識/00_index.md`
- `00_common_knowledge_共通知識/01_UTRシリーズ概要.md`
- `00_common_knowledge_共通知識/02_対象機種とインターフェース.md`
- `00_common_knowledge_共通知識/03_動作モード.md`
- `00_common_knowledge_共通知識/04_通信フォーマット.md`
- `00_common_knowledge_共通知識/05_SUM計算方法.md`
- `00_common_knowledge_共通知識/06_ACK_NACKレスポンス.md`
- `00_common_knowledge_共通知識/07_コマンド逆引き.md`
- `00_common_knowledge_共通知識/08_機種別_バージョン別_対応表.md`
- `00_common_knowledge_共通知識/09_RFタグメモリ構造.md`
- `00_common_knowledge_共通知識/10_RAM値とFLASH値.md`
- `00_common_knowledge_共通知識/11_アンテナ番号.md`
- `00_common_knowledge_共通知識/12_キャリアセンスと電波法注意.md`
- `00_common_knowledge_共通知識/13_RSSI_ANGLE値の読み方.md`
- `00_common_knowledge_共通知識/14_危険操作_Kill_Lock_FLASH初期化.md`
- `00_common_knowledge_共通知識/15_UTRとUTRXの違い.md`

## 第1章 通信インターフェース

目的: 機種別の通信インターフェース、上位機器からの見え方、接続方式を確認する。

参照ページ: 9-14

主な検索キーワード: 通信インターフェース / USB / 有線LAN / Wi-Fi / Bluetooth / COMポート / ソケット通信

ファイル:
- `01_interface_通信インターフェース/01_interface_通信インターフェース.md`

## 第2章 リーダライタの動作モード

目的: コマンドモード、自動読み取りモード、モード遷移、起動時の考え方を確認する。

参照ページ: 15-20

主な検索キーワード: 動作モード / コマンドモード / 連続インベントリモード / 連続インベントリリードモード

ファイル:
- `02_operation_modes_動作モード/02_operation_modes_動作モード.md`

## 第3章 リーダライタの機能

目的: キャリア、アンチコリジョン、LED、タイムアウト、TID付加読み取り、RAM/FLASH値などを確認する。

参照ページ: 21-76

主な検索キーワード: キャリア / アンチコリジョン / Q値 / タイムアウト / Target A/B / TID付加読み取り / RAM値 / FLASH値

ファイル:
- `03_reader_functions_リーダライタ機能/03_reader_functions_リーダライタ機能.md`

## 第4章 RFタグの機能

目的: RFタグの状態遷移、Session、Inventoriedフラグ、SLフラグ、メモリ構造を確認する。

参照ページ: 77-96

主な検索キーワード: RFタグ / Session / Inventoried / SLフラグ / MemBank / EPC / UII / TID / User領域

ファイル:
- `04_rf_tag_functions_RFタグ機能/04_rf_tag_functions_RFタグ機能.md`

## 第5章 通信フォーマット

目的: STX、アドレス、コマンド、データ長、データ部、ETX、SUM、CRの共通フォーマットを確認する。

参照ページ: 97-101

主な検索キーワード: 通信フォーマット / STX / ETX / SUM / CR / ACK / NACK / レスポンス

ファイル:
- `05_frame_format_通信フォーマット/05_frame_format_通信フォーマット.md`

## 第6章 コマンド一覧・対応表

目的: コマンド一覧、コマンド逆引き、リーダライタ別対応可否を確認する。

参照ページ: 102-116

主な検索キーワード: コマンド一覧 / 逆引き表 / 対応表 / リーダライタ制御コマンド / 設定コマンド / RFタグ通信コマンド

ファイル:
- `06_command_list_対応表/06_command_list_対応表.md`

## 第7章 コマンドフォーマット

目的: 個別コマンドの送信フォーマット、ACK/NACK、パラメータ、レスポンス仕様を確認する。

参照ページ: 117-319

主な検索キーワード: コマンドフォーマット / UHF_Inventory / UHF_Read / UHF_Write / ACK / NACK / エラーコード

ファイル:
- `07_command_format_コマンドフォーマット/7.1_uhf_continuous_inventory/7.1_uhf_continuous_inventory.md`
- `07_command_format_コマンドフォーマット/7.2_uhf_continuous_inventory_read/7.2_uhf_continuous_inventory_read.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/42_ブザーの制御.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_57_LED&ブザーの制御.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9D_リスタート.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_9E_RF送信信号の制御.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_80_エラー情報の読み取り.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_90_ROMバージョンの読み取り.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_38_使用アンテナ番号の書き込み.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_44_UHF_CheckAntenna.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_46_UHF_GetHandle.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_48_使用アンテナ番号の読み取り.md`
- `07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_90_チップバージョンの読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_00-10_リーダライタ動作モードの書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_9F_汎用ポート値の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_A0_拡張ポート値の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_B4_FLASH設定値の書き込み(1バイトアクセス).md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_00_リーダライタ動作モードの読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_9F_汎用ポート値の読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_A0_拡張ポート値の読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_B4_FLASH設定値の読み取り(1バイトアクセス).md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_30_UHF_SetSelectParam.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_31_UHF_SetInventoryParam.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_32_UHF_SetExpandSelectParam.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_00_アンテナ切替設定の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_01_出力設定の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_02_周波数設定の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_03_Accessパスワードの書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_04_RFタグ通信関連パラメータの書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_33_05_EPC(UII)関連パラメータの書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_37_外部アンテナ自動切替設定の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_39_RSSIフィルタ設定の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_3A_アンテナ個別送信出力設定の書き込み.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_40_UHF_GetSelectParam.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_41_UHF_GetInventoryParam.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_42_UHF_GetExpandSelectParam.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_00_アンテナ切替設定の読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_01_出力設定の読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_02_周波数設定の読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_04_RFタグ通信関連パラメータの読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_43_05_EPC(UII)関連パラメータの読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_47_外部アンテナ自動切替設定の読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_49_RSSIフィルタ設定の読み取り.md`
- `07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_4A_アンテナ個別送信出力設定の読み取り.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_10_UHF_Inventory.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_14_UHF_InventoryRead.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_15_UHF_Read.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_18_UHF_Lock.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1A_UHF_BlockWrite.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1B_UHF_BlockErase.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1D_UHF_BlockWrite2.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1E_UHF_Encode.md`
- `07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_FF_UHF_ThroughCmd.md`
- `07_command_format_コマンドフォーマット/7.6_nack_error_codes/7.6_nack_error_codes.md`
- `07_command_format_コマンドフォーマット/07_command_format_コマンドフォーマット_概要.md`

## 第8章 RFタグ制御方法

目的: 読み取り、書き込み、パスワード、ロック、複数リーダライタ運用などの実用手順を確認する。

参照ページ: 320-345

主な検索キーワード: RFタグ制御 / 自動読み取り / コマンド制御 / Select / 書き込み / パスワード / ロック / 周波数

ファイル:
- `08_rf_tag_control_RFタグ制御方法/8.1_RFタグのデータを自動読み取りモードで読み取る.md`
- `08_rf_tag_control_RFタグ制御方法/8.2_RFタグのデータをコマンド制御で読み取る.md`
- `08_rf_tag_control_RFタグ制御方法/8.3_SelectコマンドとTarget_A_B自動切替を使用しない.md`
- `08_rf_tag_control_RFタグ制御方法/8.4_RFタグにデータを書き込む.md`
- `08_rf_tag_control_RFタグ制御方法/8.5_RFタグにパスワードを書き込む.md`
- `08_rf_tag_control_RFタグ制御方法/8.6_RFタグのメモリをロックする.md`
- `08_rf_tag_control_RFタグ制御方法/8.7_RFタグのメモリロックを解除する.md`
- `08_rf_tag_control_RFタグ制御方法/8.8_複数のリーダライタを同じ周波数で動作させる.md`
- `08_rf_tag_control_RFタグ制御方法/08_rf_tag_control_RFタグ制御方法_概要.md`

## 第9章 FLASH

目的: FLASHアドレス一覧、設定値の保存先、初期化や書き込み時の注意点を確認する。

参照ページ: 346-353

主な検索キーワード: FLASH / FLASHアドレス / 設定値 / 初期化 / RAM値

ファイル:
- `09_flash_FLASH/9.1_FLASHアドレス一覧.md`
- `09_flash_FLASH/09_flash_FLASH_概要.md`

## 第10章 参考資料

目的: dBm/mW換算、符号付き16進数変換、Q値とタグ枚数、実行時間、フラグ保持時間の参考値を確認する。

参照ページ: 354-360

主な検索キーワード: dBm / mW / 符号付き16進数 / Q値 / 読取時間 / 実行時間 / Inventoried

ファイル:
- `10_reference_参考資料/10.1_conversion_tables/10.1.1_電力のdBmとmWの換算表.md`
- `10_reference_参考資料/10.1_conversion_tables/10.1.2_符号付き16進数整数と10進数の変換.md`
- `10_reference_参考資料/10.2_reference_measurements/10.2.1_Q値設定とRFタグ枚数による読取時間および精度.md`
- `10_reference_参考資料/10.2_reference_measurements/10.2.2_各種コマンドの実行時間.md`
- `10_reference_参考資料/10.2_reference_measurements/10.2.3_Inventoried_S1フラグの保持時間.md`
- `10_reference_参考資料/10_reference_参考資料_概要.md`

## 変更履歴

目的: 原本マニュアルの改版履歴を確認する。

参照ページ: 361-362

主な検索キーワード: 変更履歴 / 改版履歴 / マニュアル履歴

ファイル:
- `99_change_history_変更履歴/99_change_history_変更履歴.md`

## 生成AI回答時の共通注意

- コマンドのバイト列を提示する場合は、各バイトの意味も説明してください。
- SUM値を扱う場合は、第5章のSUM計算方法を確認してください。
- ACK/NACKやエラーコードを説明する場合は、第7章のNACKレスポンスとエラーコードを参照してください。
- 書き込み、Kill、Lock、FLASH操作は、実行前に対象タグ、対象機種、現在設定、復旧方法を確認してください。
- このMarkdownは二次加工データのため、正式回答や実機投入前には原本PDFと照合してください。

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UHF_Inventory / UHF_Read / UHF_Write / PDF / TDR / MNL / PRC / AI / FLASH / UTRX / SUM / ACK / NACK / ACK_NACK / RF / RAM / RSSI_ANGLE / USB / LAN / COM / LED / TID / SL / EPC / UII / STX / ETX / CR / 通信フォーマット / 通信インターフェース / 動作モード / コマンドモード / 自動読み取りモード / リーダライタ / RFタグ / アンテナ / アンテナ番号 / キャリアセンス / 電波法 / インベントリ / レスポンス / MemBank / RSSI / ANGLE / Q値 / Session
