---
title: "GitHub USB版サンプル 最新状態"
category: "github_reference"
chunk_type: "implementation_status"
rag_priority: "high"
risk_level: "medium"
source_type: "verified_github_sample"
source_priority_rank: 3
repo: "TamaruNorio/UTR_USB_Python_CodeX"
branch: "main"
model_specific: true
cross_model_reuse: "prohibited"
source_of_truth: "official_pdf"
---

# GitHub USB版サンプル 最新状態

GitHub USB版は、UTR-S201シリーズ向けPython実装例です。
仕様正本ではなく、実装例・実機確認済み挙動として参照します。

## 標準Inventory入口

- `src/utr_usb_sample.py`
- 実行例: `py .\src\utr_usb_sample.py`
- USBシリアル接続、ROM確認、コマンドモード切替、Inventory、必要に応じた送信出力一時変更を扱います。
- 送信出力一時変更は、現時点では UTR-SUN02-4CH / USM02 を対象とします。
- 変更送信前に復元計画を保持し、例外時も `finally` 側で復元を試みます。

## 8CH順次Inventory入口

- `src/utr_8ch_sequential_inventory_cli.py`
- 実行例: `py .\src\utr_8ch_sequential_inventory_cli.py`
- 対象: UTR-SUN02-8CH / USM08
- 開始前に使用アンテナ番号を読み取り、終了時に開始前設定へ自動復元します。
- Ctrl+Cや例外時も、可能な範囲でシリアルクローズ前に復元します。
- 復元前に受信バッファをクリアし、ACK/NACK以外を受信した場合は1回だけ再試行します。

## AI参照時の注意

- PDF正本を最終根拠とします。
- GitHub実装を他機種へ横展開しないでください。
- UTR-S201とUTR-S202を同一仕様と仮定しないでください。
- UTR-SUN02-8CH / USM08 のアンテナ番号体系を UTR-SUN02V-8CH / USM06 へ流用しないでください。
- USB版接続処理をLAN版へそのまま流用しないでください。

