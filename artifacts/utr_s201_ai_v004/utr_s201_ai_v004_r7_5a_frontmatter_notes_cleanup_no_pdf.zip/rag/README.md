---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: UTR版 Markdown 知識ベース README
topic: README
chapter: 全体
category: README.md
chunk_type: readme
rag_priority: high
risk_level: low
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- README
- TDR
- MNL
- PRC
- AI
- RAG
- PDF
- ACK
- NACK
- SUM
- UTF
- UTR_S201_protocol_md_RAG
- RF
- FLASH
- YAML
- UTRX
- ACK_NACK
- RAM
- COM
- LAN
- USB
- STX
- ETX
- 通信フォーマット
- 通信インターフェース
- 動作モード
- コマンドモード
- 自動読み取りモード
- リーダライタ
- RFタグ
- アンテナ
- アンテナ番号
- キャリアセンス
- 電波法
- レスポンス
- Q値
- Session
- Inventoried
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- Bluetooth
- Wi-Fi
- COMポート
- 有線LAN
- USB Type-C
- UART
- RS-232C
- UHF連続インベントリモード
- CR
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- 設定保存
- FLASH設定値
aliases:
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- ACK
- NACK
- FLASH
- ACK_NACK
- FLASH設定値
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: README.md
optimized_path: README.md
source_chapters:
- 全章
---
# UTR版 Markdown 知識ベース

このフォルダは、`TDR-MNL-PRC-UTR-S201-117 / UTR-S201シリーズ 通信プロトコル説明書 / Ver.1.17` を、生成AIのRAG・Skill用途で扱いやすいように整理したMarkdown一式です。

## 目的

PDFの本文をそのまま長文として扱うのではなく、章・節・コマンド単位に分割し、生成AIが必要な情報を検索しやすい形にしています。

主な用途は以下です。

- UTRシリーズの通信仕様を生成AIに参照させる
- コマンド送信バイト列、レスポンス、ACK/NACK、SUM計算の説明に使う
- Python、C++、C#などのサンプル実装を作るときの根拠資料にする
- 実機確認時の前提、注意点、切り分け観点を整理する
- 技術問い合わせ対応、技術メモ、RAG、Skillの元データにする

## 対象資料

```text
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_version: 1.17
manual_date: 2025-06-16
series: UTR
chipset: R2000
language: ja
encoding: UTF-8
```

## フォルダ構成

```text
UTR_S201_protocol_md_RAG/
├─ README.md
├─ 00_index.md
├─ index_chapters.yaml
├─ 01_interface_通信インターフェース/  # 第1章 通信インターフェース
├─ 02_operation_modes_動作モード/  # 第2章 リーダライタの動作モード
├─ 03_reader_functions_リーダライタ機能/  # 第3章 リーダライタの機能
├─ 04_rf_tag_functions_RFタグ機能/  # 第4章 RFタグの機能
├─ 05_frame_format_通信フォーマット/  # 第5章 通信フォーマット
├─ 06_command_list_対応表/  # 第6章 コマンド一覧・対応表
├─ 07_command_format_コマンドフォーマット/  # 第7章 コマンドフォーマット
├─ 08_rf_tag_control_RFタグ制御方法/  # 第8章 RFタグ制御方法
├─ 09_flash_FLASH/  # 第9章 FLASH
├─ 10_reference_参考資料/  # 第10章 参考資料
├─ 99_change_history_変更履歴/  # 変更履歴
```

## 章別ファイル数

| 章 | タイトル | フォルダ | Markdown数 | 参照ページ |
|---|---|---:|---:|---:|
| 第1章 | 通信インターフェース | `01_interface_通信インターフェース/` | 1 | 9-14 |
| 第2章 | リーダライタの動作モード | `02_operation_modes_動作モード/` | 1 | 15-20 |
| 第3章 | リーダライタの機能 | `03_reader_functions_リーダライタ機能/` | 1 | 21-76 |
| 第4章 | RFタグの機能 | `04_rf_tag_functions_RFタグ機能/` | 1 | 77-96 |
| 第5章 | 通信フォーマット | `05_frame_format_通信フォーマット/` | 1 | 97-101 |
| 第6章 | コマンド一覧・対応表 | `06_command_list_対応表/` | 1 | 102-116 |
| 第7章 | コマンドフォーマット | `07_command_format_コマンドフォーマット/` | 58 | 117-319 |
| 第8章 | RFタグ制御方法 | `08_rf_tag_control_RFタグ制御方法/` | 9 | 320-345 |
| 第9章 | FLASH | `09_flash_FLASH/` | 2 | 346-353 |
| 第10章 | 参考資料 | `10_reference_参考資料/` | 6 | 354-360 |
| 変更履歴 | 変更履歴 | `99_change_history_変更履歴/` | 1 | 361-362 |

合計Markdownファイル数: 100

※ 上記の章別Markdownに加え、共通知識Markdown 16ファイル、`README.md`、`00_index.md`を含めた合計は100ファイルです。`index_chapters.yaml`はYAMLファイルとして別管理です。

## 共通知識フォルダ

`00_common_knowledge_共通知識/` には、章をまたいで参照する前提知識をまとめています。

| ファイル群 | 用途 |
|---|---|
| UTRシリーズ概要 / 対象機種 / 接続方式 | 対象機種、通信方式、UTR/UTRX混同防止の入口 |
| 通信フォーマット / SUM / ACK_NACK | コマンド生成・レスポンス解析の共通ルール |
| コマンド逆引き / 機種別バージョン別対応表 | 質問から参照すべき個別コマンドを探す |
| RFタグメモリ / RAM値とFLASH値 / アンテナ番号 | 実装時に混同しやすい概念の整理 |
| キャリアセンスと電波法注意 / 危険操作 | 実機確認前に必ず確認する注意事項 |

## 分割方針

- 説明中心の章は、章または節単位で分割しています。
- 第7章のコマンド仕様は、RAGで検索しやすいようにコマンド単位を中心に分割しています。
- 第8章以降の実用手順・参考資料は、節単位で分割しています。
- 各Markdownには、可能な範囲で要約、用途、重要ポイント、実機確認時の注意、RAG検索キーワードを入れています。

## RAGでの推奨使い方

質問内容に応じて、以下の優先順位で参照してください。

| 質問内容 | 優先参照先 |
|---|---|
| 接続方式、COMポート、LAN、USB、Bluetooth、Wi-Fi | 第1章 |
| 起動時の状態、コマンドモード、自動読み取りモード | 第2章 |
| キャリア、Q値、タイムアウト、アンテナ切替、RAM/FLASH | 第3章 |
| RFタグの状態、Session、Inventoried、メモリ構造 | 第4章 |
| STX、ETX、SUM、ACK/NACK、通信フレーム | 第5章 |
| どのコマンドを使うか、機種別対応可否 | 第6章 |
| 個別コマンドの送信フォーマット、レスポンス仕様 | 第7章 |
| 実運用での読み取り、書き込み、ロック、複数台運用 | 第8章 |
| FLASHアドレス、設定値保存 | 第9章 |
| 換算表、実測値、参考値 | 第10章 |

## 注意

このMarkdownはRAG・Skill向けの二次加工データです。実機制御コード、顧客提出資料、量産手順で使う場合は、必ず原本PDFの該当ページと照合してください。

特に、RFタグへの書き込み、Kill、Lock、FLASH書き込み、FLASH初期化に関する操作は、実機・RFタグ・設定値へ不可逆または復旧困難な影響を与える可能性があります。生成AIの回答をそのまま実行せず、原本仕様、対象機種、RFタグ仕様、現場条件を確認してください。

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / README / TDR / MNL / PRC / AI / RAG / PDF / ACK / NACK / SUM / UTF / UTR_S201_protocol_md_RAG / RF / FLASH / YAML / UTRX / ACK_NACK / RAM / COM / LAN / USB / STX / ETX / 通信フォーマット / 通信インターフェース / 動作モード / コマンドモード / 自動読み取りモード / リーダライタ / RFタグ / アンテナ / アンテナ番号 / キャリアセンス / 電波法 / レスポンス / Q値 / Session / Inventoried / 通信 / インターフェース / シリアル通信 / TCP/IP


## v004 H追加: 再分割RAGチャンク

- `rag/commands/`: 主要コマンドを1ファイル1コマンドに近い単位で整理した検索用入口です。
- `rag/safety/`: FLASH、送信出力、周波数、InventoryParam、アンテナ制御、PC+UIIマスク、不明時回答の安全ポリシーです。
- `03_structured_data/rag_metadata_schema_v004_h.yml`: RAG front matter の必須項目と推奨項目です。
