---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 30】UHF_SetSelectParam
topic: リーダライタ設定コマンド
chapter: '07'
source_section: 7.4.17
source_pages: 191-196
category: リーダライタ設定コマンド
chunk_type: command_spec
rag_priority: high
risk_level: high
command_name: UHF_SetSelectParam
command_code: 55h
detail_command: 30h
command_label: 55 30
operation_type: write_setting
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_SET_SELECT_PARAM
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_SET_SELECT_PARAM
executable_hex_output: prohibited
checksum_policy: placeholder_only
automatic_send_allowed: false
requires_actual_device_check: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_SetSelectParam
- UHF_SetInventoryParam
- RAM
- FLASH
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- RF
- RFU
- EPC
- UII
- TID
- SL
- AB
- 55H
- 30H
- 02H
- 00H
- 01H
- 81H
- 通信フォーマット
- コマンドモード
- 自動読み取りモード
- リーダライタ
- RFタグ
- レスポンス
- MemBank
- Inventoried
- Target
- 55 30
- '5530'
- '55_30'
- 55h 30h
- UHF SetSelectParam
- uhf_setselectparam
- 55h
- 30h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- CR
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 31h
- エラーコード
- 異常応答
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_SetSelectParam
- UHF_SetInventoryParam
- FLASH
- ACK
- NACK
- 55H
- 55 30
- '5530'
- '55_30'
- 55h 30h
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【55 30】UHF_SetSelectParam.md
optimized_path: 07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_30_UHF_SetSelectParam.md
---
# 【55 30】UHF_SetSelectParam

    ## コマンドの要約

    UHF_SetSelectParamに関する設定値を書き込むコマンドです。RAM、FLASH、または指定パラメータ種別への反映条件を確認してから使用します。

    ## 何に使うコマンドか

    UHF_SetSelectParamの設定を上位機器から変更するために使います。現場調整では、変更前後の読み取り確認とログ保存が重要です。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.4.17 |
    | 参照ページ | 191-196 |
    | コマンド区分 | リーダライタ設定コマンド |
    | コマンドラベル | 55 30 |
    | コマンド | 55h |
    | 詳細コマンド / サブ情報 | 30h |
    | 操作種別 | write_setting |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 書き込み先がRAMかFLASHかを必ず確認する。
- FLASH書き込みは設定が保持されるため、実行前に値を控える。
- 不正パラメータ時はNACKとなるため、範囲・予約ビット・機種対応を確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    UHF_SetSelectParam, 55 30, 55h, 30h, リーダライタ設定コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

190 

7.4.17 UHF_SetSelectParam 
RFタグへのSelectコマンドで送信するパラメータの設定コマンドです。 
このコマンドは、リーダライタへの設定コマンドです。本コマンドを実行しても、リーダライタか
らのSelectコマンドの送信はおこなわれません。 
Selectコマンドの送信のタイミングについては、「3.10 RFタグ通信コマンド実行時のリーダライタ
の内部処理」をご参照ください。 
※[UHF_SetInventoryParam]コマンドで「Selectコマンド：使用する」に設定されている場合は、
本コマンドで「マスクbit数」=[0]としてもSelectコマンドは発行されます。 
（「マスクbit数」=[0]、「マスクデータ」=[empty]のSelectコマンドが発行されます） 

［コマンド］ 
（次ページへ続く） 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
9+n 
データ部 
1 
30h（詳細コマンド） 
1 
パラメータ種類 ※1 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
1 
パラメータ1 ［初期値：81h］ 
bit0 
bit1 
MemBank ※左側が上位bit 
00 
：RFU 
01 
：EPC(UII) ［初期値］ 
10 
：TID 
11 
：User 
bit2-4 
Action 値 ［初期値：000］ 
詳細はパラメータ説明参照 
bit5-7 
Target 値 ※左側が上位bit 
000 
：Inventoried(S0) 
001 
：Inventoried(S1) 
010 
：Inventoried(S2) 
011 
：Inventoried(S3) 
100 
：SL ［初期値］ 
101 
：Reserved 
110 
：Reserved 
111 
：Reserved 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

191 

（前ページからの続き） 
※1：パラメータ種類の詳細は「3.12.1 パラメータ種類」をご参照ください。 


● Select コマンドについて 
リーダライタが「Select コマンドを使用する」の設定となっている場合、RF タグ読み取り時の
Inventory 処理中に、リーダライタからRF タグに対して[Select]コマンドが実行されます。[Select]
コマンドにより、指定した条件を満たすRF タグのみを選択(または除外)することができます。 
(例) EPC が[AB 12]h で始まるRF タグのみを選択する場合 
※EPC は、EPC 領域のWord アドレス[02]h（ビットアドレス[20]h）から始まります 
→EPC 領域のビットアドレス[20]h から16[bit]が[AB 12]h, Action 値=000(0), Target 値=[S0]を
指定します。 
※Action 値=000(0)の状態遷移 … 一致: [A]に遷移、不一致: [B]に遷移 
→EPC が[AB 12]で始まるRF タグはS0=[A]に、[AB 12]で始まらないRF タグはS0=[B]に遷移
します。 
※S1 やSL など、Target 値で指定していないフラグは遷移しません 

EPC 
Select コマンド 
実行前 
Mask 条件への 
[一致]／[不一致] 
Select コマンド 
実行後 
RF タグ1 
AB12 0021… 
S0=[A], S1=[A], 
S2=[B], S3=[A] 
一致 
S0=[A], S1=[A], 
S2=[B], S3=[A] 
RF タグ2 
CD35 2200… 
S0=[A], S1=[A], 
S2=[B], S3=[A] 
不一致 
S0=[B], S1=[A], 
S2=[B], S3=[A] 
RF タグ3 
ABCD 1234… 
S0=[B], S1=[B], 
S2=[A], S3=[B] 
不一致 
S0=[B], S1=[B], 
S2=[A], S3=[B] 


ラベル名 
バイト数 
内容 
データ部 
1 
パラメータ2 ［初期値：00h］ 
bit0 
bit1 
将来拡張のための予約（通常は0） 
bit2 
Truncate 値（0 固定） 
0 
：Disable［初期値］ 
1 
：Enable（未サポート） 
bit3-7 
将来拡張のための予約（通常は0） 
4 
マスク開始ビットアドレス ［初期値: 00 00 00 00］h 
※MSB ファースト、ビット単位で指定 
1 
マスクbit 数 
※最大128[bit] (=80[h])まで 
(n) 
マスクデータ 
マスクbit 数で指定した長さのマスクデータ 
※「マスクbit 数」=[0]の場合は省略(n=0) 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

192 

● MemBank 
[Select]コマンドの対象のメモリ領域を指定します。（FLASH 初期値：EPC(UII)） 
詳細は、「4.2 RF タグのメモリ構造」の項を参照ください。 
・RFU 
ISO18000-63 規格上の予約領域です。現在使用することはできません 
※RF タグのメモリ領域の[00h: Reserved]とは異なります。 
 →Kill Password やAccess Password を「マスク条件」とすることはできません。 

・EPC(UII) 
ビットアドレス[00]h からCRC (16[bit]) + PC (16[bit]) 
ビットアドレス[20]h からEPC(UII) 
・TID 
ビットアドレス[00]h からRF タグのユニークなID 領域（一般的には64[bit]または96[bit]） 
・USER 
ビットアドレス[00]h からユーザメモリ 


● Action 値 
「マスク条件」で指定した内容に[一致]／[不一致]のRF タグに対し、「Target 値」で指定した
フラグの状態をそれぞれどのように変化させるかを指定するパラメータです。 
（FLASH 初期値：000） 
※「Target 値」で指定したフラグのみ変化します。 


Action 
※左側がMSB 
()内は10 進数 
Matching 
（マスク条件が一致） 
Non-Matching 
（マスク条件が不一致） 
Inventoried 
フラグが対象 
SL フラグ 
が対象 
Inventoried 
フラグが対象 
SL フラグ 
が対象 
000 
(0) 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
001 
(1) 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
なにもしない 
010 
(2) 
なにもしない 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
011 
(3) 
Inventoried フラグ 
を反転 
※[A]なら[B]へ 
※[B]なら[A]へ 
SL フラグを 
反転 
なにもしない 
100 
(4) 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
101 
(5) 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
なにもしない 
110 
(6) 
なにもしない 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
111 
(7) 
なにもしない 
Inventoried フラグ 
を反転 
※[A]なら[B]へ 
※[B]なら[A]へ 
SL フラグを 
反転 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

193 

(例1) 「Target 値」=[SL]、「Action 値」=[000(0)]の場合 
※Action 値=000(0)のSL フラグの遷移 → [一致]：SL=[Set]、[不一致]：SL=[Reset] 
・「Target 値」=[SL]なので、「SL フラグ」のみが遷移します。 
  ・マスク条件に[一致]のRF タグは、SL=[Set]となります。 
  ・マスク条件に[不一致]のRF タグは、SL=[Reset]となります。 
・「Inventoried フラグ」は遷移しません。 

マスク条件への 
[一致]／[不一致] 
Select コマンド 
実行前 
Select コマンド 
実行後 
RF タグ1 
一致 
S0=[A], S1=[A], S2=[A],  
S3=[A], SL=[Reset] 
S0=[A], S1=[A], S2=[A],  
S3=[A], SL=[Set] 
RF タグ2 
一致 
S0=[A], S1=[A], S2=[B],  
S3=[A], SL=[Set] 
S0=[A], S1=[A], S2=[B],  
S3=[A], SL=[Set] 
RF タグ3 
不一致 
S0=[A], S1=[B], S2=[A],  
S3=[B], SL=[Reset] 
S0=[A], S1=[B], S2=[A],  
S3=[B], SL=[Reset] 
RF タグ4 
不一致 
S0=[A], S1=[A], S2=[B],  
S3=[B], SL=[Set] 
S0=[A], S1=[A], S2=[B],  
S3=[B], SL=[Reset] 

(例2) 「Target 値」=[SL]、「Action 値」=[001(1)]の場合 
※Action 値=001(1)のSL フラグの遷移 → [一致]：SL=[Set]、[不一致]：SL=[なにもしない] 
・「Target 値」=[SL]なので、「SL フラグ」のみが遷移します。 
・「Inventoried フラグ」は遷移しません。 

マスク条件への 
[一致]／[不一致] 
Select コマンド 
実行前 
Select コマンド 
実行後 
RF タグ1 
一致 
S0=[A], S1=[A], S2=[A],  
S3=[A], SL=[Reset] 
S0=[A], S1=[A], S2=[A],  
S3=[A], SL=[Set] 
RF タグ2 
一致 
S0=[A], S1=[A], S2=[B],  
S3=[A], SL=[Set] 
S0=[A], S1=[A], S2=[B],  
S3=[A], SL=[Set] 
RF タグ3 
不一致 
S0=[A], S1=[B], S2=[A],  
S3=[B], SL=[Reset] 
S0=[A], S1=[B], S2=[A],  
S3=[B], SL=[Reset] 
RF タグ4 
不一致 
S0=[A], S1=[A], S2=[B],  
S3=[B], SL=[Set] 
S0=[A], S1=[A], S2=[B],  
S3=[B], SL=[Set] 

(例3) 「Target 値」=[S2]、「Action 値」=[100(4)]の場合 
※Action 値=001(1)のInventory フラグ(S2)の遷移 → [一致]：S2=[B]、不一致：S2=[A] 
・「Target 値」=[S2]なので、「Inventoried(S2)フラグ」のみが遷移します。 
・「SL フラグ」やS2 以外の「Inventoried フラグ」は遷移しません。 

マスク条件への 
[一致]／[不一致] 
Select コマンド 
実行前 
Select コマンド 
実行後 
RF タグ1 
一致 
S0=[A], S1=[A], S2=[A],  
S3=[A], SL=[Reset] 
S0=[A], S1=[A], S2=[B],  
S3=[A], SL=[Reset] 
RF タグ2 
一致 
S0=[A], S1=[A], S2=[B],  
S3=[A], SL=[Set] 
S0=[A], S1=[A], S2=[B],  
S3=[A], SL=[Set] 
RF タグ3 
不一致 
S0=[A], S1=[B], S2=[A],  
S3=[B], SL=[Reset] 
S0=[A], S1=[B], S2=[A],  
S3=[B], SL=[Reset] 
RF タグ4 
不一致 
S0=[A], S1=[A], S2=[B],  
S3=[B], SL=[Set] 
S0=[A], S1=[A], S2=[A],  
S3=[B], SL=[Set] 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

194 

● Target 値 
Select コマンドを受けたRF タグが、「Inventoried フラグ」または「SL フラグ」のどちらを遷
移させるかを指定します。（FLASH 初期値：SL） 
また、「Inventoried フラグ」の場合はさらに、4 つのセッション(S0, S1, S2, S3)のうちどのセッ
ションが対象かを指定します。 
RF タグは、Select コマンドで指定した「マスク条件」への[一致]／[不一致]に応じて、「Action
値」で指定した状態遷移をおこないます。 

● Truncate 値（FLASH 初期値：Disable） 
・Select コマンドのコマンドパラメータ中のTruncate の値を設定します。 
・UTR-S201 シリーズは、「Truncate 値」は[Disable]のみ対応しています。[Enable]を指定して
も設定や実動作に反映されません。 

● マスク開始bit アドレス（FLASH 初期値：[00 00 00 00]h） 
MemBank で指定したメモリ領域の、マスク条件を設定する開始bit アドレスを指定します。 
※ Word アドレスではなく、bit アドレスで指定します。 
※ 0 [Word]目の最上位bit がbit アドレス[00]h、最下位bit がbit アドレス[0F]h です。 

● マスクbit 数 
マスク開始bit アドレスから開始して、マスクするbit 長を指定します。 
上限128[bit]まで指定することができます。（FLASH 初期値：0） 
「Select コマンド使用」=[使用する]の場合、「マスクbit 数」=[0]を設定した場合でも、 
「マスクbit 数=0」、「マスクデータ」=[empty]の[Select]コマンドが発行されます。 

● マスクデータ 
マスクデータを「byte 単位」で指定します。 
上限16[byte]まで指定することができます。（FLASH 初期値：0） 
※マスクビット数が8 の倍数にならない場合は、上位bit からbyte 単位で区切り、 
端数となるbyte 内では下位bit にデータを詰めて、上位bit は0 埋めします。 
(例1) TID 領域の先頭28[bit]が[E2 80 11 7]の条件でマスクする場合 
※ [E2 80 11 7]h=[1110 0010 1000 0000 0001 0001 0111]b 
byte 単位で区切った場合、下位[4bit]の[0111]b が端数byte となります。 
8[bit]に満たない最下位byte は、上位4[bit]を0 埋めし、[0000 0111]b (=07h)とします。 
マスクデータは、[E2 80 11 07]h となります。（※[E2 80 11 70]h ではありません） 
＜コマンド例＞ 
[TX] 02 00 55 0D 30 00 82 00 00 00 00 00 1C E2 80 11 07 03 AF 0D 

(例2) EPC 領域のビットアドレス[10]h から5[bit] ([10]h-[14]h: EPC Length)が[00110]b の 
条件でマスクする場合 
指定したマスクbit 数(=5)が8[bit]に満たないため、上位3[bit]を0 埋めして、 
[0000 0110]b (=[06]h)とします。マスクデータは、[06]h となります。 
＜コマンド例＞ 
[TX] 02 00 55 0A 30 00 81 00 00 00 00 10 05 06 03 30 0D 
7 [byte]目 :[81]h … Target=SL(=[100]b), Action 値=0 (=[000]b), MemBank=EPC (=[01]b) 
8 [byte]目 :[00]h … Truncate 値=0 (Disable) 
9-12 [byte]目 : [00 00 00 10]h … マスク開始ビットアドレス 
13 [byte]目 : [05]h … マスクbit 数(=5) 
14 [byte]目 : [06]h … マスクデータ 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

195 

［ACK レスポンス］ 

［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
(例1) 以下のパラメータを書き込む場合 
データ種類 
数値／パラメータ 
コマンド列 
書き込み対象 
FLASH データ 
02 
MemBank 
EPC(UII) 
81 
Action 値 
000(0) 
Target 値 
SL 
Truncate 値 
Disable 
00 
マスク開始ビットアドレス 
[20]h 
00 00 00 20 
マスクbit 数 
96 
60 
マスクデータ 
E2 00 68 0A 00 00 40 02 3C 25 39 17 
同左 
• 
コマンド 
02 00 55 15 30 02 81 00 00 00 00 20 60 E2 00 68 0A 00 00 40 02 3C 25 39 17 03 E9 0D 
• 
レスポンス 
02 00 30 01 30 03 66 0D 

(例2) 以下のパラメータを書き込む場合（マスクを使用しない場合） 
データ種類 
数値／パラメータ 
コマンド列 
書き込み対象 
コマンドモード用パラメータ 
00 
MemBank 
EPC(UII) 
41 
Action 値 
000(0) 
Target 値 
S2 
Truncate 値 
Disable 
00 
マスク開始ビットアドレス 
[00]h 
00 00 00 00 
マスクbit 数 
0 
00 
マスクデータ 
[empty] 
― 
• 
コマンド 
02 00 55 09 30 00 41 00 00 00 00 00 00 03 D4 0D 
• 
レスポンス 
02 00 30 01 30 03 66 0D 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
01h 
データ部 
1 
30h（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_SetSelectParam / UHF_SetInventoryParam / RAM / FLASH / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / RF / RFU / EPC / UII / TID / SL / AB / 55H / 30H / 02H / 00H / 01H / 81H / 通信フォーマット / コマンドモード / 自動読み取りモード / リーダライタ / RFタグ / レスポンス / MemBank / Inventoried / Target / 55 30 / 5530 / 55_30 / 55h 30h / UHF SetSelectParam
