---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 40】UHF_GetSelectParam
topic: リーダライタ設定コマンド
chapter: '07'
source_section: 7.4.2
source_pages: 154-156
category: リーダライタ設定コマンド
chunk_type: command_spec
rag_priority: high
risk_level: low
command_name: UHF_GetSelectParam
command_code: 55h
detail_command: 40h
command_label: 55 40
operation_type: read_setting
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_GetSelectParam
- UHF_SetSelectParam
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- FLASH
- CR
- RFU
- EPC
- UII
- TID
- SL
- MSB
- 55H
- 40H
- 02H
- 00H
- 01H
- 03H
- 0DH
- 30H
- 81H
- 通信フォーマット
- コマンドモード
- 自動読み取りモード
- リーダライタ
- レスポンス
- MemBank
- Inventoried
- Target
- 55 40
- '5540'
- '55_40'
- 55h 40h
- UHF GetSelectParam
- uhf_getselectparam
- 55h
- 40h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_GetSelectParam
- UHF_SetSelectParam
- ACK
- NACK
- FLASH
- 55H
- 55 40
- '5540'
- '55_40'
- 55h 40h
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【55 40】UHF_GetSelectParam.md
optimized_path: 07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_40_UHF_GetSelectParam.md
---
# 【55 40】UHF_GetSelectParam

    ## コマンドの要約

    UHF_GetSelectParamに関する現在値または設定値を読み取るコマンドです。アプリケーション起動時の設定確認、実機状態の見える化、設定変更前のバックアップ確認に使います。

    ## 何に使うコマンドか

    UHF_GetSelectParamの現在設定を上位機器側で取得し、画面表示・ログ出力・設定差分確認に利用します。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.4.2 |
    | 参照ページ | 154-156 |
    | コマンド区分 | リーダライタ設定コマンド |
    | コマンドラベル | 55 40 |
    | コマンド | 55h |
    | 詳細コマンド / サブ情報 | 40h |
    | 操作種別 | read_setting |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 読み取り系コマンドのため、原則として設定値は変更しない。
- ACKレスポンスのデータ部を解析して現在値を取得する。
- NACK時は7.6のエラーコードを確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    UHF_GetSelectParam, 55 40, 55h, 40h, リーダライタ設定コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

153 

7.4.2 
UHF_GetSelectParam 
Selectコマンド用のパラメータ値の取得をおこなうコマンドです。 

［コマンド］ 
※1：パラメータ種類の詳細は「3.12.1 パラメータ種類」をご参照ください。 


ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
02h 
データ部 
1 
40h（詳細コマンド） 
1 
パラメータ種類 ※1 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

154 

［ACK レスポンス］ 
※取得した値の説明は、「7.4.12 UHF_SetSelectParam」をご参照ください。 


ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
9+n 
データ部 
1 
40h（詳細コマンド） 
1 
パラメータ種類 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
1 
パラメータ1 （初期値：81h） 
bit0-1 
MemBank ※左側が上位bit 
00 
：RFU 
01 
：EPC(UII)［初期値］ 
10 
：TID 
11 
：User 
bit2-4 
Action 値 ［初期値：000］ 
※左側が上位bit、詳細はパラメータ説明参照 
bit5-7 
Select のTarget 値 ※左側が上位bit 
000 
：Inventoried(S0) 
001 
：Inventoried(S1) 
010 
：Inventoried(S2) 
011 
：Inventoried(S3) 
100 
：SL［初期値］ 
101 
：Reserved 
110 
：Reserved 
111 
：Reserved 
1 
パラメータ2 （初期値：00h） 
bit0-1 
将来拡張のための予約（通常は0） 
bit2 
Truncate 値（0 固定） 
0 
：Disable［初期値］ 
1 
：Enable（未サポート） 
bit3-7 
将来拡張のための予約（通常は0） 
4 
マスク開始ビットアドレス ［初期値：[00 00 00 00]h］ 
※MSB ファースト 
1 
マスクbit 数 ［初期値：00h］ 
※最大128[bit]まで (=[80]h) 
(n) 
マスクデータ 
※「マスクbit 数」で指定した長さのマスクデータ 
※「マスクbit 数」=0 の場合は省略(n=0) 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

155 

［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
• コマンド 
02 00 55 02 40 00 03 9C 0D 
• レスポンス 
02 00 30 09 40 00 81 00 00 00 00 00 00 03 FF 0D 

バイト位置 
レスポンス 
パラメータ 
3 [byte]目 
[30]h ・ACK 応答 
4 [byte]目 
[09]h ・データ長 = 9 
5 [byte]目 
[40]h ・詳細コマンド…[UHF_GetSelectParam] 
6 [byte]目 
[00]h ・パラメータ種類=[コマンドモード用パラメータ] 
7 [byte]目 
[81]h 
・Select のTarget 値=[SL] 
・Action 値=[000(0)] 
・MemBank = EPC(UII) 
8 [byte]目 
[00]h ・Truncate 値=[0: Disable] 
9-12 [byte]目 
[00 00 00 00]h ←マスク開始ビットアドレス 
13 [byte]目 
[00]h ・マスクbit 数 = 0
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_GetSelectParam / UHF_SetSelectParam / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / FLASH / CR / RFU / EPC / UII / TID / SL / MSB / 55H / 40H / 02H / 00H / 01H / 03H / 0DH / 30H / 81H / 通信フォーマット / コマンドモード / 自動読み取りモード / リーダライタ / レスポンス / MemBank / Inventoried / Target / 55 40 / 5540 / 55_40 / 55h 40h
