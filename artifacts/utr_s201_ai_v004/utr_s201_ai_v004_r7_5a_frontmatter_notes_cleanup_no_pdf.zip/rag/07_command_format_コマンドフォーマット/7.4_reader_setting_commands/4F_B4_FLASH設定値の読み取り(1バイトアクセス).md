---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【4F B4】FLASH設定値の読み取り(1バイトアクセス)
topic: リーダライタ設定コマンド
chapter: '07'
source_section: 7.4.13
source_pages: '182'
category: リーダライタ設定コマンド
chunk_type: command_spec
rag_priority: high
risk_level: low
command_name: FLASH設定値の読み取り(1バイトアクセス)
command_code: 4Fh
detail_command: B4h
command_label: 4F B4
operation_type: read_setting
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- FLASH
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- FF
- CR
- 4FH
- B4H
- 02H
- 00H
- 03H
- 0DH
- 30H
- 通信フォーマット
- リーダライタ
- レスポンス
- Write
- 4F B4
- 4FB4
- 4F_B4
- 4Fh B4h
- FLASH設定値の読み取り(1バイトアクセス)
- flash設定値の読み取り(1バイトアクセス)
- 4Fh
- B4h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- UHF_Write
- 書き込み
- EPC書き換え
- WordPtr
- WriteData
- RAM
- 設定保存
- FLASH設定値
- 電源再投入
- 初期化
- チップバージョン
- RF-ASIC
aliases:
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- FLASH
- ACK
- NACK
- 4FH
- 4F B4
- 4FB4
- 4F_B4
- 4Fh B4h
- FLASH設定値の読み取り(1バイトアクセス)
- 4Fh
- UHF_Write
- FLASH設定値
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【4F B4】FLASH設定値の読み取り(1バイトアクセス).md
optimized_path: 07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4F_B4_FLASH設定値の読み取り(1バイトアクセス).md
---
# 【4F B4】FLASH設定値の読み取り(1バイトアクセス)

    ## コマンドの要約

    FLASH設定値(1バイトアクセス)に関する現在値または設定値を読み取るコマンドです。アプリケーション起動時の設定確認、実機状態の見える化、設定変更前のバックアップ確認に使います。

    ## 何に使うコマンドか

    FLASH設定値(1バイトアクセス)の現在設定を上位機器側で取得し、画面表示・ログ出力・設定差分確認に利用します。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.4.13 |
    | 参照ページ | 182 |
    | コマンド区分 | リーダライタ設定コマンド |
    | コマンドラベル | 4F B4 |
    | コマンド | 4Fh |
    | 詳細コマンド / サブ情報 | B4h |
    | 操作種別 | read_setting |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 読み取り系コマンドのため、原則として設定値は変更しない。
- ACKレスポンスのデータ部を解析して現在値を取得する。
- NACK時は7.6のエラーコードを確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    FLASH設定値の読み取り(1バイトアクセス), 4F B4, 4Fh, B4h, リーダライタ設定コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

181 

7.4.13 FLASH 設定値の読み取り(1 バイトアクセス) 
FLASH設定値をアドレス単位（1 バイト単位）で読み取るコマンドです。 
FLASHアドレスの一覧は、「9.1 FLASHアドレス一覧」をご参照ください。 

［コマンド］ 


［ACK レスポンス］ 


［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
FLASH のアドレス94([5B]h)に格納されている、「Write コマンドタイムアウト時間(msec)」を 
読み取った結果、[14]h (=20) が返ってきた場合 
• コマンド 
02 00 4F 02 B4 5B 03 65 0D 
↑ アドレス94 (=[5B]h) 
• レスポンス 
02 00 30 02 B4 14 03 FF 0D 
↑ FLASH 設定値 [14]h (=20) 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
4Fh 
データ長 
1 
02h 
データ部 
1 
B4h（詳細コマンド） 
1 
読み取りアドレス 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 
ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
ACK 
1 
30h（ACK） 
データ長 
1 
02h 
データ部 
1 
B4h（詳細コマンド） 
1 
FLASH 設定値 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / FLASH / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / FF / CR / 4FH / B4H / 02H / 00H / 03H / 0DH / 30H / 通信フォーマット / リーダライタ / レスポンス / Write / 4F B4 / 4FB4 / 4F_B4 / 4Fh B4h / FLASH設定値の読み取り(1バイトアクセス) / flash設定値の読み取り(1バイトアクセス) / 4Fh / B4h / 通信 / インターフェース / シリアル通信 / TCP/IP / USB / Bluetooth / Wi-Fi / COMポート / データ長
