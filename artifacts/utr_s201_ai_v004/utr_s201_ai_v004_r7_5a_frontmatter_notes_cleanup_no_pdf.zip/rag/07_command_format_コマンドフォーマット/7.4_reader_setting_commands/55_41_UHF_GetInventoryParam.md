---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: "1.17"
manual_date: "2025-06-16"
language: ja
encoding: UTF-8
public_protocol: true
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
source_of_truth: PDF正本
markdown_role: AI参照補助資料
markdown_is_authoritative: false
requires_pdf_verification_for_final_answer: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
  - UTR-S201
  - UTR-SHR201
do_not_confuse_with:
  - UTRXシリーズ
  - TR3XMシリーズ
  - TR3Xシリーズ
  - UTR-S101シリーズ
  - MS710/E710系チップセット
title: 【55 41】UHF_GetInventoryParam
topic: リーダライタ設定コマンド
chapter: "07"
source_section: "7.4.3"
source_pages: "157-160"
category: リーダライタ設定コマンド
chunk_type: command_spec
chunk_profile: command_single
rag_priority: high
risk_level: low
safety_class: read_setting_no_persistent_change
command_name: UHF_GetInventoryParam
command_code: 55h
detail_command: 41h
command_label: "55 41"
operation_type: read_inventory_parameter
writes_to_reader_setting: false
writes_to_flash: false
writes_to_tag_memory: false
persistent_effect: false
requires_explicit_user_permission: false
ai_code_generation: allowed_with_caution
parameter_kinds:
  "00h": コマンドモード用パラメータ
  "01h": 自動読み取りモード用パラメータ
  "02h": FLASHデータ
related_commands:
  paired_write_command: UHF_SetInventoryParam
  affected_inventory_command: UHF_Inventory
  response_reference: NACKレスポンスとエラーコード
primary_retrieval_questions:
  - UTR-S201のInventoryパラメータ現在値を読むにはどのコマンドを使うか
  - UHF_GetInventoryParamのACKに含まれるパラメータ1から4の意味は何か
  - Q値、Session、Target、MemBankの現在設定を確認するにはどうするか
keywords:
  - UHF_GetInventoryParam
  - 55 41
  - 55_41
  - 5541
  - Inventoryパラメータ取得
  - コマンドモード用パラメータ
  - 自動読み取りモード用パラメータ
  - FLASHデータ読み取り
  - Q値確認
  - Session確認
  - Target確認
  - MemBank確認
  - Select使用確認
  - TID付加確認
search_boost_terms:
  - UHF_GetInventoryParam
  - "55 41"
  - "55h 41h"
  - パラメータ1
  - パラメータ2
  - パラメータ3
  - パラメータ4
negative_keywords:
  - UHF_SetInventoryParam
  - 書き込み
  - 変更
  - 送信出力
  - 周波数設定
  - TR3XM
  - UTRX
aliases:
  - GetInventoryParam
  - InventoryParam読み取り
  - インベントリパラメータ読み取り
  - 設定確認
optimized_path: rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_41_UHF_GetInventoryParam.md
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【55 41】UHF_GetInventoryParam.md
optimization_note: v004 C工程で読み取り専用コマンドとして明示し、対応する書き込みコマンドとの差別化メタデータを追加。
---

# 【55 41】UHF_GetInventoryParam

## このファイルの役割

このMarkdownは、UTR-S201シリーズの `UHF_GetInventoryParam` を生成AIが参照しやすくするための補助資料です。正本はPDFの通信プロトコル説明書です。数値、ビット定義、対応機種の最終判断はPDF正本で確認してください。

## コマンドの要約

`UHF_GetInventoryParam` は、RFタグ読み取り時のInventory処理に使用するパラメータを取得する読み取り系コマンドです。設定値の確認、画面表示、ログ保存、設定変更前のバックアップ確認に使います。

## AIが誤読しやすい点

| 誤読しやすい点 | 正しい扱い |
|---|---|
| `Get` と `Set` を混同する | `55 41` は読み取り。`55 31` が書き込み。 |
| FLASHデータ取得をFLASH書き込みと誤解する | パラメータ種類 `02h` はFLASHデータを読む指定であり、書き込みではありません。 |
| ACKのデータ部を単なるバイト列として扱う | パラメータ1〜4はbit fieldとして解析します。 |
| 取得値を根拠に自動で変更コードまで生成する | 読み取りと変更は分離します。変更は明示許可が必要です。 |

## 基本情報

| 項目 | 内容 |
|---|---|
| コマンド名 | UHF_GetInventoryParam |
| コマンドラベル | 55 41 |
| コマンド | 55h |
| 詳細コマンド | 41h |
| 操作種別 | read_inventory_parameter |
| 危険度 | low |
| 永続設定変更 | なし |
| 対応する書き込みコマンド | UHF_SetInventoryParam / 55 31 |
| 参照章 | 7.4.3 |
| 参照ページ | 157-160 |

## パラメータ種類

| 値 | 意味 | 注意 |
|---|---|---|
| 00h | コマンドモード用パラメータ | コマンドモード時のInventory条件確認 |
| 01h | 自動読み取りモード用パラメータ | 連続読み取り等の条件確認 |
| 02h | FLASHデータ | 不揮発設定の現在値確認。読み取りのみ。 |

## ACKレスポンス解析の要点

| フィールド | 主な意味 |
|---|---|
| パラメータ1 | Select使用、Q値自動UP/DOWN、アンチコリジョン、Q開始値、Target |
| パラメータ2 | Session、Sel、TRext、M、DR |
| パラメータ3 | Q最小値、Q最大値 |
| パラメータ4 | MemBank、TID付加、予約bit |
| 読み取り開始Wordアドレス | RFタグメモリ上の読み取り開始位置 |
| 読み取りWord数 | 読み取りするWord数 |

## 生成AI向け実装ガード

- 読み取り専用として扱い、設定変更処理を同じ関数に混ぜないでください。
- ACKレスポンスのbit fieldは、PDF正本または構造化データ `03_structured_data/uhf_inventory_param_bitfields.yml` と照合してください。
- パラメータ種類 `02h` を扱う場合でも、これはFLASH値の読み取りであり、FLASH書き込みではありません。
- NACK時は、NACKレスポンスとエラーコードの章を参照してください。

## RAG検索用の短い説明

UTR-S201のInventoryパラメータを読み取るコマンド。`55 41`。Q値、Session、Target、MemBank、TID付加などの現在値確認に使う。対応する書き込みコマンドは `55 31`。

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

156 

7.4.3 
UHF_GetInventoryParam 
RFタグ読み取り時のインベントリ処理に使用するパラメータの取得をおこなうコマンドです。 

［コマンド］ 
※1：パラメータ種類の詳細は「3.12.1 パラメータ種類」をご参照ください。 


ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
02h 
データ部 
1 
41h（詳細コマンド） 
1 
パラメータ種類 ※1 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

157 

［ACK レスポンス］ 
（次ページへ続く） 


ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
0Bh 
データ部 
1 
41h（詳細コマンド） 
1 
パラメータ種類 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
1 
パラメータ1 （初期値：1Fh） 
bit0 
Select コマンドの使用 
0 
：使用しない 
1 
：使用する［初期値］ 
bit1 
Q 値の自動UP/DOWN 機能 
0 
：使用しない 
1 
：使用する［初期値］ 
bit2 
アンチコリジョン機能 
0 
：使用しない 
1 
：使用する［初期値］ 
bit3-6 
Q 値の開始値 
0～15 ［初期値：3(0011b)］ 
※bit3 をLSB とする4[bit]の数値 
bit7 
Inventory のTarget 
0 
：A［初期値］ 
1 
：B 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

158 

（前ページからの続き） 
（次ページへ続く） 


ラベル名 
バイト数 
内 容 
データ部 
1 
パラメータ2 （初期値：DCh） 
bit0-1 
Session 値 ※左側が上位bit 
00 
：S0［初期値］ 
01 
：S1 
10 
：S2 
11 
：S3 
bit2-3 
Sel 値 ※左側が上位bit 
00 
：ALL 
01 
：ALL 
10 
：^SL 
11 
：SL［初期値］ 
bit4 
TRext 値 
0 
：No pilot tone （未サポート） 
1 
：Use pilot tone ［初期値］ 
bit5-6 
M 値 ※左側が上位bit 
00 
：M1(FM0) （未サポート） 
01 
：M2 （未サポート） 
10 
：M4 ［初期値］ 
11 
：M8 （未サポート） 
bit7 
DR 値 
0 
：8 （未サポート） 
1 
：64/3 ［初期値］ 
1 
パラメータ3 （初期値：81h） 
bit0-3 
Q 値の最小値 
0～15 ［初期値：1 (0001b)］ 
※bit0 をLSB とする4[bit]の数値 
bit4-7 
Q 値の最大値 
0～15 ［初期値：8 (1000b)］  
※bit4 をLSB とする4[bit]の数値 
1 
パラメータ4 （初期値：02h） 
bit0-1 
MemBank ※左側が上位bit 
00 
：Reserved 
01 
：EPC(UII) 
10 
：TID ［初期値］ 
11 
：User 
bit2 
TID 付加 
0 
：付加しない ［初期値］ 
1 
：付加する 
bit3-7 
将来拡張のための予約（通常は0） 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

159 

（前ページからの続き） 
※取得した値の説明は、「7.4.13 UHF_SetInventoryParam」をご参照ください。 


［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
• コマンド 
02 00 55 02 41 00 03 9D 0D 
• レスポンス 
02 00 30 0B 41 00 1F DC 81 02 00 00 00 00 02 03 01 0D 

バイト位置 
レスポンス 
パラメータ 
3 [byte]目 
[30]h ・ACK 応答 
4 [byte]目 
[0B]h ・データ長 = 11 
5 [byte]目 
[41]h ・詳細コマンド…[UHF_GetInventoryParam] 
6 [byte]目 
[00]h ・パラメータ種類=[コマンドモード用パラメータ] 
7 [byte]目 
[1F]h 
パラメータ1 
・Select コマンドの使用=[使用する] 
・Q 値の自動UP/DOWN 機能=[使用する] 
・アンチコリジョン機能=[使用する] 
・Q 値の開始値=[3] 
・Inventory のTarget=[A] 
8 [byte]目 
[DC]h 
パラメータ2 
・Session 値=[S0]、Sel 値=[SL] 
・TRext 値=[Use pilot tone] 
・M 値=[M4]、DR 値=[64/3] 
9 [byte]目 
[81]h パラメータ3 
・Q 値の最小値=[1]、Q 値の最大値=[8] 
10 [byte]目 
[02]h パラメータ4 
・MemBank=[TID]、TID 付加=[付加しない] 
11-14 [byte]目 
[00 00 00 00]h ←読み取り開始Word アドレス 
15 [byte]目 
[02]h ・読み取りWord 数 = 2 


ラベル名 
バイト数 
内 容 
データ部 
4 
読み取り開始Word アドレス （初期値：[00 00 00 00]h） 
RF タグのメモリ上の読み取り開始位置（Word 単位） 
※MSB ファーストで指定 
1 
読み取りWord 数 （初期値：02h） 
読み取りするWord 数（1～32） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_GetInventoryParam / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / RF / FLASH / CR / UP / DOWN / LSB / DCh / ALL / SL / TRext / FM0 / DR / 55H / 41H / 02H / 00H / 01H / 03H / 0DH / 30H / 0BH / 1FH / DCH / 81H / 通信フォーマット / コマンドモード / 自動読み取りモード / リーダライタ / RFタグ / インベントリ
