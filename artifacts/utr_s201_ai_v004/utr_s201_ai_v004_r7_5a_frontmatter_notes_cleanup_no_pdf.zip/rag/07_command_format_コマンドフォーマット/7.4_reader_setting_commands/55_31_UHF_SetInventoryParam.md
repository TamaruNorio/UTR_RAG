---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: "1.17"
manual_date: "2025-06-16"
language: ja
encoding: UTF-8
public_protocol: true
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
source_of_truth: PDF正本
markdown_role: AI参照補助資料
markdown_is_authoritative: false
requires_pdf_verification_for_final_answer: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
  - UTR-S201
  - UTR-SHR201
do_not_confuse_with:
  - UTRXシリーズ
  - TR3XMシリーズ
  - TR3Xシリーズ
  - UTR-S101シリーズ
  - MS710/E710系チップセット
title: 【55 31】UHF_SetInventoryParam
topic: リーダライタ設定コマンド
chapter: "07"
source_section: "7.4.18"
source_pages: "197-204"
category: リーダライタ設定コマンド
chunk_type: command_spec
chunk_profile: command_single
rag_priority: high
risk_level: high
safety_class: write_inventory_parameter_requires_permission
command_name: UHF_SetInventoryParam
command_code: 55h
detail_command: 31h
command_label: "55 31"
operation_type: write_inventory_parameter
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_SET_INVENTORY_PARAM
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_SET_INVENTORY_PARAM
executable_hex_output: prohibited
checksum_policy: placeholder_only
writes_to_reader_setting: true
writes_to_flash: conditional
writes_to_tag_memory: false
persistent_effect: conditional
requires_explicit_user_permission: true
ai_code_generation: explanation_only_by_default
automatic_send_allowed: false
requires_actual_device_check: true
safe_default_action: explain_and_request_pdf_verification
parameter_kinds:
  "00h": コマンドモード用パラメータへの反映
  "01h": 自動読み取りモード用パラメータへの反映
  "02h": FLASHデータへの反映
related_commands:
  paired_read_command: UHF_GetInventoryParam
  affected_inventory_command: UHF_Inventory
  safety_rules: 00_policy/safety_rules.yml
  structured_bitfields: 03_structured_data/uhf_inventory_param_bitfields.yml
primary_retrieval_questions:
  - UHF_SetInventoryParamをAIが勝手に送信してよいか
  - UTR-S201のInventoryパラメータを書き込む場合の危険点は何か
  - 55 31でRAMとFLASHのどちらに反映されるかをどう確認するか
keywords:
  - UHF_SetInventoryParam
  - 55 31
  - 55_31
  - 5531
  - Inventoryパラメータ設定
  - インベントリ条件変更
  - Q値設定
  - Session設定
  - Target設定
  - MemBank設定
  - TID付加設定
  - FLASHデータ
  - RAM値
  - 明示許可必要
  - 自動送信禁止
search_boost_terms:
  - UHF_SetInventoryParam
  - "55 31"
  - "55h 31h"
  - FLASHデータ
  - パラメータ種類02h
  - 自動送信禁止
  - 明示許可
negative_keywords:
  - UHF_GetInventoryParam
  - 読み取り専用
  - UHF_Inventory
  - TR3XM
  - UTRX
aliases:
  - SetInventoryParam
  - InventoryParam書き込み
  - インベントリパラメータ書き込み
  - インベントリ設定変更
optimized_path: rag/07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_31_UHF_SetInventoryParam.md
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【55 31】UHF_SetInventoryParam.md
optimization_note: v004 C工程でrisk_levelをlowからhighへ修正し、明示許可・自動送信禁止・FLASH条件をメタデータ化。
---

# 【55 31】UHF_SetInventoryParam

## このファイルの役割

このMarkdownは、UTR-S201シリーズの `UHF_SetInventoryParam` を生成AIが参照しやすくするための補助資料です。正本はPDFの通信プロトコル説明書です。数値、ビット定義、設定影響、対応機種の最終判断はPDF正本で確認してください。

## コマンドの要約

`UHF_SetInventoryParam` は、RFタグ読み取り時のInventory処理に使用するパラメータを設定する書き込み系コマンドです。Inventoryの読取挙動、Q値、Session、Target、MemBank、TID付加などに影響します。

## 安全上の扱い

このコマンドは、生成AIが自動で送信コードを作ってよいコマンドではありません。説明、仕様確認、差分確認、ドライラン用のフレーム生成までは可能ですが、実機へ送信する処理は田丸さんの明示許可、PDF正本確認、変更前値のバックアップ、復元手順の確認が必要です。

## AIが誤読しやすい点

| 誤読しやすい点 | 正しい扱い |
|---|---|
| v003ではrisk_level lowだったため安全な読取コマンドと誤認する | `55 31` は書き込み系。risk_levelはhighとして扱います。 |
| `55 41` と混同する | `55 41` は読み取り、`55 31` は書き込み。 |
| パラメータ種類 `02h` を軽く扱う | `02h` はFLASHデータへの反映を含むため、永続影響の確認が必要です。 |
| Inventoryサンプル内でついでに送る | 自動送信禁止。Inventory実行と設定変更は分離します。 |
| 予約bitや未サポート値を推測で埋める | 不明値は推測せず、PDF正本確認とします。 |

## 基本情報

| 項目 | 内容 |
|---|---|
| コマンド名 | UHF_SetInventoryParam |
| コマンドラベル | 55 31 |
| コマンド | 55h |
| 詳細コマンド | 31h |
| 操作種別 | write_inventory_parameter |
| 危険度 | high |
| 明示許可 | 必要 |
| 自動送信 | 禁止 |
| FLASH影響 | パラメータ種類により条件付きであり得る |
| 対応する読み取りコマンド | UHF_GetInventoryParam / 55 41 |
| 参照章 | 7.4.18 |
| 参照ページ | 197-204 |

## パラメータ種類

| 値 | 意味 | AI実装時の扱い |
|---|---|---|
| 00h | コマンドモード用パラメータ | 実機挙動に影響。明示許可が必要。 |
| 01h | 自動読み取りモード用パラメータ | 自動読み取り時の挙動に影響。明示許可が必要。 |
| 02h | FLASHデータ | 不揮発設定に影響する可能性があるため、原則として説明のみ。 |

## 書き込み前に必ず行う確認

1. `UHF_GetInventoryParam` で変更前値を読み取る。
2. 読み取った値をログ保存する。
3. 変更対象が `00h` / `01h` / `02h` のどれかを明示する。
4. PDF正本でbit定義、予約bit、未サポート値を確認する。
5. 実機へ送信するコードには、送信直前の確認プロンプトを入れる。
6. NACK、タイムアウト、SUM不一致時の復旧方針を決める。

## 生成AI向け実装ガード

- 明示許可なしに実機送信用コードを生成しないでください。
- サンプルコードを出す場合でも、初期状態では送信処理を無効化してください。
- `parameter_kind == 02h` はFLASH影響として扱い、通常のRAM一時変更と同列にしないでください。
- 予約bitは通常0とし、推測で1にしないでください。
- 変更後は必ず `UHF_GetInventoryParam` で読み戻し確認する前提にしてください。

## RAG検索用の短い説明

UTR-S201のInventoryパラメータを書き込むコマンド。`55 31`。Q値、Session、Target、MemBankなどの読取条件に影響するため、risk_level high。明示許可なしの自動送信は禁止。

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

196 

7.4.18 UHF_SetInventoryParam 
「コマンドモード」、「UHF連続インベントリモード」、および「UHF連続インベントリリードモ
ード」のインベントリ処理におけるパラメータの設定をおこなうコマンドです。 




［コマンド］ 
（次ページへ続く） 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
0Bh 
データ部 
1 
31h（詳細コマンド） 
1 
パラメータ種類 ※1 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
1 
パラメータ1 
bit0 
Select コマンドの使用 
0 
：使用しない 
1 
：使用する ［初期値］ 
bit1 
Q 値の自動UP/DOWN 機能 
0 
：使用しない 
1 
：使用する ［初期値］ 
bit2 
アンチコリジョン機能 
0 
：使用しない 
1 
：使用する ［初期値］ 
bit3-6 
Q 値の開始値 
0～15 ［初期値：3(0011b)］ 
※bit3 をLSB とする4[bit]の数値 
bit7 
Inventory のTarget 
0 
：A ［初期値］ 
1 
：B 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

197 

（前ページからの続き） 
（次ページへ続く） 


ラベル名 
バイト数 
内容 
データ部 
1 
パラメータ2 
bit0 
bit1 
Session 値 ※左側が上位bit 
00 
：S0 ［初期値］ 
01 
：S1 
10 
：S2 
11 
：S3 
bit2 
bit3 
Sel 値 ※左側が上位bit 
00 
：ALL 
01 
：ALL 
10 
：^SL 
11 
：SL ［初期値］ 
bit4 
TRext 値 
0 
：No pilot tone（未サポート） 
1 
：Use pilot tone［初期値］ 
bit5 
bit6 
M 値 ※左側が上位bit 
00 
：M1 （未サポート） 
01 
：M2 （未サポート） 
10 
：M4 ［初期値］ 
11 
：M8 （未サポート） 
bit7 
DR 値 
0 
：8 （未サポート） 
1 
：64/3 ［初期値］ 
1 
パラメータ3 
bit0-3 
Q 値の最小値 
0～15 ［初期値：1 (0001b)］ 
※bit0 をLSB とする4[bit]の数値 
bit4-7 
Q 値の最大値 
0～15 ［初期値：8 (1000b)］ 
※bit4 をLSB とする4[bit]の数値 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

198 

（前ページからの続き） 
※1：パラメータ種類の詳細は「3.12.1 パラメータ種類」をご参照ください。 


● Select コマンドの使用 （FLASH 初期値：使用する） 
RF タグ読み取り時のInventory 処理において、[Query]コマンド実行前に[Select]コマンドを発
行するかどうかを指定します。 
アンテナの読み取り範囲内にある、読み取り対象以外のRF タグを除外する際に使用します。読
み取り対象のRF タグのエンコードの方法を事前に決めて運用する必要があります。 
マスク条件を指定して[Select]コマンドをRF タグに対して実行すると、RF タグはマスク条件へ
の[一致]／[不一致]により、RF タグ内部の「Inventoried フラグ」または「SL フラグ」の状態を
遷移させます。 
その後、読み取りの対象フラグとフラグの状態を指定して[Query]コマンドを実行することで、
対象のRF タグのみを読み取りすることができます。 
・[使用する] 
リーダライタは、[Query]コマンド実行前に[Select]コマンドを発行します。 
Select コマンドのパラメータは、[UHF_SetSelectParam]コマンドで設定した内容が反映さ
れます。 
・[使用しない] 
リーダライタは、[Query]コマンド実行前に[Select]コマンドを発行しません。 


ラベル名 
バイト数 
内容 
データ部 
1 
パラメータ4 
bit0 
bit1 
MemBank ※左側が上位bit 
00 
：Reserved 
01 
：EPC(UII) 
10 
：TID［初期値］ 
11 
：User 
bit2 
TID 付加 
0 
：付加しない［初期値］ 
1 
：付加する 
bit3-7 
将来拡張のための予約（通常は0） 
4 
読み取り開始Word アドレス  初期値は[00 00 00 00]h 
RF タグのメモリ上の読み取り開始位置（Word 単位） 
※MSB ファーストで指定 
1 
読み取りWord 数  初期値は2 (02h) 
読み取りするWord 数（1～32） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

199 

● Q 値の自動UP/DOWN 機能 （FLASH 初期値：使用する） 
RF タグ読み取り時のInventory 処理中のアンチコリジョン処理において、リーダライタがRF
タグに対して指定するスロット数を、コリジョンの発生頻度により自動的に増減するための機能
です。 
「Q 値の自動UP/DOWN 機能」の詳細は、「3.2.3 Q 値の自動UP/DOWN 機能」をご参照くだ
さい。 
・[使用する] 
RF タグ読み取り時のアンチコリジョン処理において、コリジョンが発生したスロット数に
応じて、次回のアンチコリジョン処理の際のスロット数（Q 値）を、リーダライタ内部で動
的に切り替えます。 
・[使用しない] 
RF タグ読み取り時のアンチコリジョン処理で使用するスロット数（Q 値）は、リーダライ
タに設定された「Q 値の開始値」に固定されます。 
「Q 値の自動UP/DOWN 機能」を使用しない場合は、読み取り対象のRF タグの枚数に合
わせて、「Q 値の開始値」を適切に設定してください。 
「Q 値の開始値」を適切に設定しないと、RF タグを読みこぼしたり、アンチコリジョン処
理に時間が掛かったりする原因となります。 


● アンチコリジョン機能 （FLASH 初期値：使用する） 
・[使用する] 
Inventory 処理においてコリジョンが発生したスロットがあった場合、再度Inventory 処理を
おこない、応答を返すRF タグが無くなるまでアンチコリジョン処理を繰り返します。 
・[使用しない] 
Inventory 処理において、コリジョンが発生したスロットは、RF タグの読み取りをおこないま
せん。 
コリジョン処理を行わない分、読み取り速度が上がりますが、読み取り枚数にバラツキが発生
します。 
コリジョンが発生したことを検出しませんので、「Q 値の自動UP/DOWN 機能」も動作しな
くなります。Q 値の設定が適切でない場合には、読み取りが不安定になります。 


● Q 値の開始値 （FLASH 初期値：3） 
・RF タグ読み取り時のInventory 処理において、アンチコリジョン処理で使用するスロット数
（Q 値）の開始値を設定します。 
1 回のInventory 処理で読み取りをおこなうRF タグの枚数に応じて適切なQ 値の設定として
ください。 
※「Q 値の開始値」は、別途指定する「Q 値の最小値」、「Q 値の最大値」との大小関係が、「Q
値の最小値」≦「Q 値の開始値」≦「Q 値の最大値」となるように指定してください。上記の
大小関係とならない設定とした場合は、リーダライタからNACK 応答が返ります。 
※読み取るRF タグ枚数に対してスロット数が小さいと読みこぼす可能性があり、大きすぎると
処理時間が遅くなります。 
・Q 値の設定の詳細は、「3.2.2 Q 値設定」をご参照ください。 
＜注意事項＞Q=11 を超えるQ 値の制限 
UTR-S201 では、Q=12 以上に設定した場合、Inventory 処理時間が4 秒を超える可能性が
高く、電波法の制限により処理の途中でキャリアOFF となる可能性があるため、 
Q=12 以上を設定した場合であっても、Q=11 の設定でInventory 処理を実行します。 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

200 

● Inventory のTarget （FLASH 初期値：A） 
・設定可能な値…[A] または [B] 
・RF タグはSession ごとにInventoried フラグを持っており、フラグは[A]または[B]の状態を保
持しています。 
(例) S0=[A], S1=[A], S2=[B], S3=[A] 
・本設定では、Inventory 処理をおこなう際に、RF タグが持つInventoried フラグ（A/B）のう
ち、どちらのフラグのRF タグを読み取り対象にするかを指定します。 
Session 値と併せて使用します。 


● Session 値 （FLASH 初期値：S0） 
・本設定では、Inventory 処理をおこなう際に、RF タグのどのSession のInventoried フラグを
参照するかを設定します。 
基本的には、[UHF_SetSelectParam]コマンドで指定したTarget と同じSession を設定しま
す。 
(例) Session=[S0]、Sel=[ALL]、Inventory のTarget = [A]の場合 
→ S0=[A]のRF タグのみ読み取りします。他のSession の状態には依存しません。 
 ・RF タグ1 … S0= [A], S1= [A], S2= [B], S3= [A] → 読み取りする 
 ・RF タグ2 … S0= [B], S1= [B], S2= [B], S3= [A] → 読み取りしない 
 ・RF タグ3 … S0= [A], S1= [A], S2= [A], S3= [A] → 読み取りする 


● Sel 値 （FLASH 初期値：11: SL） 
・読み取り対象のRF タグの指定に、「Inventoried フラグ」と「SL フラグ」のどちらを使用す
るかを設定します。 
基本的には、[UHF_SetSelectParam]コマンドで指定した「Target 値」が[SL]の場合は、
「Sel 値」には[SL]または[^SL]を指定します。 
それ以外の場合は[ALL]を指定します。 

・Sel 値が[ALL]の場合 (00:ALL または 01:ALL) 
「Session」値で指定した「Inventoried フラグ」の状態が、「Inventory のTarget」で指定
したフラグになっているRF タグが読み取り対象となります。 
(例) Session=[S0], Sel=[ALL], Inventory のTarget= [A]の場合 
→S0=[A]のRF タグのみ読み取りします。他のSession フラグの状態には依存しませ
ん。 
・RF タグ1 … S0= [A], S1= [A], S2= [B], S3= [A], SL=[Set]   → 読み取りする 
・RF タグ2 … S0= [B], S1= [B], S2= [B], S3= [A], SL=[Set]   → 読み取りしない 
・RF タグ3 … S0= [A], S1= [A], S2= [A], S3= [A], SL=[Reset] → 読み取りする 

＜Sel 値が「ALL」の場合の注意点＞ 
通常は、[UHF_SetSelectParam]コマンドで指定する「Target 値」と、
[UHF_SetInventoryParam]コマンドで指定する「Session 値」は、同一のSession とな
るようにします。 
※Select コマンドで遷移させたInventory フラグ以外のフラグを参照して読み取りをお
こなった場合、Select コマンドは意味を持たなくなります。 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

201 

・Sel 値が「10: ^SL」の場合 
SL フラグが[Reset]で、かつ、「Session」値で指定したSession のInventoried フラグの状
態が、「Inventory のTarget」と一致するRF タグが読み取り対象となります。 
(例) Session=[S0], Sel=[^SL], Inventory のTarget= [A]の場合 
→S0=[A]で、かつ、SL=[Reset]のRF タグのみ読み取りします。 
他のSession フラグの状態には依存しません。 
・RF タグ1 … S0= [A], S1= [A], S2= [B], S3= [A], SL=[Set]   → 読み取りしない 
・RF タグ2 … S0= [B], S1= [B], S2= [B], S3= [A], SL=[Set]   → 読み取りしない 
・RF タグ3 … S0= [A], S1= [A], S2= [A], S3= [A], SL=[Reset] → 読み取りする 

・Sel 値が「11: SL」の場合 
SL フラグが[Set]で、かつ、「Session」値で指定したSession のInventoried フラグの状態
が、「Inventory のTarget」と一致するRF タグが読み取り対象となります。 
(例) Session=[S0], Sel=[SL], Inventory のTarget= [A]の場合 
→S0=[A]で、かつ、SL=[Set]のRF タグのみ読み取りします。 
他のSession フラグの状態には依存しません。 
・RF タグ1 … S0= [A], S1= [A], S2= [B], S3= [A], SL=[Set]   → 読み取りする 
・RF タグ2 … S0= [B], S1= [B], S2= [B], S3= [A], SL=[Set]   → 読み取りしない 
・RF タグ3 … S0= [A], S1= [A], S2= [A], S3= [A], SL=[Reset] → 読み取りしない 


● TRext 値 （FLASH 初期値：Use pilot tone） 
・RF タグからの応答のプリアンブル（同期信号）に「pilot tone」を含むかどうかの設定です。 
・UTR-S201 シリーズは、[Use pilot tone]のみ対応しています。[No pilot tone]を指定しても反
映されません。 


● M 値 (変調度、変調モード)  （FLASH 初期値：M4） 
・RF タグからの応答信号の符号化方式を指定します。 
M の後の数値が大きい程、応答信号の受信の精度が高くなりますが、応答信号の受信に掛か
る時間が長くなります。 
特に、大きいデータ長のRF タグデータの読み取りをおこなう場合の、読み取りの精度および
受信に掛かる時間に影響します。 
・UTR-S201 シリーズは、[M4]のみ対応しています。[M4]以外の値を指定しても反映されませ
ん。 


● DR 値 （FLASH 初期値：64/3） 
・DR(Divide Ratio)の略で、RF タグからリーダライタへ応答を返す際のデータ転送速度に影響
します。「DR 値」=[8]よりも「DR 値」=[64/3]のほうが、高速にデータ転送が可能です。 
・UTR-S201 は、「DR 値」=[8]に未対応です。「DR 値」=[8]を指定しても、設定は変更されま
せん。 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

202 

● Q 値の最小値 （FLASH 初期値：1） 
・「Q 値の自動UP/DOWN 機能」が[使用する]の場合の、Q 値の下限値を指定します。 
※「Q 値の最小値」は、別途指定する「Q 値の開始値」、「Q 値の最大値」との大小関係が、「Q
値の最小値」≦「Q 値の開始値」≦「Q 値の最大値」となるように指定してください。上記の
大小関係とならない設定とした場合は、リーダライタからNACK 応答が返ります。 


● Q 値の最大値 （FLASH 初期値：8） 
・「Q 値の自動UP/DOWN 機能」が[使用する]の場合の、Q 値の上限値を指定します。 
※「Q 値の最大値」は、別途指定する「Q 値の開始値」、「Q 値の最小値」との大小関係が、「Q
値の最小値」≦「Q 値の開始値」≦「Q 値の最大値」となるように指定してください。上記の
大小関係とならない設定とした場合は、リーダライタからNACK 応答が返ります。 


● MemBank （FLASH 初期値：TID） 
リーダライタの動作モードが「UHF 連続インベントリリードモード」の場合に、EPC 以外に読
み取りするMemBank を指定します。 
MemBank の詳細は、「4.2 RF タグのメモリ構造」をご参照ください。 


● TID 付加 （FLASH 初期値：付加しない） 
リーダライタが「UHF 連続インベントリリードモード」で動作する場合に、RF タグのEPC
および指定MemBank データの読み取り結果に加えて、TID データも読み取りして付加する
かどうかを指定します。 
・[付加する] 
リーダライタは、TID データも読み取りをおこないます。 
上位機器へのレスポンスは、EPC、指定MemBank データ、TID が返ります。 
TID の読み取りに失敗した場合には、上位機器へのレスポンスは返りません。 
・[付加しない] 
リーダライタは、TID データの読み取りをおこないません。 
上位機器へのレスポンスは、EPC および指定MemBank データのみ返ります。 

TID の読み取りフローの詳細は、「3.9 TID 付加読み取り」をご参照ください。 


● 読み取り開始Word アドレス （FLASH 初期値：[00 00 00 00]h） 
リーダライタが「UHF 連続インベントリリードモード」動作する場合に、指定MemBank の読
み取り開始位置（Word アドレス）を指定します。 
(例) Word アドレス[03]h を指定する場合は、[00 00 00 03]h を指定します。 
(例) Word アドレス[10D]h を指定する場合は、[00 00 01 0D]h を指定します。 


● 読み取りWord 数 （FLASH 初期値：2） 
リーダライタが「UHF 連続インベントリリードモード」動作する場合に、指定MemBank の読
み取るメモリサイズをWord 長（2 バイト単位）で指定します。 
1～32 [Word]の範囲で指定が可能です。 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

203 

［ACK レスポンス］ 

［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 

［コマンド／レスポンス例］ 
(例) 以下のパラメータを書き込む場合 

データ種類 
数値／パラメータ 
コマンド列 

書き込み対象 
FLASH データ 
[02]h 
パラメータ1 
Select コマンドの使用 
使用する 
[1]b 
[0001 1111]b=  
[1F]h 
Q 値の自動UP/DOWN 機能 
使用する 
[1]b 
アンチコリジョン機能 
使用する 
[1]b 
Q 値の初期値 
3 
[0011]b 
Inventory のTarget 
A 
[0]b 
パラメータ2 
Session 値 
S0 
[00]b 
[1101 1100]b= 
[DC]h 
Sel 値 
SL 
[11]b 
TRext 値 
Use pilot tone 
[1]b 
M 値 
M4 
[10]b 
DR 値 
64/3 
[1]b 
パラメータ3 
Q 値の最小値 
1 
[0001]b 
[81]h 
Q 値の最大値 
8 
[1000]b 
パラメータ4 
MemBank 
TID 
[10]b 
[0000 0010]b= 
[02]h 
TID 付加 
付加しない 
[0]b 

読み取り開始Word アドレス 
0 
[00 00 00 00]h 

読み取りWord 数 
2 
[02]h 

• コマンド 
02 00 55 0B 31 02 1F DC 81 02 00 00 00 00 02 03 18 0D 
• レスポンス 
02 00 30 01 31 03 67 0D 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
01h 
データ部 
1 
31h（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_SetInventoryParam / RAM / FLASH / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / UP / DOWN / LSB / ALL / SL / TRext / DR / RF / 55H / 31H / 02H / 00H / 0BH / 01H / 通信フォーマット / コマンドモード / 自動読み取りモード / リーダライタ / アンテナ / インベントリ / レスポンス / Session / Target / 55 31 / 5531 / 55_31 / 55h 31h / UHF SetInventoryParam
