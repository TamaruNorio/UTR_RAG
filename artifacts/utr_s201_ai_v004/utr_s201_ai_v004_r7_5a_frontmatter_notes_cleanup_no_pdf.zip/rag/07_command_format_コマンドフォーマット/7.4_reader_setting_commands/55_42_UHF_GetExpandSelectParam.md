---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 42】UHF_GetExpandSelectParam
topic: リーダライタ設定コマンド
chapter: '07'
source_section: 7.4.4
source_pages: 161-163
category: リーダライタ設定コマンド
chunk_type: command_spec
rag_priority: high
risk_level: low
command_name: UHF_GetExpandSelectParam
command_code: 55h
detail_command: 42h
command_label: 55 42
operation_type: read_setting
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_GetExpandSelectParam
- UHF_SetExpandSelectParam
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- FLASH
- CR
- RFU
- EPC
- UII
- TID
- SL
- MSB
- 55H
- 42H
- 02H
- 00H
- 03H
- 01H
- 0DH
- 30H
- 85H
- 通信フォーマット
- コマンドモード
- 自動読み取りモード
- リーダライタ
- レスポンス
- MemBank
- Inventoried
- Target
- 55 42
- '5542'
- '55_42'
- 55h 42h
- UHF GetExpandSelectParam
- uhf_getexpandselectparam
- 55h
- 42h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_GetExpandSelectParam
- UHF_SetExpandSelectParam
- ACK
- NACK
- FLASH
- 55H
- 55 42
- '5542'
- '55_42'
- 55h 42h
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【55 42】UHF_GetExpandSelectParam.md
optimized_path: 07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_42_UHF_GetExpandSelectParam.md
---
# 【55 42】UHF_GetExpandSelectParam

    ## コマンドの要約

    UHF_GetExpandSelectParamに関する現在値または設定値を読み取るコマンドです。アプリケーション起動時の設定確認、実機状態の見える化、設定変更前のバックアップ確認に使います。

    ## 何に使うコマンドか

    UHF_GetExpandSelectParamの現在設定を上位機器側で取得し、画面表示・ログ出力・設定差分確認に利用します。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.4.4 |
    | 参照ページ | 161-163 |
    | コマンド区分 | リーダライタ設定コマンド |
    | コマンドラベル | 55 42 |
    | コマンド | 55h |
    | 詳細コマンド / サブ情報 | 42h |
    | 操作種別 | read_setting |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 読み取り系コマンドのため、原則として設定値は変更しない。
- ACKレスポンスのデータ部を解析して現在値を取得する。
- NACK時は7.6のエラーコードを確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    UHF_GetExpandSelectParam, 55 42, 55h, 42h, リーダライタ設定コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

160 

7.4.4 
UHF_GetExpandSelectParam 
2回目以降のSelectコマンド用のパラメータ値の取得をおこなうコマンドです。 

［コマンド］ 
※1：パラメータ種類の詳細は「3.12.1 パラメータ種類」をご参照ください。 


ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
03h 
データ部 
1 
42h（詳細コマンド） 
1 
パラメータ種類 ※1 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
1 
n：取得するマスクデータ数(1～7) 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

161 

［ACK レスポンス］ 
※取得した値の説明は、「7.4.14 UHF_SetExpandSelectParam」をご参照ください。 


ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
23*n +2 
データ部 
1 
42h（詳細コマンド） 
1 
パラメータ種類 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 


[コマンド]で指定した [取得するマスクデータ数] 回繰り返します 
23 
× 
(n) 
1 
パラメータ1 ［初期値：85h］ 
bit0 
bit1 
MemBank ※左側が上位bit 
00 
：RFU 
01 
：EPC(UII) ［初期値］ 
10 
：TID 
11 
：User 
bit2-4 
Action 値 ［初期値：001(1)］ 
詳細はパラメータ説明参照 
bit5-7 
Select のTarget 値 ※左側が上位bit 
000 
：Inventoried(S0) 
001 
：Inventoried(S1) 
010 
：Inventoried(S2) 
011 
：Inventoried(S3) 
100 
：SL ［初期値］ 
101 
：Reserved 
110 
：Reserved 
111 
：Reserved 
1 
パラメータ2 ［初期値: 00h］ 
bit0-1 
将来拡張のための予約（通常は0） 
bit2 
Truncate 値（0 固定） 
0 
：Disable ［初期値］ 
1 
：Enable （未サポート） 
bit3-7 
将来拡張のための予約（通常は0） 
4 
マスク開始ビットアドレス ［初期値：[00 00 00 00]h］ 
※MSB ファースト、ビット単位で指定 
1 
マスクbit 数 ［初期値: 00h］ 
※最大128[bit] ([80]h) まで 
16 
マスクデータ ※16[byte]固定 
［初期値：[00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00]h］ 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

162 

［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
• コマンド 
02 00 55 03 42 01 07 03 A7 0D 
                 n 
01h: 自動読み取りモード用パラメータ 
07h: 取得するマスクデータ数n=7 
• レスポンス 
02 00 30 A3 42 01 
85 00 00 00 00 20 60 E2 00 68 0A 00 00 40 02 3C 25 49 18 00 00 00 00 
85 00 00 00 00 20 60 E2 00 68 0A 00 00 40 02 3C 24 D1 17 00 00 00 00 
85 00 00 00 00 20 60 E2 00 68 0A 00 00 40 02 3C 24 E5 17 00 00 00 00 
85 00 00 00 00 20 60 E2 00 68 0A 00 00 40 02 3C 25 51 18 00 00 00 00 
85 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 
85 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 
85 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 
03 46 0D  

• 
レスポンスの内容 

パラメータ1 
パラメータ2 
マスク開始 
ビットアドレス 
マスク 
bit 数 
マスクデータ 
(16 [byte]固定) 
Select2 
85 00 
00 00 00 20 
[60]]h→ 96[bit] 
E2 00 68 0A 00 00 40 02 
3C 25 49 18 00 00 00 00 
Select3 
85 00 
00 00 00 20 
[60]h→ 96[bit] 
E2 00 68 0A 00 00 40 02 
3C 24 D1 17 00 00 00 00 
Select4 
85 00 
00 00 00 20 
[60]h→ 96[bit] 
E2 00 68 0A 00 00 40 02 
3C 24 E5 17 00 00 00 00 
Select5 
85 00 
00 00 00 20 
[60]h→ 96[bit] 
E2 00 68 0A 00 00 40 02 
3C 25 51 18 00 00 00 00 
Select6 
85 00 
00 00 00 00 
[00]h→ 0[bit] 
00 00 00 00 00 00 00 00 
00 00 00 00 00 00 00 00 
Select7 
85 00 
00 00 00 00 
[00]h→ 0[bit] 
00 00 00 00 00 00 00 00 
00 00 00 00 00 00 00 00 
Select8 
85 00 
00 00 00 00 
[00]h→ 0[bit] 
00 00 00 00 00 00 00 00 
00 00 00 00 00 00 00 00 
※パラメータ1 : [85]h … Target 値：[SL]、Action 値：[001]、MemBank：EPC(UII) 
※パラメータ2 : [00]h … Truncate 値: [Disable] 
※マスクbit 数：[60]h → 96 [bit] … マスクデータの先頭96[bit] (=12[byte])がマスク対象 
※マスクbit 数：[00]h → 0 [bit] … Select コマンドの対象外 
→ Select6, Select7, Select8 はSelect コマンドの対象外 

Action 値:001 は、OR(論理和)の動作をするため、以下の条件の「いずれか」に一致する 
RF タグが選択されます。 
・Select1： UHF_SetSelectParam で設定したマスク条件のRF タグ 
・Select2： EPC(UII)がE2 00 68 0A 00 00 40 02 3C 25 49 18 に一致するRF タグ 
・Select3： EPC(UII)がE2 00 68 0A 00 00 40 02 3C 24 D1 17 に一致するRF タグ 
・Select4： EPC(UII)がE2 00 68 0A 00 00 40 02 3C 24 E5 17 に一致するRF タグ 
・Select5： EPC(UII)がE2 00 68 0A 00 00 40 02 3C 25 51 18 に一致するRF タグ
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_GetExpandSelectParam / UHF_SetExpandSelectParam / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / FLASH / CR / RFU / EPC / UII / TID / SL / MSB / 55H / 42H / 02H / 00H / 03H / 01H / 0DH / 30H / 85H / 通信フォーマット / コマンドモード / 自動読み取りモード / リーダライタ / レスポンス / MemBank / Inventoried / Target / 55 42 / 5542 / 55_42 / 55h 42h
