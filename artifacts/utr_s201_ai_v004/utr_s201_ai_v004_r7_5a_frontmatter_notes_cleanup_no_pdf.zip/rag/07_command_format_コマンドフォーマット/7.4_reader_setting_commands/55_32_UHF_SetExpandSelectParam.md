---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 32】UHF_SetExpandSelectParam
topic: リーダライタ設定コマンド
chapter: '07'
source_section: 7.4.19
source_pages: 205-212
category: リーダライタ設定コマンド
chunk_type: command_spec
rag_priority: high
risk_level: high
command_name: UHF_SetExpandSelectParam
command_code: 55h
detail_command: 32h
command_label: 55 32
operation_type: write_setting
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_SET_EXPAND_SELECT_PARAM
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_SET_EXPAND_SELECT_PARAM
executable_hex_output: prohibited
checksum_policy: placeholder_only
automatic_send_allowed: false
requires_actual_device_check: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_SetExpandSelectParam
- UHF_SetSelectParam
- RAM
- FLASH
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- RFU
- EPC
- UII
- TID
- SL
- MSB
- RF
- ISO18000
- CRC
- PC
- ID
- 55H
- 32H
- 02H
- 00H
- 01H
- 85H
- 通信フォーマット
- コマンドモード
- 自動読み取りモード
- リーダライタ
- レスポンス
- CR
- MemBank
- Inventoried
- Target
- 55 32
- '5532'
- '55_32'
- 55h 32h
- UHF SetExpandSelectParam
- uhf_setexpandselectparam
- 55h
- 32h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_SetExpandSelectParam
- UHF_SetSelectParam
- FLASH
- ACK
- NACK
- 55H
- 55 32
- '5532'
- '55_32'
- 55h 32h
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【55 32】UHF_SetExpandSelectParam.md
optimized_path: 07_command_format_コマンドフォーマット/7.4_reader_setting_commands/55_32_UHF_SetExpandSelectParam.md
---
# 【55 32】UHF_SetExpandSelectParam

    ## コマンドの要約

    UHF_SetExpandSelectParamに関する設定値を書き込むコマンドです。RAM、FLASH、または指定パラメータ種別への反映条件を確認してから使用します。

    ## 何に使うコマンドか

    UHF_SetExpandSelectParamの設定を上位機器から変更するために使います。現場調整では、変更前後の読み取り確認とログ保存が重要です。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.4.19 |
    | 参照ページ | 205-212 |
    | コマンド区分 | リーダライタ設定コマンド |
    | コマンドラベル | 55 32 |
    | コマンド | 55h |
    | 詳細コマンド / サブ情報 | 32h |
    | 操作種別 | write_setting |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 書き込み先がRAMかFLASHかを必ず確認する。
- FLASH書き込みは設定が保持されるため、実行前に値を控える。
- 不正パラメータ時はNACKとなるため、範囲・予約ビット・機種対応を確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    UHF_SetExpandSelectParam, 55 32, 55h, 32h, リーダライタ設定コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

204 

7.4.19 UHF_SetExpandSelectParam 
2回目以降のSelectコマンド用のパラメータ値の設定をおこなうコマンドです。 
[UHF_SetSelectParam]コマンドにて指定したマスクに加えて、別のエリアのマスク対象を指定する
ために使用します。必要なエリアの数だけ最大7ヶ所追加することが可能です。 

［コマンド］ 
（次ページへ続く） 

ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
23*n+3 
データ部 
1 
32h（詳細コマンド） 
1 
パラメータ種類 ※1 
00h 
：コマンドモード用パラメータ 
01h 
：自動読み取りモード用パラメータ 
02h 
：FLASH データ 
1 
設定するマスクデータ数 n（1～7） 


[設定するマスクデータ数] 回繰り返します 
23
× 
(n) 
1 
パラメータ1 ［初期値: 85h］ 
bit0 
bit1 
MemBank ※左側が上位bit 
00 
：RFU 
01 
：EPC(UII) ［初期値］ 
10 
：TID 
11 
：User 
bit2-4 
Action 値 ［初期値：001］ 
詳細はパラメータ説明参照 
bit5-7 
Target 値 
000 
：Inventoried(S0) 
001 
：Inventoried(S1) 
010 
：Inventoried(S2) 
011 
：Inventoried(S3) 
100 
：SL ［初期値］ 
101 
：Reserved 
110 
：Reserved 
111 
：Reserved 
1 
パラメータ2 ［初期値: 00h］ 
bit0-1 
将来拡張のための予約（通常は0） 
bit2 
Truncate 値（0 固定） 
0 
：Disable［初期値］ 
1 
：Enable（未サポート） 
bit3-7 
将来拡張のための予約（通常は0） 
4 
マスク開始ビットアドレス ［初期値: 00 00 00 00］ 
※MSB ファースト、ビット単位で指定 
1 
マスクbit 数  ※最大128[bit]まで 
16 
マスクデータ （16 [byte]固定） 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

205 

（前ページからの続き） 
※1：パラメータ種類の詳細は「3.12.1 パラメータ種類」をご参照ください。 


● 設定するマスクデータ数（1～7） 
2 回目以降のSelect コマンドを送信する数を指定します。 


● MemBank 
[Select]コマンドの対象のメモリ領域を指定します。（FLASH 初期値：EPC(UII)） 
詳細は、「4.2 RF タグのメモリ構造」の項を参照ください。 
・RFU 
ISO18000-63 規格上の予約領域です。現在使用することはできません 
※RF タグのメモリ領域の[00h: Reserved]とは異なります。 
・EPC(UII) 
ビットアドレス[00]h からCRC (16[bit]) + PC (16[bit]) 
ビットアドレス[20]h からEPC(UII) 
・TID 
ビットアドレス[00]h からRF タグのユニークなID 領域（一般的には64[bit]または96[bit]） 
・USER 
ビットアドレス[00]h からユーザメモリ 



ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

206 

● Action 値 
「マスク条件」で指定した内容に「一致」／「不一致」のRF タグに対し、「Target 値」で指定
したフラグの状態をそれぞれどのように変化させるかを指定するパラメータです。（FLASH 初
期値：001） 
※「Target 値」で指定したフラグのみ変化します。 
・2回目以降の[Select]コマンドの「Action値」の設定により、「マスク条件」は論理演算
(AND, ORなど)されます。 
・1回目の[Select]コマンドの「Target値」と異なる場合を除き、2回目以降の[Select]コマンド
の「Action値」は、000(0)、100(4)以外を指定してください。詳細は後述の(例2)をご参照く
ださい。 


● Target 値 
Select コマンドを受けたRF タグが、「Inventoried フラグ」または「SL フラグ」のどちらを遷
移させるかを指定します。（FLASH 初期値：SL） 
また、「Inventoried フラグ」の場合はさらに、4 つのセッション(S0, S1, S2, S3)のうちどのセッ
ションが対象かを指定します。 
RF タグは、Select コマンドで指定した「マスク条件」への[一致]／[不一致]に応じて、「Action
値」で指定した状態遷移をおこないます。 


● Truncate 値（FLASH 初期値：Disable） 
・Select コマンドのコマンドパラメータ中のTruncate の値を設定します。 
・UTR-S201 シリーズは、「Truncate 値」は[Disable]のみ対応しています。[Enable]を指定して
も反映されません。 


Action 
※左側がMSB 
( )内は10 進数 
Matching 
（マスク条件が一致） 
Non-Matching 
（マスク条件が不一致） 
Inventoried 
フラグが対象 
SL フラグ 
が対象 
Inventoried 
フラグが対象 
SL フラグ 
が対象 
000 
(0) 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
001 
(1) 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
なにもしない 
010 
(2) 
なにもしない 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
011 
(3) 
Inventoried フラグ 
を反転 
※[A]なら[B]へ 
※[B]なら[A]へ 
SL フラグを 
反転 
なにもしない 
100 
(4) 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
101 
(5) 
Inventoried フラグ 
を[B]にセット 
SL フラグを 
リセット 
なにもしない 
110 
(6) 
なにもしない 
Inventoried フラグ 
を[A]にセット 
SL フラグを 
セット 
111 
(7) 
なにもしない 
Inventoried フラグ 
を反転 
※[A]なら[B]へ 
※[B]なら[A]へ 
SL フラグを 
反転 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

207 

● マスク開始bit アドレス（FLASH 初期値：[00 00 00 00]h） 
「MemBank」で指定したメモリ領域の、「マスク条件」を設定する開始bit アドレスを指定しま
す。 
※ Word アドレスではなく、bit アドレスで指定します。 
※ 0 [Word]目の最上位bit がbit アドレス[00]h、最下位bit がbit アドレス[0F]h です。 


● マスクbit 数 
マスク開始bit アドレスから開始して、マスクするbit 長を指定します。 
上限128[bit]まで指定することができます。（FLASH 初期値：0） 
※[UHF_SetExpandSelectParam]コマンドで指定するマスク条件においては、
「マスクbit 数」
が0 の場合は、そのマスク条件のSelect コマンドは送信されません。また、その場合、それ以
降の番号のマスク条件が設定されている場合においても、Select コマンドは送信されません。 

マスクbit 数 
Select コマンドは 
何回実行されるか？ 
Sel-1 
Sel-2 
Sel-3 
Sel-4 
Sel-5 
Sel-6 
Sel-7 
Sel-8 
例1 
0 
96 
16 
0 
32 
0 
0 
0 
Select3 まで実行 
例2 
0 
0 
0 
0 
0 
0 
0 
0 
Select1 のみ実行 
例3 
32 
0 
16 
96 
96 
96 
16 
0 
Select1 のみ実行 
例4 
96 
16 
16 
32 
96 
96 
0 
0 
Select6 まで実行 


● マスクデータ （16 [byte]固定） 
 （FLASH 初期値：[00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00]h） 
・マスクデータを「byte 単位」で指定します。上限16[byte]まで指定することができます。 
※マスクbit 数が8 の倍数にならない場合は、上位bit からbyte 単位で区切り、 
端数となるbyte 内では下位bit にデータを詰めて、上位bit は0 埋めします。 
詳細は、「7.4.17 UHF_SetSelectParam」の「マスクデータ」をご参照ください。 
・マスクデータ長が16 [byte]未満となる場合は、下位バイトに「00」を詰めて、16[byte]となる
ように指定します。 
(例) EPC(UII) : 「E2 00 68 0A 00 00 40 02 3C 25 49 18」(12[byte])でマスクする場合 
「マスクデータ」 = [E2 00 68 0A 00 00 40 02 3C 25 49 18 00 00 00 00 ] h 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

208 

● Select コマンドを2 回以上使用した場合のRF タグのフラグ状態遷移 
・[UHF_SetSelectParam]コマンドで指定する1 回目のSelect コマンドのマスク条件と、
[UHF_SetExpandSelectParam]コマンドで指定する2 回目以降のSelect コマンドのマスク条件
の組み合わせにより、RF タグのフラグの状態遷移は異なります。 
※以下の説明では、「Target 値」=[SL]の場合の例を示しています。 

(例1) 1 回目のSelect のAction 値000 (0)、2 回目のSelect のAction 値001 (1)を指定した場合 
※Action 値の説明 （必要部分を抜粋） 

SL フラグが対象 
Action 値 
Matching（マスク条件が一致） 
Non-Matching（マスク条件が不一致） 
000 (0) 
SL=[Set] 
SL=[Reset] 
001 (1) 
SL=[Set] 
なにもしない 
・1 回目のSelect のAction 値は000(0)なので、マスク条件1 に[一致]するRF タグは[SL=Set]とな
り、[不一致]のRF タグは[SL = Reset]となります。 
・2 回目のSelect のAction 値は001(1)なので、マスク条件2 に[一致]するRF タグは[SL=Set]とな
りますので、1 回目のSelect の結果によらず[SL=Set]になります。 
マスク条件2 に[不一致]のRF タグは、Action が[なにもしない]なので、1 回目のSelect の結果が
そのまま反映されます。 
コマンド 
実行前 
マスク条件1 への
[一致]／[不一致] 
Select1 
実行後 
マスク条件2 への
[一致]／[不一致] 
Select2 
実行後 
Set 
一致 
Set 
一致 
Set 
不一致 
Set 
不一致 
Reset 
一致 
Set 
不一致 
Reset 
Reset 
一致 
Set 
一致 
Set 
不一致 
Set 
不一致 
Reset 
一致 
Set 
不一致 
Reset 
以上の動作をおこなうと、[マスク条件1]または[マスク条件2]に一致するRF タグが 
[SL=Set]となるため、結果として論理演算の[OR]の動作をおこないます。 

(例2) 2 回目のSelect のAction 値に、000(0)または100 (4)を指定した場合 
※Action 値の説明 （必要部分を抜粋） 

SL フラグが対象 
Action 値 
Matching（マスク条件が一致） 
Non-Matching（マスク条件が不一致） 
000 (0) 
SL=[Set] 
SL=[Reset] 
100 (4) 
SL=[Reset] 
SL=[Set] 

・2 回目のSelect のAction 値に000(0)または100(4)を指定すると、1 回目のSelect のAction の結
果によらず、2 回目のSelect のマスク条件への[一致]／[不一致]の結果のみでフラグの状態遷移が
決まります。 
よって、UHF_SetExpandSelectParam で2 回目以降のSelect コマンドを実行する場合には、
Action 値は000(0)と100(4)は使用しないように設定します。 

・次ページ以降に、1 回目のSelect コマンドのAction 値が000(0)の場合および100(4)の場合におけ
る、2 回目のSelect コマンド毎のRF タグのフラグ状態遷移をまとめます。 
※上記理由により、2 回目のSelect のAction 値が000(0)または100(4)の場合を除外していま
す。 


マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

209 

● 1 回目のSelect のAction 値が000 (0)の場合 
・1 回目のSelect のマスク条件への[一致]／[不一致]をP とします。 
・2 回目のSelect のマスク条件への[一致]／[不一致]をQ とします。 

① 2 回目のSelect のAction 値が001 (1)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Set 
SL = Set 

論理式 ： P ∨ Q 
不一致 
SL = Set 
SL = Reset 

論理演算：OR (論理和) 

② 2 回目のSelect のAction 値が010 (2)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Set 
SL = Reset 

論理式 ： P ∧ Q 
不一致 
SL = Reset 
SL = Reset 

論理演算：AND (論理積) 

③ 2 回目のSelect のAction 値が011 (3)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Reset 
SL = Set 

論理式 ： P (XOR) Q 
不一致 
SL = Set 
SL = Reset 

論理演算：XOR (排他的論理和) 

④ 2 回目のSelect のAction 値が101 (5)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Reset 
SL = Set 

論理式 ： P ∧ ￢Q 
不一致 
SL = Reset 
SL = Reset 

論理演算 ： 該当なし 

⑤ 2 回目のSelect のAction 値が110 (6)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Set 
SL = Set 

論理式 ： P ∨ ￢Q 
不一致 
SL = Reset 
SL = Set 

論理演算 ： 該当なし 

⑥ 2 回目のSelect のAction 値が111 (7)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Set 
SL = Reset 

論理式 ： ￢ ( P (XOR) Q ) 
不一致 
SL = Reset 
SL = Set 

論理演算 ： 該当なし 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

210 

● 1 回目のSelect のAction 値が100 (4)の場合 
・1 回目のSelect のマスク条件への[一致]／[不一致]をP とします。 
・2 回目のSelect のマスク条件への[一致]／[不一致]をQ とします。 

① 2 回目のSelect のAction 値が001 (1)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Set 
SL = Reset 

論理式 ： P (NAND) ￢Q 
不一致 
SL = Set 
SL = Set 

論理演算 ： 該当なし 

② 2 回目のSelect のAction 値が010 (2)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Reset 
SL = Reset 

論理式 ： ￢P ∧ Q 
不一致 
SL = Set 
SL = Reset 

論理演算 ： 該当なし 

③ 2 回目のSelect のAction 値が011 (3)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Set 
SL = Reset 

論理式 ： ￢ ( P (XOR) Q ) 
不一致 
SL = Reset 
SL = Set 

論理演算 ： 該当なし 

④ 2 回目のSelect のAction 値が101 (5)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Reset 
SL = Reset 

論理式 ： P (NOR) Q 
不一致 
SL = Reset 
SL = Set 

論理演算：NOR (否定論理和) 

⑤ 2 回目のSelect のAction 値が110 (6)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Reset 
SL = Set 

論理式 ： P (NAND) Q 
不一致 
SL = Set 
SL = Set 

論理演算：NAND (否定論理積) 

⑥ 2 回目のSelect のAction 値が111 (7)の場合 
マスク条件 
条件2 ( Q ) 


一致 
不一致 
条件1 
( P ) 
一致 
SL = Reset 
SL = Set 

論理式 ： P (XOR) Q 
不一致 
SL = Set 
SL = Reset 

論理演算：XOR (排他的論理和) 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

211 

［ACK レスポンス］ 


［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
以下のパラメータを書き込む場合 
データ種類 
数値／パラメータ 
コマンド列 
書き込み対象 
自動読み取りモード用 
パラメータ 
01 
設定するマスクデータ数 n 
1 
01 
パラメータ1 
MemBank 
11：User 
(01000111)b 
→ 47 
Action 値 
001 (1) 
Target 値 
010：Inventoried(S2) 
パラメータ2 
Truncate 値 
0：Disable 
00 
マスク開始bit アドレス 
4 
00 00 00 04 
マスクbit 数 
4 
04 
マスクデータ 
3 
03 00 00 00 00 00 00 00 
00 00 00 00 00 00 00 00 
・User 領域の4[bit]目から4[bit]をマスクしてInventoried フラグ(S2)に対して 
Action 001 (1)を実行します。 
・UHF_SetSelectParam で指定した1 回目のSelect のAction 値により、 
読み取りできるRF タグは異なります。 

• 
コマンド 
02 00 55 1A 32 01 01 47 00 00 00 00 04 04 03 00 00 00 00 00 00 00 00 00 00 00 
00 00 00 00 03 FA 0D 
• 
レスポンス 
02 00 30 01 32 03 68 0D 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
01h 
データ部 
1 
32h（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_SetExpandSelectParam / UHF_SetSelectParam / RAM / FLASH / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / RFU / EPC / UII / TID / SL / MSB / RF / ISO18000 / CRC / PC / ID / 55H / 32H / 02H / 00H / 01H / 85H / 通信フォーマット / コマンドモード / 自動読み取りモード / リーダライタ / レスポンス / CR / MemBank / Inventoried / Target / 55 32
