---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【4E B4】FLASH設定値の書き込み(1バイトアクセス)
topic: リーダライタ設定コマンド
chapter: '07'
source_section: 7.4.29
source_pages: 246-247
category: リーダライタ設定コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
command_name: FLASH設定値の書き込み(1バイトアクセス)
command_code: 4Eh
detail_command: B4h
command_label: 4E B4
operation_type: write_setting
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#FLASH_WRITE
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.FLASH_WRITE
executable_hex_output: prohibited
checksum_policy: placeholder_only
ai_code_generation: implementation_prohibited
automatic_send_allowed: false
requires_actual_device_check: true
requires_explicit_user_permission: true
requires_pdf_confirmation: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- FLASH
- RAM
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- CR
- EA
- 4EH
- B4H
- 02H
- 00H
- 03H
- 0DH
- 30H
- 01H
- 通信フォーマット
- リーダライタ
- レスポンス
- Write
- 4E B4
- 4EB4
- 4E_B4
- 4Eh B4h
- FLASH設定値の書き込み(1バイトアクセス)
- flash設定値の書き込み(1バイトアクセス)
- 4Eh
- B4h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- UHF_Write
- 書き込み
- EPC書き換え
- WordPtr
- WriteData
- 設定保存
- FLASH設定値
- 電源再投入
- 初期化
- チップバージョン
aliases:
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- FLASH
- ACK
- NACK
- 4EH
- 4E B4
- 4EB4
- 4E_B4
- 4Eh B4h
- FLASH設定値の書き込み(1バイトアクセス)
- 4Eh
- UHF_Write
- FLASH設定値
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.4_リーダライタ設定コマンド/公開_UTR版_【4E B4】FLASH設定値の書き込み(1バイトアクセス).md
optimized_path: 07_command_format_コマンドフォーマット/7.4_reader_setting_commands/4E_B4_FLASH設定値の書き込み(1バイトアクセス).md
---
# 【4E B4】FLASH設定値の書き込み(1バイトアクセス)

    ## コマンドの要約

    FLASH設定値(1バイトアクセス)に関する設定値を書き込むコマンドです。RAM、FLASH、または指定パラメータ種別への反映条件を確認してから使用します。

    ## 何に使うコマンドか

    FLASH設定値(1バイトアクセス)の設定を上位機器から変更するために使います。現場調整では、変更前後の読み取り確認とログ保存が重要です。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.4.29 |
    | 参照ページ | 246-247 |
    | コマンド区分 | リーダライタ設定コマンド |
    | コマンドラベル | 4E B4 |
    | コマンド | 4Eh |
    | 詳細コマンド / サブ情報 | B4h |
    | 操作種別 | write_setting |
    | リスク目安 | high |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 書き込み先がRAMかFLASHかを必ず確認する。
- FLASH書き込みは設定が保持されるため、実行前に値を控える。
- 不正パラメータ時はNACKとなるため、範囲・予約ビット・機種対応を確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    FLASH設定値の書き込み(1バイトアクセス), 4E B4, 4Eh, B4h, リーダライタ設定コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

245 

7.4.29 FLASH 設定値の書き込み(1 バイトアクセス) 
FLASH設定値をアドレス単位（1 バイト単位）で書き込むコマンドです。 
FLASHアドレスは、「9.1 FLASHアドレス一覧」をご参照ください。 

［コマンド］ 

● 書き込みアドレス 
書き込みするFLASHアドレスをHex文字列で指定します。 
(例) FLASHアドレスの30([1E]h)に書き込みする場合は、[1E]hを指定します。 

［ACK レスポンス］ 

［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
4Eh 
データ長 
1 
03h 
データ部 
1 
B4h（詳細コマンド） 
1 
書き込みアドレス 
1 
書き込みデータ 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 
ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
ACK 
1 
30h（ACK） 
データ長 
1 
01h 
データ部 
1 
B4h（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.4 リーダライタ設定コマンド 

246 

［コマンド／レスポンス例］ 

(例1) 汎用ポートの「機能」を変更する場合 
汎用ポートの「機能」、FLASH アドレスの30([1E]h)に書かれています。 
以下では、汎用ポートの「機能」のパラメータを下表の通り変更する例を示します。 
データ種類 
数値／パラメータ 
コマンド列 
書き込みアドレス 
アドレス30 
1E 
書き込みデータ 
汎用ポート1 の機能 
1: 汎用ポート 
05 
汎用ポート2 の機能 
0: トリガー制御信号入力ポート 
汎用ポート3 の機能 
1: 汎用ポート 
汎用ポート4 の機能 
0: －－ 
汎用ポート5 の機能 
0: －－ 
汎用ポート6 の機能 
0: －－ 
汎用ポート7 の機能 
0: ブザー制御信号出力ポート 
汎用ポート8 の機能 
0: －－ 

• 
コマンド 
02 00 4E 03 B4 1E 05 03 2D 0D 
• 
レスポンス 
02 00 30 01 B4 03 EA 0D 


(例2) Writeコマンドのタイムアウト時間を変更する場合 
Writeコマンドのタイムアウト時間は、FLASHアドレスの91([5B]h)に書かれています。 
初期値は20 [msec] (=[14]h)です。 
以下では、Writeコマンドのタイムアウト時間を20[msec] (初期値)から5[msec]に変更する例
を示します。[FLASH設定値の書き込み(1バイトアクセス)]コマンドを使用して、以下のパラ
メータを書き込みます。 
・書き込みアドレス：91 ([5B]h) 
・書き込みデータ：5 ([05]h) 
↓ 
・コマンド 
  02 00 4E 03 B4 5B 05 03 6A 0D 
・レスポンス 
  02 00 30 01 B4 03 EA 0D  ([30]h: ACK応答)
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / FLASH / RAM / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / CR / EA / 4EH / B4H / 02H / 00H / 03H / 0DH / 30H / 01H / 通信フォーマット / リーダライタ / レスポンス / Write / 4E B4 / 4EB4 / 4E_B4 / 4Eh B4h / FLASH設定値の書き込み(1バイトアクセス) / flash設定値の書き込み(1バイトアクセス) / 4Eh / B4h / 通信 / インターフェース / シリアル通信 / TCP/IP / USB / Bluetooth / Wi-Fi
