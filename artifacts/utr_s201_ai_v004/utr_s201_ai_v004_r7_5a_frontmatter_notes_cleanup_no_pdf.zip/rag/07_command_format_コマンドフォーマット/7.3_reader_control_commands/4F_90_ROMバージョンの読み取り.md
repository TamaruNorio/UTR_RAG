---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【4F 90】ROMバージョンの読み取り
topic: リーダライタ制御コマンド
chapter: '07'
source_section: 7.3.8
source_pages: '146'
category: リーダライタ制御コマンド
chunk_type: command_spec
rag_priority: high
risk_level: low
command_name: ROMバージョンの読み取り
command_code: 4Fh
detail_command: 90h
command_label: 4F 90
operation_type: reader_control
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- ROM
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- ASCII
- USM01
- CR
- USM06
- 4FH
- 90H
- 02H
- 00H
- 01H
- 03H
- 0DH
- 30H
- 0AH
- 通信フォーマット
- リーダライタ
- レスポンス
- ROMバージョン
- 4F 90
- 4F90
- 4F_90
- 4Fh 90h
- ROMバージョンの読み取り
- romバージョンの読み取り
- 4Fh
- 90h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- ファームウェア
- USM02
- USM05
- USM08
- チップバージョン
- RF-ASIC
- Reader Writer
- RW
aliases:
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- ACK
- NACK
- 4FH
- 4F 90
- 4F90
- 4F_90
- 4Fh 90h
- 4Fh
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.3_リーダライタ制御コマンド/公開_UTR版_【4F 90】ROMバージョンの読み取り.md
optimized_path: 07_command_format_コマンドフォーマット/7.3_reader_control_commands/4F_90_ROMバージョンの読み取り.md
---
# 【4F 90】ROMバージョンの読み取り

    ## コマンドの要約

    ROMバージョンに関する現在値または設定値を読み取るコマンドです。アプリケーション起動時の設定確認、実機状態の見える化、設定変更前のバックアップ確認に使います。

    ## 何に使うコマンドか

    ROMバージョンの現在設定を上位機器側で取得し、画面表示・ログ出力・設定差分確認に利用します。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.3.8 |
    | 参照ページ | 146 |
    | コマンド区分 | リーダライタ制御コマンド |
    | コマンドラベル | 4F 90 |
    | コマンド | 4Fh |
    | 詳細コマンド / サブ情報 | 90h |
    | 操作種別 | reader_control |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 読み取り系コマンドのため、原則として設定値は変更しない。
- ACKレスポンスのデータ部を解析して現在値を取得する。
- NACK時は7.6のエラーコードを確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    ROMバージョンの読み取り, 4F 90, 4Fh, 90h, リーダライタ制御コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.3 リーダライタ制御コマンド 

145 

7.3.8 
ROM バージョンの読み取り 
リーダライタのROM バージョン（ファームウェアバージョン）を読み取るコマンドです。 
ROM バージョン更新情報およびシリーズ名の一覧は、目次の前の「ROM バージョン情報」をご参
照ください。 

［コマンド］ 


［ACK レスポンス］ 


［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
• コマンド 
02 00 4F 01 90 03 E5 0D 
• レスポンス 
02 00 30 0A 90 31 31 30 30 55 53 4D 30 31 03 E7 0D 

「メジャーバージョン番号」「マイナーバージョン番号」「シリーズ名」は、 
ASCII コードで返りますので、文字列に変換してください。 

受信データ列 
31 
31 
30 
30 
55 
53 
4D 
30 
31 
ROM バージョン 
1 
1 
0 
0 
U 
S 
M 
0 
1 
※ ROM バージョン1100USM01 
シリーズ名：UTR-S201、ファームバージョン1.100 であることが分かります。 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
4Fh 
データ長 
1 
01h 
データ部 
1 
90h（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 
ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
0Ah 
データ部 
1 
90h（詳細コマンド） 
1 
メジャーバージョン番号 
3 
マイナーバージョン番号 
5 
シリーズ名（例：”USM01”, “USM06”） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / ROM / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / ASCII / USM01 / CR / USM06 / 4FH / 90H / 02H / 00H / 01H / 03H / 0DH / 30H / 0AH / 通信フォーマット / リーダライタ / レスポンス / ROMバージョン / 4F 90 / 4F90 / 4F_90 / 4Fh 90h / ROMバージョンの読み取り / romバージョンの読み取り / 4Fh / 90h / 通信 / インターフェース / シリアル通信 / TCP/IP / USB
