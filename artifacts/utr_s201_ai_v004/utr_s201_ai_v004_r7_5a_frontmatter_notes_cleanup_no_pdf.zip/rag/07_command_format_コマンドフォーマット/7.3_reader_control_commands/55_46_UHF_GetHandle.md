---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 46】UHF_GetHandle
topic: リーダライタ制御コマンド
chapter: '07'
source_section: 7.3.12
source_pages: 151-152
category: リーダライタ制御コマンド
chunk_type: command_spec
rag_priority: high
risk_level: low
command_name: UHF_GetHandle
command_code: 55h
detail_command: 46h
command_label: 55 46
operation_type: reader_control
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_GetHandle
- UHF_ThroughCmd
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- ACK
- NACK
- AI
- PDF
- RAG
- RF
- ROM
- CR
- 'ON'
- UP
- DOWN
- 'OFF'
- MSB
- 55H
- 46H
- 02H
- 00H
- 01H
- 03H
- 0DH
- 30H
- 通信フォーマット
- リーダライタ
- RFタグ
- レスポンス
- Q値
- ROMバージョン
- 55 46
- '5546'
- '55_46'
- 55h 46h
- UHF GetHandle
- uhf_gethandle
- 55h
- 46h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- Inventory
- UHF_Inventory
aliases:
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_GetHandle
- UHF_ThroughCmd
- ACK
- NACK
- 55H
- 55 46
- '5546'
- '55_46'
- 55h 46h
- 55h
- Inventory
- UHF_Inventory
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.3_リーダライタ制御コマンド/公開_UTR版_【55 46】UHF_GetHandle.md
optimized_path: 07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_46_UHF_GetHandle.md
---
# 【55 46】UHF_GetHandle

    ## コマンドの要約

    UHF_GetHandleに関する現在値または設定値を読み取るコマンドです。アプリケーション起動時の設定確認、実機状態の見える化、設定変更前のバックアップ確認に使います。

    ## 何に使うコマンドか

    UHF_GetHandleの現在設定を上位機器側で取得し、画面表示・ログ出力・設定差分確認に利用します。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.3.12 |
    | 参照ページ | 151-152 |
    | コマンド区分 | リーダライタ制御コマンド |
    | コマンドラベル | 55 46 |
    | コマンド | 55h |
    | 詳細コマンド / サブ情報 | 46h |
    | 操作種別 | reader_control |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - 読み取り系コマンドのため、原則として設定値は変更しない。
- ACKレスポンスのデータ部を解析して現在値を取得する。
- NACK時は7.6のエラーコードを確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    UHF_GetHandle, 55 46, 55h, 46h, リーダライタ制御コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.3 リーダライタ制御コマンド 

150 

7.3.12 UHF_GetHandle 
リーダライタ内部に保持している、「RFタグから最後に取得したHandleデータ」を取得する 
コマンドです。 
※リーダライタのROMバージョンがVer.2.050以降の場合に有効なコマンドです。 
Open状態、Secured状態のRFタグに対してコマンドを送信する際に、RFタグから取得したHandle
データをコマンドパラメータにセットする必要があります。 
[UHF_ThroughCmd]を使用してカスタムコマンドを実行する場合など、必要に応じてリーダライタ
からHandleデータを取得してください。 

[コマンド] 
ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
01h 
データ部 
1 
46h（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.4 SUM の計算方法」参照） 
CR 
1 
0Dh 

RFタグが保持しているHandleデータは、RFタグがOpen状態またはSecured状態から抜けるとクリ
アまたは再生成されてしまいますので、正しいフローで制御しないと、「リーダライタ内部で保持し
ているHandleデータ」と「RFタグが生成したHandleデータ」が異なる可能性があります。 
Handleデータを取得してコマンド制御に使用する場合は、以下の手順で処理をおこなう必要があり
ますのでご注意ください。 
1．RF送信信号の制御コマンドを実行し、キャリア出力をONする。 
2．Inventoryコマンドを以下のパラメータで実行し、RFタグをOpen状態とする。 
・Q値の自動UP/DOWN機能=使用しない 
・Q値の開始値=0 
・Q値の最小値=0 
・Q値の最大値=0 
※複数のRFタグから1枚を指定して処理をおこなう場合は、事前にSelectコマンドを実行する設
定も必要です。 
3．UHF_GetHandleコマンドを実行してHandleデータを取得する。（必要に応じて） 
4．UHF_ThroughCmdを使用してRFタグのカスタムコマンドを実行する。 
（必要に応じてHandleデータをパラメータに含める） 
5．RF送信信号の制御コマンドを実行し、キャリア出力をOFFする。（推奨処理） 
※不要な電波を出し続けると電波干渉の要因となりますので、処理終了後は直ちにキャリア
出力OFFすることを推奨します。 
※Handleデータは、UHF_ThroughCmdのパラメータ設定により、RFタグへの送信データに自動
的に付与させることも可能です。 
詳細は「7.5.11 UHF_ThroughCmd」をご参照ください。 



マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.3 リーダライタ制御コマンド 

151 

[ACK レスポンス] 
ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
03h 
データ部 
1 
46h 
2 
RF タグから受信したHandle 値 
※MSB ファーストでセットされます 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.4 SUM の計算方法」参照） 
CR 
1 
0Dh 


［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
• コマンド 
02 00 55 01 46 03 A1 0D 
• レスポンス 
02 00 30 03 46 52 90 03 60 0D 
※取得したRF タグのHandle 値がリーダライタに維持されている状態で 
[UHF_GetHandle]コマンドを実行し、Handle 値 = [52 90]h が返ってきた場合
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_GetHandle / UHF_ThroughCmd / TDR / MNL / PRC / SUM / STX / ETX / ACK / NACK / AI / PDF / RAG / RF / ROM / CR / ON / UP / DOWN / OFF / MSB / 55H / 46H / 02H / 00H / 01H / 03H / 0DH / 30H / 通信フォーマット / リーダライタ / RFタグ / レスポンス / Q値 / ROMバージョン / 55 46 / 5546 / 55_46 / 55h 46h / UHF GetHandle / uhf_gethandle / 55h
