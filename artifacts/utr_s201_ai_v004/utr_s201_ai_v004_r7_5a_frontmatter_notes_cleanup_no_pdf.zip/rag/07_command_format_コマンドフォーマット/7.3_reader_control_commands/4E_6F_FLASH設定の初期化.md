---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【4E 6F】FLASH設定の初期化
topic: リーダライタ制御コマンド
chapter: '07'
source_section: 7.3.11
source_pages: '150'
category: リーダライタ制御コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
source_status: matrix_reference
source_traceability_ref: null
source_traceability_note: "command section metadata present; no R7-5A single source_traceability_matrix trace item"
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.FLASH_INITIALIZE
pdf_cross_checked: false
pdf_cross_checked_note: "not directly registered as a single R7-5A source trace item; section metadata preserved"
matrix_reference:
  - 03_structured_data/command_safety_matrix.yml
command_name: FLASH設定の初期化
command_code: 4Eh
detail_command: 6Fh
command_label: 4E 6F
operation_type: reader_control
ai_code_generation: implementation_prohibited
automatic_send_allowed: false
requires_explicit_user_permission: true
requires_pdf_confirmation: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- FLASH
- ACK
- NACK
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- AI
- PDF
- RAG
- CR
- 4EH
- 6FH
- 02H
- 00H
- 01H
- 03H
- 0DH
- 30H
- 通信フォーマット
- リーダライタ
- レスポンス
- 4E 6F
- 4E6F
- 4E_6F
- 4Eh 6Fh
- FLASH設定の初期化
- flash設定の初期化
- 4Eh
- 6Fh
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- RAM
- 設定保存
- FLASH設定値
- 電源再投入
- 初期化
- チップバージョン
- RF-ASIC
- リスタート
- 再起動
- 2秒待機
- FLASH読込
- Reader Writer
- RW
aliases:
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- FLASH
- ACK
- NACK
- 4EH
- 4E 6F
- 4E6F
- 4E_6F
- 4Eh 6Fh
- FLASH設定の初期化
- 4Eh
- FLASH設定値
- FLASH読込
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.3_リーダライタ制御コマンド/公開_UTR版_【4E 6F】FLASH設定の初期化.md
optimized_path: 07_command_format_コマンドフォーマット/7.3_reader_control_commands/4E_6F_FLASH設定の初期化.md
---
# 【4E 6F】FLASH設定の初期化

    ## コマンドの要約

    FLASH設定の初期化に関するコマンド仕様です。コマンドフレーム、ACKレスポンス、NACKレスポンス、実行例を確認できます。

    ## 何に使うコマンドか

    FLASH設定の初期化を上位機器から実行する際の送信データ作成と受信データ解析に使います。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.3.11 |
    | 参照ページ | 150 |
    | コマンド区分 | リーダライタ制御コマンド |
    | コマンドラベル | 4E 6F |
    | コマンド | 4Eh |
    | 詳細コマンド / サブ情報 | 6Fh |
    | 操作種別 | reader_control |
    | リスク目安 | high |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - コマンドコード、データ長、データ部の順序を確認する。
- SUMはSTXからETXまでを加算した下位1バイトを使用する。
- NACK時は7.6のエラーコードを確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    FLASH設定の初期化, 4E 6F, 4Eh, 6Fh, リーダライタ制御コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.3 リーダライタ制御コマンド 

149 

7.3.11 FLASH 設定の初期化 
リーダライタのFLASH 設定を出荷時設定に戻すコマンドです。 
コマンド実行後はリスタートコマンド、あるいはリーダライタの電源再起動を実行してください。 
※FLASH の汎用ポートまたは拡張ポートの設定を変更した場合は、リスタートが必要です。 

［コマンド］ 


［ACK レスポンス］ 


［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
• コマンド 
02 00 4E 01 6F 03 C3 0D 
• レスポンス 
02 00 30 01 6F 03 A5 0D 


ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
4Eh 
データ長 
1 
01h 
データ部 
1 
6Fh（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 
ラベル名 
バイト数 
内容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
30h（ACK） 
データ長 
1 
01h 
データ部 
1 
6Fh（詳細コマンド） 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / FLASH / ACK / NACK / TDR / MNL / PRC / SUM / STX / ETX / AI / PDF / RAG / CR / 4EH / 6FH / 02H / 00H / 01H / 03H / 0DH / 30H / 通信フォーマット / リーダライタ / レスポンス / 4E 6F / 4E6F / 4E_6F / 4Eh 6Fh / FLASH設定の初期化 / flash設定の初期化 / 4Eh / 6Fh / 通信 / インターフェース / シリアル通信 / TCP/IP / USB / Bluetooth / Wi-Fi / COMポート / データ長 / チェックサム
