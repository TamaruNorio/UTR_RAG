---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 44】UHF_CheckAntenna
topic: リーダライタ制御コマンド
chapter: '07'
source_section: 7.3.5
source_pages: 138-140
category: リーダライタ制御コマンド
chunk_type: command_spec
rag_priority: high
risk_level: low
command_name: UHF_CheckAntenna
command_code: 55h
detail_command: 44h
command_label: 55 44
operation_type: reader_control
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_CheckAntenna
- ACK
- NACK
- TDR
- MNL
- PRC
- SUM
- STX
- ETX
- AI
- PDF
- RAG
- SHR201
- ANT0
- SUN02
- CH
- ANT1
- ANT2
- ANT3
- SUN02V
- ANT4
- ANT5
- ANT6
- ANT7
- ANT8
- CR
- OK
- 55H
- 44H
- 02H
- 00H
- 4CH
- 01H
- 03H
- 8CH
- 04H
- 05H
- 06H
- 07H
- 0DH
- 30H
- 通信フォーマット
- リーダライタ
- アンテナ
- アンテナ番号
- 断線確認
- レスポンス
- 55 44
- '5544'
- '55_44'
- 55h 44h
- UHF CheckAntenna
- uhf_checkantenna
- 55h
- 44h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
aliases:
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_CheckAntenna
- ACK
- NACK
- 55H
- 55 44
- '5544'
- '55_44'
- 55h 44h
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.3_リーダライタ制御コマンド/公開_UTR版_【55 44】UHF_CheckAntenna.md
optimized_path: 07_command_format_コマンドフォーマット/7.3_reader_control_commands/55_44_UHF_CheckAntenna.md
---
# 【55 44】UHF_CheckAntenna

    ## コマンドの要約

    UHF_CheckAntennaに関するコマンド仕様です。コマンドフレーム、ACKレスポンス、NACKレスポンス、実行例を確認できます。

    ## 何に使うコマンドか

    UHF_CheckAntennaを上位機器から実行する際の送信データ作成と受信データ解析に使います。

    ## 基本情報

    | 項目 | 内容 |
    |---|---|
    | シリーズ | UTR |
    | チップセット | R2000 |
    | 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
    | 参照章 | 7.3.5 |
    | 参照ページ | 138-140 |
    | コマンド区分 | リーダライタ制御コマンド |
    | コマンドラベル | 55 44 |
    | コマンド | 55h |
    | 詳細コマンド / サブ情報 | 44h |
    | 操作種別 | reader_control |
    | リスク目安 | low |

    ## コマンドフレーム要点

    - 送信フレームは第5章の共通フォーマットに従います。
    - コマンドコード、データ長、データ部の並びは、下の「公式仕様抜粋」で必ず確認してください。
    - SUM値は、STXからETXまでを1バイト単位で加算し、下位1バイトを使用します。

    ## ACKレスポンス要点

    - 正常応答はACKレスポンスとして返ります。
    - ACKレスポンスのコマンド、データ長、データ部の意味は、下の「公式仕様抜粋」を参照してください。
    - 書き込み系コマンドでは、書き込んだ値がACKレスポンス内で返る場合と、データ長00hのACKのみ返る場合があります。

    ## NACKレスポンス

    NACKレスポンスとエラーコードは、仕様書の「7.6 NACKレスポンスとエラーコード」を参照してください。

    ## 生成AI向けの重要ポイント

    - コマンドコード、データ長、データ部の順序を確認する。
- SUMはSTXからETXまでを加算した下位1バイトを使用する。
- NACK時は7.6のエラーコードを確認する。
    - このコマンドは説明専用です。完成Hex、SUM計算済みコマンド、実機送信用コードは生成しないでください。実機動作はR7では未確認です。
    - 顧客回答で使う場合は、数値・ビット定義・対応機種を原本PDFで再確認してください。

    ## RAG検索キーワード

    UHF_CheckAntenna, 55 44, 55h, 44h, リーダライタ制御コマンド, ACK, NACK, SUM

    ## 公式仕様抜粋

    以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

    ```text
    マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.3 リーダライタ制御コマンド 

137 

7.3.5 
UHF_CheckAntenna 
アンテナの接続確認用のコマンドです。 

［コマンド］ 



ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
コマンド 
1 
55h 
データ長 
1 
02h  
データ部 
1 
44h（詳細コマンド） 
1 
アンテナ番号 
UTR-S201 の場合 
UTR-SHR201 の場合 
00h : ANT0 
UTR-SUN02-4CH 
の場合 
00h : ANT0 
01h : ANT1 
02h : ANT2 
03h : ANT3 
UTR-SUN02V-8CH 
の場合 
UTR-SUN02-8CH 
の場合 
00h : ANT1 
01h : ANT2 
02h : ANT3 
03h : ANT4 
04h : ANT5 
05h : ANT6 
06h : ANT7 
07h : ANT8 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.3 リーダライタ制御コマンド 

138 

［ACK レスポンス］ 



ラベル名 
バイト数 
内 容 
STX 
1 
02h 
アドレス 
1 
00h（「5.2 通信フォーマットの詳細」参照） 
ACK 
1 
30h（ACK） 
データ長 
1 
03h 
データ部 
1 
44h（詳細コマンド） 
1 
アンテナ番号 
UTR-S201 の場合 
UTR-SHR201 の場合 
00h : ANT0 
UTR-SUN02-4CH 
の場合 
00h : ANT0 
01h : ANT1 
02h : ANT2 
03h : ANT3 
UTR-SUN02V-8CH 
の場合 
UTR-SUN02-8CH 
の場合 
00h : ANT1 
01h : ANT2 
02h : ANT3 
03h : ANT4 
04h : ANT5 
05h : ANT6 
06h : ANT7 
07h : ANT8 
1 
接続情報 
00h 
：アンテナの接続OK 
01h 
：アンテナの接続エラー 
02h 
：アンテナがパラメータ異常 
ETX 
1 
03h 
SUM 
1 
SUM 値（「5.3 SUM の計算方法」参照） 
CR 
1 
0Dh 

マニュアル番号： 
TDR-MNL-PRC-UTR-S201-117 
第7 章 コマンドフォーマット 
7.3 リーダライタ制御コマンド 

139 

● 接続情報 
アンテナ番号で指定した出力端子のアンテナの断線確認を実施し、その接続状態により 
以下のレスポンスが返ります。 
[00h: アンテナの接続OK] 
適切にアンテナが接続されており、アンテナのマッチングが良好の場合 
[01h: アンテナの接続エラー] 
断線確認した出力端子にアンテナが接続されていない場合や、接続されたアンテナのマッ
チングが極端にずれている場合 
※アンテナ周囲の誘電体(水分や人体を含む)や金属物等の影響により、アンテナの特性に
影響を与える場合があります。アンテナの特性が極端に悪くなった場合、リーダライタ
は、アンテナの断線を検知する場合があります。 
アンテナは、周囲環境の影響を受けない場所に設置してください。 

[02h: アンテナがパラメータ異常] 
存在しないアンテナ番号を選択した場合 
・機種により、アンテナポート数が異なります。機種ごとのアンテナポート数は下表の通り
です。 
製品の種類 
製品型式 
アンテナ 
ポート数 
備考 
据置型 
UTR-SUN02-4CH 
4 
ANT0～ANT3 が設定可能 
UTR-SUN02V-8CH 
8 
ANT1～ANT8 が設定可能 
UTR-SUN02-8CH 
8 
ANT1～ANT8 が設定可能 
基板モジュール型 
UTR-S201 
1 
ANT0 のみ設定可能 
ハンディ型 
UTR-SHR201 
1 
ANT0 のみ設定可能 


［NACK レスポンス］ 
「7.6 NACK レスポンスとエラーコード」参照。 


［コマンド／レスポンス例］ 
• コマンド 
02 00 55 02 44 00 03 A0 0D 
• レスポンス 
02 00 30 03 44 00 00 03 7C 0D  
ANT0 ↑  ↑アンテナの接続OK
    ```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_CheckAntenna / ACK / NACK / TDR / MNL / PRC / SUM / STX / ETX / AI / PDF / RAG / SHR201 / ANT0 / SUN02 / CH / ANT1 / ANT2 / ANT3 / SUN02V / ANT4 / ANT5 / ANT6 / ANT7 / ANT8 / CR / OK / 55H / 44H / 02H / 00H / 4CH / 01H / 03H / 8CH / 04H / 05H / 06H / 07H / 0DH / 30H / 通信フォーマット
