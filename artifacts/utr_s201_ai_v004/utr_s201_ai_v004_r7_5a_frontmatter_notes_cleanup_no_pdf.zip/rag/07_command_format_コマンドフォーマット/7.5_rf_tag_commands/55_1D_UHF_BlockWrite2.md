---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 1D】UHF_BlockWrite2
topic: RFタグ通信コマンド
chapter: '07'
source_section: 7.5.9
source_pages: 288-290
category: RFタグ通信コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
command_name: UHF_BlockWrite2
command_code: 55h
detail_command: 1Dh
command_label: 55 1D
operation_type: bulk_write_memory
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_BLOCK_WRITE2
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_BLOCK_WRITE2
executable_hex_output: prohibited
checksum_policy: placeholder_only
automatic_send_allowed: false
requires_actual_device_check: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_BlockWrite2
- UHF_BlockWrite
- RF
- TDR
- MNL
- PRC
- STX
- MSB
- ETX
- SUM
- CR
- ACK
- NACK
- AI
- FLASH
- RAG
- PDF
- ISO18000
- 55H
- 1DH
- 05H
- 02H
- 03H
- 0DH
- 30H
- リーダライタ
- RFタグ
- レスポンス
- MemBank
- パスワード
- Write
- 55 1D
- 551D
- 55_1D
- 55h 1Dh
- UHF BlockWrite2
- uhf_blockwrite2
- 55h
- 1Dh
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- SUM計算
- チェックサム
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- UHF_Write
- 書き込み
- EPC書き換え
- WordPtr
- WriteData
- RAM
- 設定保存
aliases:
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_BlockWrite2
- UHF_BlockWrite
- ACK
- NACK
- FLASH
- 55H
- 55 1D
- 551D
- 55_1D
- 55h 1Dh
- 55h
- UHF_Write
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 1D】UHF_BlockWrite2.md
optimized_path: 07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1D_UHF_BlockWrite2.md
---
# 【55 1D】UHF_BlockWrite2

## コマンドの要約

RFタグに最大124 Wordのデータを一括書き込みするためのコマンドです。大量データを書き込む場合、UHF_BlockWriteより処理時間を短縮できる可能性がありますが、RFタグ側のBlockWrite対応とタイムアウトに注意が必要です。

## 何に使うコマンドか

BlockWrite対応タグに対して、大きめのデータを高速に一括書き込みする。

## 基本情報

| 項目 | 内容 |
|---|---|
| シリーズ | UTR |
| チップセット | R2000 |
| 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
| 参照章 | 7.5.9 |
| 参照ページ | 288-290 |
| コマンド区分 | RFタグ通信コマンド |
| コマンド | 55h |
| 詳細コマンド | 1Dh |
| データ長 | 05h + 書き込みWord数*2 |
| 操作種別 | bulk_write_memory |
| リスク目安 | medium |

## コマンドフレーム要点

| 項目 | バイト数 | 内容 |
|---|---:|---|
| STX | 1 | 02h |
| アドレス | 1 | 通常00h |
| コマンド | 1 | 55h |
| データ長 | 1 | 05h + 書き込みWord数*2 |
| データ部 | 1 | 1Dh: 詳細コマンド |
| パラメータ1 | 1 | MemBank指定 |
| 書き込み開始Wordアドレス | 2 | MSBファースト |
| 書き込みWord数 | 1 | 最大124 Word |
| 書き込みデータ | Word数*2 | 最大124 Word |
| ETX | 1 | 03h |
| SUM | 1 | SUM値 |
| CR | 1 | 0Dh |

## ACKレスポンス要点

- ACKレスポンス: コマンド30h、詳細コマンド1Dh。

## NACKレスポンス

NACKレスポンスとエラーコードは、仕様書の「7.6 NACK レスポンスとエラーコード」を参照してください。

## 生成AI向けの重要ポイント

- UHF_BlockWrite2は、RFタグへBlockWriteコマンドを一括送信します。タグによっては2 Word以上または3 Word以上のBlockWriteに対応していない場合があります。
- 書き込みデータ量が大きいため、RFタグの応答タイミングが遅くなりやすく、FLASHアドレス5ChのBlockWriteタイムアウト設定が関係します。
- 書き込み開始Wordアドレスは2バイト、書き込みWord数は1バイトです。UHF_BlockWriteの4バイト開始アドレス/2バイトWord数と混同しないでください。

## 対応状況メモ

6.2.3の対応表では、対象UTR-S201シリーズ機種で対応。

## RAG検索キーワード

BlockWrite2, 一括書き込み, 最大124Word, 高速書き込み, BlockWriteタイムアウト, 30h 1Dh

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
7.5.9   UHF_BlockWrite2
  RFタグに最大124[Word]のデータを一括書き込みするためのコマンドです。
  RFタグに大容量データを書き込む場合に、本コマンドを使用することで、[UHF_BlockWrite]コマ
  ンドと比較して処理時間を短くすることができます。

  本コマンドを実行すると、ISO18000-63 規格で規定された、[Select], [Query], [Access],
  [BlockWrite]などのコマンドを、リーダライタが自動的に順次実行します。
    ※リーダライタと RF タグ間で実行されるコマンドの詳細は、
                                 「3.10 RF タグ通信コマンド実行時の
     リーダライタの内部処理」をご参照ください。
    ※読み書き対象の RF タグが 1 枚となるように、あらかじめ[Select]コマンドのマスク条件や
     [Query]コマンドのパラメータを設定した状態で本コマンドを実行してください。
     複数の RF タグが応答を返す状態でコマンドを実行すると、意図しない RF タグに対して
     コマンドが実行されたり、コマンドの実行に失敗したりする可能性があります。
    ※リーダライタの Access パスワードに[0000 0000]h 以外が設定されている場合には、書き込みす
     る MemBank によらず、必ず、[Access]コマンドが発行されます。


  ＜UHF_BlockWriteコマンドとUHF_BlockWrite2コマンドの違い＞
    ・[UHF_BlockWrite]コマンドは、上位機器から指定した最大32[Word]のデータを、
     1[Word]単位で、RFタグにBlockWriteコマンドまたはWriteコマンドで送信します。
    ・[UHF_BlockWrite2]コマンドは、上位機器から指定した最大124[Word]のデータを、
     一括で、RFタグにBlockWriteコマンドを送信します。
        ・BlockWrite コマンドは、ISO18000-63 では RF タグのオプションコマンドのため、一部の
         RF タグでは対応していません。詳細は「4.2.7 RF タグオプションコマンド対応表」または
         使用する RF タグ Chip のデータシートを参照ください。
        ・一部のRFタグでは、2[Word]または3[Word]以上のBlockWriteコマンドに対応していないた
         め、本コマンドを使用しての書き込みができません。
         詳細は、使用するRFタグのデータシートを参照するか、あらかじめ書き込みの可否および
         書き込み精度の動作確認をおこなったうえでご使用ください。
        ・一度に書き込みするデータ量が大きいため、RFタグからのレスポンスが返るタイミング
         が、他のコマンドと比較して遅くなる傾向があります。本コマンドを実行した際の
         BlockWriteコマンドのタイムアウト時間は、FLASHアドレス92([5C]h)に設定していま
         す。指定時間以内にRFタグからの応答が返らない場合、リーダライタはNACK応答を返し
         ます。
        ※弊社にて動作確認しているRFタグのChip：
          Fujitsu社製 MB97R8110、Alien社製 Higgs EC
             ※書き込みWord数が多い場合、タイムアウト時間の設定可能範囲の20[msec]以内に
              RFタグからの応答が返らないことがありますので、必ず実機で検証を実施してか
              らご使用ください。


［コマンド］
ラベル名 バイト数                            内容
 STX   1          02h
アドレス   1          00h（「5.2 通信フォーマットの詳細」参照）
コマンド   1          55h
データ長   1          05h+（書き込み Word 数×2）
            1     1Dh（詳細コマンド）
                  パラメータ 1
                          MemBank ※左側が上位 bit
                         00   ：Reserved
                  bit0
            1            01   ：EPC(UII)
                  bit1
                         10   ：TID
                         11   ：User
                  bit2-7 将来拡張のための予約（通常は 0）
データ部
                  書き込み開始 Word アドレス
                    メモリ上の書き込み開始位置（Word 単位）
            2
                    1 バイト目：上位バイト（MSB）
                    2 バイト目：下位バイト（LSB）
           1      書き込み Word 数
         書き込み
         Word 数   書き込みデータ（最大 124[Word]）
           ×2
 ETX       1      03h
 SUM       1      SUM 値（「5.3 SUM の計算方法」参照）
  CR       1      0Dh


＜コマンドパラメータ＞
● MemBank
   書き込むメモリ領域を指定します。
   詳細は、  「4.2RF タグのメモリ構造」の項を参照ください。

● 書き込み開始Wordアドレス
   指定した MemBank 上の書き込み開始位置（Word アドレス）を指定します。

● 書き込み Word 数
   書き込むメモリのサイズを Word 長（2 [byte]単位）で指定します。

● 書き込みデータ
   書き込むデータを指定します。


［ACK レスポンス］
ラベル名 バイト数                                            内容
 STX          1      02h
アドレス          1      00h（「5.2 通信フォーマットの詳細」参照）
 ACK          1      30h
データ長          1      01h
データ部          1      1Dh（詳細コマンド）
 ETX          1      03h
 SUM          1      SUM 値（「5.3 SUM の計算方法」参照）
  CR          1      0Dh


［NACK レスポンス］
 「7.6 NACK レスポンスとエラーコード」参照。


［コマンド／レスポンス例］
    (例) UHF_BlockWrite2 コマンドを使用して、Alien 社製 HiggsEC の Chip を搭載する
        RF タグに書き込む場合
         データ種類                           数値／パラメータ                   コマンド列
         MemBank                         11: User                   03
         書き込み Word 開始アドレス                0                          00 00
         書き込み Word 数                     8                          08
         書き込みデータ                         0101 0202 0303 0404        同左
                                         0505 0606 0707 0808
    • コマンド
      02 00 55 15 1D 03 00 00 08 01 01 02 02 03 03 04 04 05 05 06 06 07 07 08 08 03 DF 0D
    • レスポンス
      02 00 30 01 1D 03 53 0D


［UHF_BlockWrite2 コマンドによる書き込み時間の短縮例］
    ・Alien 社製 HiggsEC の Chip を搭載する RF タグに対して、User 領域の Word アドレス
     [00]h から 8[Word]の書き込みを以下の条件で実行し、処理時間を計測しました。
       (1) [UHF_BlockWrite]コマンドを、[BlockWrite コマンド:使用する]の設定で実行
             → BlockWrite コマンドが 1[Word]単位で 8 回実行されます。
             → 平均実行時間：89[msec]
       (2) [UHF_BlockWrite]コマンドを、[BlockWrite コマンド:使用しない]の設定で実行
             → Write コマンドが 1[Word]単位で 8 回実行されます。
             → 平均実行時間：109[msec]
       (3) [UHF_BlockWrite2]コマンドを使用
             → BlockWrite コマンドが 8[Word]一括送信で 1 回実行されます。
             → 平均実行時間：64[msec]
```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_BlockWrite2 / UHF_BlockWrite / RF / TDR / MNL / PRC / STX / MSB / ETX / SUM / CR / ACK / NACK / AI / FLASH / RAG / PDF / ISO18000 / 55H / 1DH / 05H / 02H / 03H / 0DH / 30H / リーダライタ / RFタグ / レスポンス / MemBank / パスワード / Write / 55 1D / 551D / 55_1D / 55h 1Dh / UHF BlockWrite2 / uhf_blockwrite2 / 55h / 1Dh / 通信 / インターフェース / シリアル通信
