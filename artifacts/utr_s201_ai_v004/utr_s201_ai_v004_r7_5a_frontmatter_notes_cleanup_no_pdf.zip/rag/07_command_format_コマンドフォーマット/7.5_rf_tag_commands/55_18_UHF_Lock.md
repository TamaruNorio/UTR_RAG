---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 18】UHF_Lock
topic: RFタグ通信コマンド
chapter: '07'
source_section: 7.5.6
source_pages: 278-282
category: RFタグ通信コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
command_name: UHF_Lock
command_code: 55h
detail_command: 18h
command_label: 55 18
operation_type: lock_or_unlock_tag_memory
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_LOCK
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_LOCK
executable_hex_output: prohibited
checksum_policy: placeholder_only
ai_code_generation: implementation_prohibited
automatic_send_allowed: false
requires_actual_device_check: true
requires_explicit_user_permission: true
requires_pdf_confirmation: true
safety_note: UHF_Lock はRFタグメモリのロック状態に不可逆影響を与える可能性があるため critical と扱い、実装は禁止します。
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Lock
- UHF_Write
- UHF_BlockWrite
- RF
- EPC
- TID
- TDR
- MNL
- PRC
- STX
- ETX
- SUM
- CR
- ACK
- NACK
- AI
- RAG
- PDF
- ISO18000
- 55H
- 18H
- 04H
- 02H
- 03H
- 0DH
- 30H
- 00H
- 通信フォーマット
- リーダライタ
- RFタグ
- レスポンス
- パスワード
- Kill
- Lock
- Write
- 55 18
- '5518'
- '55_18'
- 55h 18h
- UHF Lock
- uhf_lock
- 55h
- 18h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- 書き込み
- EPC書き換え
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Lock
- UHF_Write
- UHF_BlockWrite
- ACK
- NACK
- 55H
- Kill
- Lock
- 55 18
- '5518'
- '55_18'
- 55h 18h
- UHF Lock
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 18】UHF_Lock.md
optimized_path: 07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_18_UHF_Lock.md
---
# 【55 18】UHF_Lock

> 安全注意: UHF_Lock はRFタグメモリのロック状態に不可逆影響を与える可能性があるため critical と扱い、実装は禁止します。

## コマンドの要約

RFタグのEPC、TID、User、Access Password、Kill Password領域に対して、読み書きロックの設定または解除をおこなうコマンドです。Mask/Actionビットで対象と処理内容を指定します。PermaLockは解除できないため特に注意が必要です。

## 何に使うコマンドか

Access Password認証を前提に、RFタグメモリのロック状態を制御する。

## 基本情報

| 項目 | 内容 |
|---|---|
| シリーズ | UTR |
| チップセット | R2000 |
| 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
| 参照章 | 7.5.6 |
| 参照ページ | 278-282 |
| コマンド区分 | RFタグ通信コマンド |
| コマンド | 55h |
| 詳細コマンド | 18h |
| データ長 | 04h |
| 操作種別 | lock_or_unlock_tag_memory |
| リスク目安 | high |

## コマンドフレーム要点

| 項目 | バイト数 | 内容 |
|---|---:|---|
| STX | 1 | 02h |
| アドレス | 1 | 通常00h |
| コマンド | 1 | 55h |
| データ長 | 1 | 04h |
| データ部 | 1 | 18h: 詳細コマンド |
| パラメータ1 | 1 | Mask系ビット |
| パラメータ2 | 1 | ActionおよびMask系ビット |
| パラメータ3 | 1 | Action系ビット |
| ETX | 1 | 03h |
| SUM | 1 | SUM値 |
| CR | 1 | 0Dh |

## ACKレスポンス要点

- ACKレスポンス: コマンド30h、詳細コマンド18h。

## NACKレスポンス

NACKレスポンスとエラーコードは、仕様書の「7.6 NACK レスポンスとエラーコード」を参照してください。

## 生成AI向けの重要ポイント

- 本コマンドは、リーダライタのAccessパスワードに0000 0000h以外が設定された状態で実行する必要があります。
- Mask=1の対象だけActionが反映されます。Action=1はロック設定、Action=0はロック解除です。
- PermaLockを実行するとロック状態を変更できなくなるため、コード生成時や手順説明時は必ず警告してください。
- Lock操作後、不要であればリーダライタ側のAccessパスワードを0000 0000hへ戻してください。

## 対応状況メモ

6.2.3の対応表では、対象UTR-S201シリーズ機種で対応。

## RAG検索キーワード

Lock, ロック, 解除, Mask, Action, PermaLock, Access Password, 30h 18h

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
7.5.6   UHF_Lock
  RFタグへの読み書きができないようにロックを[設定]／[解除]するコマンドです。

  本コマンドを実行すると、ISO18000-63 規格で規定された、[Select], [Query], [Access], [Lock]など
  のコマンドを、リーダライタが自動的に順次実行します。
    ※リーダライタと RF タグ間で実行されるコマンドの詳細は、
                                 「3.10 RF タグ通信コマンド実行時の
     リーダライタの内部処理」をご参照ください。
    ※読み書き対象の RF タグが 1 枚となるように、あらかじめ[Select]コマンドのマスク条件や
     [Query]コマンドのパラメータを設定した状態で本コマンドを実行してください。
     複数の RF タグが応答を返す状態でコマンドを実行すると、意図しない RF タグに対して
     コマンドが実行されたり、コマンドの実行に失敗したりする可能性があります。
    ※本コマンドは、リーダライタの Access パスワードにあらかじめ[0000 0000]以外が設定された
     状態で実行する必要があります。

  RFタグのロックを[設定]／[解除]するためには、RFタグのAccess Password領域(Reserved領域の
  Wordアドレス[02]hから2[Word])に、[0000 0000]h以外のAccess Passwordを書き込んだ状態で
  [UHF_Lock]コマンドを実行し、リーダライタに設定されたAccessパスワードと、RFタグに書き込
  まれたAccess Passwordが一致する必要があります。
    ※1：リーダライタに設定するパスワードは、[Accessパスワードの書き込み]コマンドを
       使用しておこないます。
    ※2：RFタグへ設定するパスワードは、[UHF_Write]コマンドまたは[UHF_BlockWrite]コマンド
       を使用して事前に書き込みます。


［コマンド］
ラベル名 バイト数                                    内容
 STX   1         02h
アドレス   1         00h（ 「5.2 通信フォーマットの詳細」参照）
コマンド   1         55h
データ長   1         04h
       1         18h（詳細コマンド）
                 パラメータ 1
                  ビット             処理対象              処理種別             フラグ
                 bit0     TID 領域               PermaLock            Mask
                 bit1     TID 領域               PasswordWrite        Mask
                 bit2     EPC 領域               PermaLock            Mask
            1
                 bit3     EPC 領域               PasswordWrite        Mask
                 bit4     Access Password 領域   PermaLock            Mask
                 bit5     Access Password 領域   PasswordRead/Write   Mask
                 bit6     Kill Password 領域     PermaLock            Mask
                 bit7     Kill Password 領域     PasswordRead/Write   Mask
                 パラメータ 2
                  ビット             処理対象              処理種別             フラグ
                 bit0     EPC 領域               PermaLock            Action
                 bit1     EPC 領域               PasswordWrite        Action
データ部             bit2     Access Password 領域   PermaLock            Action
            1
                 bit3     Access Password 領域   PasswordRead/Write   Action
                 bit4     Kill Password 領域     PermaLock            Action
                 bit5     Kill Password 領域     PasswordRead/Write   Action
                 bit6     User 領域              PermaLock            Mask
                 bit7     User 領域              PasswordWrite        Mask
                 パラメータ 3
                  ビット             処理対象              処理種別             フラグ
                 bit0     0 固定
                 bit1     0 固定
                 bit2     0 固定
            1
                 bit3     0 固定
                 bit4     User 領域              PermaLock            Action
                 bit5     User 領域              PasswordWrite        Action
                 bit6     TID 領域               PermaLock            Action
                 bit7     TID 領域               PasswordWrite        Action
 ETX        1    03h
 SUM        1    SUM 値（  「5.3 SUM の計算方法」参照）
  CR        1    0Dh


＜コマンドパラメータ＞
  各 bit にアサインされている「処理対象」「処理種別」「フラグ」について説明します。

  ● 処理対象と処理種別
     [Lock]コマンドの処理対象となる領域が以下の 5 種準備されており、            それぞれの領域に対して、
     「PasswordWrite」または「PasswordRead/Write」、
                                           「PermaLock」を実行することができま
     す。
            処理種別                              具体的な処理内容
                            ・Access パスワード認証無しの場合
                              Read は可能だが Write は不可
      PasswordWrite         ・Access パスワード認証有りの場合
                              Read も Write も可能
                            ・Lock 状態は[設定]または[解除]に変更が可能。
                            ・Access パスワード認証無しの場合
                              Read も Write も不可
      PasswordRead/Write    ・Access パスワード認証有りの場合
                              Read も Write も可能
                            ・Lock 状態は[設定]または[解除]に変更が可能。
                            設定した Lock 状態（解除／設定）を変更不可とする。
                            Lock 状態は恒久的に保持され、変更はできません。
                            ・Lock 状態が[解除]された状態で PermaLock すると、
      PermaLock
                              Lock 状態を[設定]に変更できなくなる。
                            ・Lock 状態が[設定]された状態で PermaLock すると、
                              Lock 状態を[解除]に変更できなくなる。

              処理対象                    設定可能な処理種別
                               Password Write
       EPC 領域
                               PermaLock
                               Password Write
       TID 領域
                               PermaLock
                               Password Write
       User 領域
                               PermaLock
                               Password Read/Write
       Access Password 領域
                               PermaLock
                               Password Read/Write
       Kill Password 領域
                               PermaLock
  ※：Write Lock とは、Read はできるが Write はできない状態です。
    ・Access パスワードの認証無しの場合、Read はできますが、Write はできません。
    ・Access パスワードの認証有りの場合、Read も Write も可能となります。
  ※：Read/Write Lock とは、Read も Write もできない状態です。
    ・Access パスワードの認証無しの場合、Read も Write もできません。
    ・Access パスワードの認証有りの場合、Read も Write も可能となります。
  ※：PermaLock を実行しなければ、Write Lock 状態または Read/Write Lock 状態を何度でも[設
    定]／[解除]することが可能です。  （事前の Access パスワード認証が必要）
  ※：PermaLock 実行後は、Lock 状態（[設定]／[解除]）を変更することができなくなります。
       ・Write Lock を[設定]した状態で PermaLock を実行すると、その領域に対する
        Write ができなくなり、Write Lock の[解除]ができない状態となります。
       ・Write Lock を[解除]した状態で PermaLock を実行すると、その領域に対する
        Write できますが、Write Lock が[設定]できない状態となります。


  ● フラグ
     上記「処理対象+処理種別」ごとに、2 つのフラグが準備されています。
     各フラグを「0」または「1」にセットすることで、処理内容が変わります。

       フラグ       セットする値                   処理内容
                           指定した「処理対象+処理種別」に対し、
                     0
                           Action の値を書き込まない
        Mask
                           指定した「処理対象+処理種別」に対し、
                     1
                           Action の値を書き込む
                     0     Lock の[解除]を実行
       Action
                     1     Lock の[設定]を実行
     [Mask]フラグが 1 にセットされた「処理対象+処理種別」のみ、同じ「処理対象+処理種別」
     の[Action]の値が RF タグに書き込まれます。

     ※Lock 状態を[設定]も[解除]もしない領域に対しては、[Mask=0]のフラグとしてコマンドを
      実行します。[Action]は 0 でも 1 でも結果は変わりません。
                    「処理対象+処理種別」のフラグを、[Mask=1], [Action=1]に
     ※Lock を[設定]する場合、
      セットして実行します。
                    「処理対象+処理種別」のフラグを、[Mask=1], [Action=0]に
     ※Lock を[解除]する場合、
      セットして実行します。
     ※処理種別が PermaLock の場合、一度 Lock 状態を[設定]すると、その後[Mask=1],
     [Action=0]として再度実行しても、PermaLock を[解除]することはできません。


＜注意事項＞
 [UHF_Lock]コマンドを実行した直後は、リーダライタおよび RF タグに同じ Access パスワードが
 書き込まれた状態となっているため、[UHF_Lock]コマンドで Write Lock を設定しても、直後に
 [UHF_Write]コマンドや[UHF_BlockWrite]コマンドを実行した場合に書き込める場合があります。

  [UHF_Lock]コマンドを使わない時は、[Access パスワードの書き込み]コマンドを使用して、リー
  ダライタ側の Access パスワードを[0000 0000]h に戻してください。

    ※リーダライタ側の Access パスワードを設定したままにすると、異なる Access パスワードを持
     つ RF タグや、Access パスワードが設定されていない RF タグに対して、読み書きができなく
     なります。
    ※リーダライタの電源を切ったり、[リスタート]コマンドを実行したりした場合にも、Access パ
     スワードは[0000 0000]h に戻ります。


［ACK レスポンス］
ラベル名 バイト数                                       内容
 STX         1      02h
アドレス         1      00h（「5.2 通信フォーマットの詳細」参照）
 ACK         1      30h
データ長         1      01h
データ部         1      18h（詳細コマンド）
 ETX         1      03h
 SUM         1      SUM 値（「5.3 SUM の計算方法」参照）
  CR         1      0Dh


［NACK レスポンス］
 「7.6 NACK レスポンスとエラーコード」参照。


［コマンド／レスポンス例］
    (例 1) User 領域の Password Write Lock を[設定]する場合
         データ種類            処理対象              処理種別          フラグ       コマンド列
        パラメータ 1               ―               ―             ―         00
        パラメータ 2        bit7: User 領域     PasswordWrite   Mask=1       80
        パラメータ 3        bit5: User 領域     PasswordWrite   Action=1     20

    Mask=1 が設 定されている領域の み Action が実行されま す。上記の場合、 User 領域の
    PasswordWrite の Action が実行されます。その他の領域の Lock 状態は変更されません。
    User 領域の PasswordWrite の Action=1 のため、User 領域の PasswordWrite が[設定]されます
    （Lock された状態となります）        。
    • コマンド
       02 00 55 04 18 00 80 20 03 16 0D
    • レスポンス
       02 00 30 01 18 03 4E 0D


    (例 2) User 領域の Password Write Lock を[解除]する場合
         データ種類            処理対象              処理種別          フラグ       コマンド列
        パラメータ 1               ―               ―             ―         00
        パラメータ 2        bit7: User 領域     PasswordWrite   Mask=1       80
        パラメータ 3        bit5: User 領域     PasswordWrite   Action=0     00

    Mask=1 が設 定されている領域の み Action が実行されま す。上記の場合、 User 領域の
    PasswordWrite の Action が実行されます。その他の領域の Lock 状態は変更されません。
    User 領域の PasswordWrite の Action=0 のため、User 領域の PasswordWrite が無効となりま
    す（Lock が解除された状態となります）           。
    • コマンド
       02 00 55 04 18 00 80 00 03 F6 0D
    • レスポンス
       02 00 30 01 18 03 4E 0D
```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Lock / UHF_Write / UHF_BlockWrite / RF / EPC / TID / TDR / MNL / PRC / STX / ETX / SUM / CR / ACK / NACK / AI / RAG / PDF / ISO18000 / 55H / 18H / 04H / 02H / 03H / 0DH / 30H / 00H / 通信フォーマット / リーダライタ / RFタグ / レスポンス / パスワード / Kill / Lock / Write / 55 18 / 5518 / 55_18 / 55h 18h / UHF Lock / uhf_lock / 55h
