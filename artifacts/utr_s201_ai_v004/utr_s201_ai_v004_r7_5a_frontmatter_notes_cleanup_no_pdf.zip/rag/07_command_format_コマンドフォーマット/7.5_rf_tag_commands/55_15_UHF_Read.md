---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 15】UHF_Read
topic: RFタグ通信コマンド
chapter: '07'
source_section: 7.5.3
source_pages: 271-273
category: RFタグ通信コマンド
chunk_type: command_spec
rag_priority: high
risk_level: high
command_name: UHF_Read
command_code: 55h
detail_command: 15h
command_label: 55 15
operation_type: read_memory
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Read
- UHF_InventoryRead
- UHF_SetSelectParam
- RF
- TDR
- MNL
- PRC
- STX
- MSB
- ETX
- SUM
- CR
- ACK
- NACK
- AI
- RAG
- PDF
- ISO18000
- EPC
- UII
- TID
- 'ON'
- 'OFF'
- 55H
- 15H
- 07H
- 02H
- 03H
- 0DH
- 30H
- 00H
- 通信フォーマット
- リーダライタ
- RFタグ
- アンテナ
- レスポンス
- MemBank
- パスワード
- Read
- 55 15
- '5515'
- '55_15'
- 55h 15h
- UHF Read
- uhf_read
- 55h
- 15h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Read
- UHF_InventoryRead
- UHF_SetSelectParam
- ACK
- NACK
- 55H
- 55 15
- '5515'
- '55_15'
- 55h 15h
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 15】UHF_Read.md
optimized_path: 07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_15_UHF_Read.md
ai_code_generation: explanation_only_until_verified
requires_single_tag_assumption: true
multi_tag_environment_risk: collision
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_READ
executable_hex_output: prohibited
checksum_policy: placeholder_only
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_READ
source_status: pdf_cross_checked
---
## R6 integration note

This chunk now references the central command safety matrix and source traceability matrix. If local metadata conflicts with the matrix, use the stricter safety profile.

# 【55 15】UHF_Read

## コマンドの要約

MemBank、読み取り開始Wordアドレス、読み取りWord数を指定して、RFタグのメモリデータを読み取るコマンドです。1回で1-32 Wordの読み取りが可能です。

## 何に使うコマンドか

対象RFタグを1枚に絞ったうえで、指定メモリ領域のデータをWord単位で読み取る。

## 基本情報

| 項目 | 内容 |
|---|---|
| シリーズ | UTR |
| チップセット | R2000 |
| 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
| 参照章 | 7.5.3 |
| 参照ページ | 271-273 |
| コマンド区分 | RFタグ通信コマンド |
| コマンド | 55h |
| 詳細コマンド | 15h |
| データ長 | 07h |
| 操作種別 | read_memory |
| リスク目安 | low |

## コマンドフレーム要点

| 項目 | バイト数 | 内容 |
|---|---:|---|
| STX | 1 | 02h |
| アドレス | 1 | 通常00h |
| コマンド | 1 | 55h |
| データ長 | 1 | 07h |
| データ部 | 1 | 15h: 詳細コマンド |
| パラメータ1 | 1 | MemBank指定 |
| 読み取り開始Wordアドレス | 4 | MSBファースト |
| 読み取りWord数 | 1 | 1-32 Word |
| ETX | 1 | 03h |
| SUM | 1 | SUM値 |
| CR | 1 | 0Dh |

## ACKレスポンス要点

- ACKレスポンス: コマンド30h、詳細コマンド15h、データ長、読み取りデータを含みます。

## NACKレスポンス

NACKレスポンスとエラーコードは、仕様書の「7.6 NACK レスポンスとエラーコード」を参照してください。

## 生成AI向けの重要ポイント

- 複数のRFタグが応答する状態では、意図しないRFタグを読んだりコマンドに失敗したりする可能性があります。Select条件などで対象を1枚にしてください。
- リーダライタのAccessパスワードが0000 0000h以外の場合、MemBankによらずAccessコマンドが発行されます。
- ACKレスポンスは30h/15hで、データ長nと読み取りデータnバイトを返します。

## 対応状況メモ

6.2.3の対応表では、対象UTR-S201シリーズ機種で対応。

## RAG検索キーワード

Read, 読み取り, MemBank, Wordアドレス, Accessパスワード, 30h 15h

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
7.5.3   UHF_Read
  MemBank と Word アドレスを指定し、RF タグのデータを読み取るコマンドです。
  読み取り範囲は Word 単位で指定し、一度に 1～32[Word]までの読み取りが可能です。

  本コマンドを実行すると、ISO18000-63 規格で規定された、[Select], [Query], [Access], [Read]など
  のコマンドを、リーダライタが自動的に順次実行します。
    ※リーダライタと RF タグ間で実行されるコマンドの詳細は、
                                 「3.10 RF タグ通信コマンド実行時の
     リーダライタの内部処理」をご参照ください。
    ※読み書き対象の RF タグが 1 枚となるように、あらかじめ[Select]コマンドのマスク条件や
     [Query]コマンドのパラメータを設定した状態で本コマンドを実行してください。
     複数の RF タグが応答を返す状態でコマンドを実行すると、意図しない RF タグに対して
     コマンドが実行されたり、コマンドの実行に失敗したりする可能性があります。
    ※アンテナの交信範囲にある複数枚の RF タグの指定 MemBank のデータを同時に読み取りする
     場合には、[UHF_InventoryRead]コマンドの使用も併せてご検討ください。
    ※リーダライタの Access パスワードに[0000 0000]以外が設定されている場合には、読み取りする
     MemBank によらず、必ず[Access]コマンドが発行されます。


 ［コマンド］
 ラベル名 バイト数                               内容
  STX   1          02h
 アドレス   1          00h（ 「5.2 通信フォーマットの詳細」参照）
 コマンド   1          55h
 データ長   1          07h
              1    15h（詳細コマンド）
                   パラメータ 1
                            MemBank ※左側が上位 bit
                            00     ：Reserved
                   bit0
              1             01     ：EPC(UII)
                   bit1
                            10     ：TID
 データ部
                            11     ：User
                   bit2-7   将来拡張のための予約（通常は     0）
                   読み取り開始 Word アドレス
              4
                     RF タグのメモリ上の読み取り開始位置（Word 単位）
                   読み取り Word 数
              1
                     読み出す Word 数（1～32）
   ETX        1    03h
   SUM        1    SUM 値（「5.3 SUM の計算方法」参照）
    CR        1    0Dh


＜注意事項＞
  ・[RF送信信号の制御]コマンドを「キャリアON」または「キャリアOFF→ON」の設定で実行
   し、リーダライタが「キャリアONの維持状態」で動作している場合においても、本コマンド実
   行前に[UHF_SetSelectParam]コマンドを実行して、対象となるRFタグが1枚となるようにマス
   ク指定してください。
     ※RFタグの読み取りに失敗してNACK応答となった場合、リーダライタは維持しているRFタ
      グのハンドル情報を破棄します。
      上位機器からリトライ処理を実行すると、リーダライタは[Query]コマンドを再度実行し、
      RFタグのハンドル情報を再度取得します。
      その際に、複数枚のRFタグが読み取りできる環境・設定にある場合、前回と異なるRFタグ
      のハンドルを取得する可能性があるため、必ず、一意にRFタグが読み取りできるようなマ
      スク条件を指定する必要があります。
  ・読み取るRFタグの指定MemBankがPassword Readロックされている場合、RFタグのAccessパ
   スワードと同じAccessパスワードがリーダライタに設定された状態で本コマンドを実行する必
   要があります。リーダライタにAccessパスワードを設定する場合、[Accessパスワードの書き込
   み]コマンドを使用します。
  ・リーダライタに[0000 0000]h以外のAccessパスワードが設定されている場合、本コマンド実行
   時に[Access]コマンドを発行します。RFタグのAccessパスワードと一致しない場合、[Accessパ
   スワードエラー]となり、NACK応答が返ります。


＜コマンドパラメータ＞
 ● MemBank
    読み取るメモリ領域を指定します。
    詳細は、  「4.2 RF タグのメモリ構造」の項を参照ください。

  ● 読み取り開始 Word アドレス
     指定した MemBank 上の読み取り開始位置（Word アドレス）を指定します。
      (例) Word アドレス[03]h を指定する場合は、[00 00 00 03]h を指定します。
      (例) Word アドレス[10D]h を指定する場合は、[00 00 01 0D]h を指定します。

  ● 読み取り Word 数
     読み取るメモリのサイズを Word 長（2 [byte]単位）で指定します。


［ACK レスポンス］
 ラベル名 バイト数                                          内容
 STX          1      02h
アドレス          1      00h（ 「5.2 通信フォーマットの詳細」参照）
コマンド          1      30h（ACK）
データ長          1      n+2
              1      15h（詳細コマンド）
              1      データ長 (n バイト）
                     読み取りデータ（※2-64 バイト）
データ部                 1 [byte]目     (MSB）
              n      2 [byte]目
                      |
                     n [byte]目     (LSB）
 ETX          1      03h
 SUM          1      SUM 値（   「5.3 SUM の計算方法」参照）
  CR          1      0Dh

  ［NACK レスポンス］
  「7.6 NACK レスポンスとエラーコード」参照。


  ［コマンド／レスポンス例］
   (例) [UHF_Read]コマンドを使用して以下の RF タグデータを読み取る場合
           データ種類                         数値／パラメータ        コマンド列
           MemBank                       01: EPC(UII)    01
           読み取り開始 Word アドレス              02              00 00 00 02
           読み取り Word 数                   1               01

       •   コマンド
            02 00 55 07 15 01 00 00 00 02 01 03 7A 0D

       •   レスポンス
            02 00 30 04 15 02 E2 80 03 B2 0D
       ※EPC(UII)領域の Word アドレス[02]h から 1[Word]の読み取りに成功し、
        [E2 80]h を受信した場合
```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Read / UHF_InventoryRead / UHF_SetSelectParam / RF / TDR / MNL / PRC / STX / MSB / ETX / SUM / CR / ACK / NACK / AI / RAG / PDF / ISO18000 / EPC / UII / TID / ON / OFF / 55H / 15H / 07H / 02H / 03H / 0DH / 30H / 00H / 通信フォーマット / リーダライタ / RFタグ / アンテナ / レスポンス / MemBank / パスワード / Read / 55 15 / 5515 / 55_15
