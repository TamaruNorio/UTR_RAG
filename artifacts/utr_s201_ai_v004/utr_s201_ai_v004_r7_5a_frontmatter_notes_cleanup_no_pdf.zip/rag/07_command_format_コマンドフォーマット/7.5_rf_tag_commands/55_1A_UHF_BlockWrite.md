---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 1A】UHF_BlockWrite
topic: RFタグ通信コマンド
chapter: '07'
source_section: 7.5.7
source_pages: 283-285
category: RFタグ通信コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
command_name: UHF_BlockWrite
command_code: 55h
detail_command: 1Ah
command_label: 55 1A
operation_type: write_memory_multi_word
source_status: pdf_cross_checked
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_BlockWrite
- UHF_Encode
- RF
- TDR
- MNL
- PRC
- STX
- MSB
- ETX
- SUM
- CR
- ACK
- NACK
- AI
- ISO18000
- RAG
- PDF
- EPC
- UII
- TID
- LSB
- 55H
- 1AH
- 09H
- 02H
- 00H
- 01H
- 03H
- 0DH
- 30H
- 通信フォーマット
- リーダライタ
- RFタグ
- レスポンス
- MemBank
- Lock
- Write
- 55 1A
- 551A
- 55_1A
- 55h 1Ah
- UHF BlockWrite
- uhf_blockwrite
- 55h
- 1Ah
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_BlockWrite
- UHF_Encode
- ACK
- NACK
- 55H
- Lock
- 55 1A
- 551A
- 55_1A
- 55h 1Ah
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 1A】UHF_BlockWrite.md
optimized_path: 07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1A_UHF_BlockWrite.md
ai_code_generation: implementation_prohibited_by_default
automatic_send_allowed: false
requires_actual_device_check: true
requires_explicit_user_permission: true
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_BLOCK_WRITE
executable_hex_output: prohibited
checksum_policy: placeholder_only
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_BLOCK_WRITE
---
## R6 integration note

This chunk now references the central command safety matrix and source traceability matrix. If local metadata conflicts with the matrix, use the stricter safety profile.

# 【55 1A】UHF_BlockWrite

## コマンドの要約

MemBankと書き込み開始Wordアドレスを指定し、連続する複数Wordのデータを書き込むコマンドです。最大32 Wordを書き込めます。RFタグへの書き込み方式としてBlockWrite使用/不使用を選択します。

## 何に使うコマンドか

対象RFタグ1枚に対して、連続した複数Wordのデータを書き込む。

## 基本情報

| 項目 | 内容 |
|---|---|
| シリーズ | UTR |
| チップセット | R2000 |
| 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
| 参照章 | 7.5.7 |
| 参照ページ | 283-285 |
| コマンド区分 | RFタグ通信コマンド |
| コマンド | 55h |
| 詳細コマンド | 1Ah |
| データ長 | 09h + 書き込みWord数*2 |
| 操作種別 | write_memory_multi_word |
| リスク目安 | medium |

## コマンドフレーム要点

| 項目 | バイト数 | 内容 |
|---|---:|---|
| STX | 1 | 02h |
| アドレス | 1 | 通常00h |
| コマンド | 1 | 55h |
| データ長 | 1 | 09h + 書き込みWord数*2 |
| データ部 | 1 | 1Ah: 詳細コマンド |
| BlockWrite使用 | 1 | 00h: 使用しない / 01h: 使用する |
| パラメータ1 | 1 | MemBank指定 |
| 書き込み開始Wordアドレス | 4 | MSBファースト |
| 書き込みWord数 | 2 | MSBファースト |
| 書き込みデータ | Word数*2 | 最大32 Word |
| ETX | 1 | 03h |
| SUM | 1 | SUM値 |
| CR | 1 | 0Dh |

## ACKレスポンス要点

- ACKレスポンス: コマンド30h、詳細コマンド1Ah。

## NACKレスポンス

NACKレスポンスとエラーコードは、仕様書の「7.6 NACK レスポンスとエラーコード」を参照してください。

## 生成AI向けの重要ポイント

- BlockWriteはISO18000-63ではオプションコマンドのため、すべてのRFタグが対応しているとは限りません。
- RFタグへの書き込み途中でNACKになった場合、途中まで書き込みが成功している可能性があります。必ず読み戻し確認を検討してください。
- 複数MemBankへの書き込みやLock処理をまとめる場合はUHF_Encodeも検討します。

## 対応状況メモ

6.2.3の対応表では、対象UTR-S201シリーズ機種で対応。

## RAG検索キーワード

BlockWrite, 複数Word書き込み, MemBank, BlockWrite使用, Write複数回, 部分書き込み, 30h 1Ah

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
7.5.7   UHF_BlockWrite
  MemBankと書き込み開始アドレスを指定し、RFタグに連続する複数Wordのデータを書き込むコマ
  ンドです。
    ※複数MemBankへの書き込みをおこなう場合や、続けてLock処理をおこなう場合は、
     [UHF_Encode]コマンドを併せてご検討ください。


  本コマンドを実行すると、ISO18000-63 規格で規定された、[Select], [Query], [Access],
  [BlockWrite]または[Write]などのコマンドを、リーダライタが自動的に順次実行します。
    ※リーダライタと RF タグ間で実行されるコマンドの詳細は、
                                 「3.10 RF タグ通信コマンド実行時の
     リーダライタの内部処理」をご参照ください。
    ※読み書き対象の RF タグが 1 枚となるように、あらかじめ[Select]コマンドのマスク条件や
     [Query]コマンドのパラメータを設定した状態で本コマンドを実行してください。
     複数の RF タグが応答を返す状態でコマンドを実行すると、意図しない RF タグに対して
     コマンドが実行されたり、コマンドの実行に失敗したりする可能性があります。


 ［コマンド］
 ラベル名 バイト数                              内容
  STX   1            02h
 アドレス   1            00h（ 「5.2 通信フォーマットの詳細」参照）
 コマンド   1            55h
 データ長   1            09h+（書き込み Word 数×2）
               1     1Ah（詳細コマンド）
                     BlockWrite コマンドを使用
               1     00h：使用しない（Write コマンドを複数回実行します）
                     01h：使用する （BlockWrite コマンドを複数回実行します）
                     パラメータ 1
                              MemBank※左側が上位 bit
                              00     ：Reserved
                     bit0
               1              01     ：EPC(UII)
                     bit1
                              10     ：TID
 データ部                         11     ：User
                     bit2-7   将来拡張のための予約（通常は 0）
                     書き込み開始 Word アドレス
               4
                       RF タグのメモリ上の書き込み開始位置（Word 単位）
                     書き込み Word 数
               2       1 バイト目：上位バイト（MSB）
                       2 バイト目：下位バイト（LSB）
            書き込み
            Word 数   書き込みデータ（最大 32 [Word]）
              ×2
   ETX        1      03h
   SUM        1      SUM 値（「5.3 SUM の計算方法」参照）
    CR        1      0Dh


＜コマンドパラメータ＞
● BlockWriteコマンドを使用
  RF タグへの書き込みに BlockWrite コマンドを使用するかどうかを選択します。
  ・[使用する]
   BlockWrite コマンドを使用して RF タグへの書き込みをおこないます。
     ※BlockWrite コマンドは ISO18000-63 では RF タグのオプションコマンドのため、一部の
      RF タグでは対応していません。詳細は「4.2.7 RF タグオプションコマンド対応表」または
      使用する RF タグ Chip のデータシートを参照ください。
  ・[使用しない]
   Write コマンドを使用して RF タグへの書き込みをおこないます。
  ※書き込みに[BlockWrite]コマンド／[Write]コマンドを使用した場合のいずれの場合も、リーダラ
   イタから RF タグへは 1[Word]ごとに分けて複数回書き込みをおこないます。
   リーダライタと RF タグ間で書き込みに失敗した場合、内部のリトライ処理は 1[Word]単位で実
   行されます。そのため、RF タグへの書き込みの途中で失敗して NACK 応答となった場合、書き
   込み内容の途中まで書き込みが成功している場合があります。

● MemBank
   書き込むメモリ領域を指定します。
   詳細は、  「4.2RF タグのメモリ構造」の項を参照ください。

● 書き込み開始Wordアドレス
   「MemBank」で指定したメモリ領域の書き込み開始位置をWordアドレスで指定します。

● 書き込み Word 数
   書き込みするデータのサイズを Word 長(2 [byte]単位)で指定します。

● 書き込みデータ
   書き込むデータを指定します。


［ACK レスポンス］
ラベル名 バイト数                                            内容
 STX           1      02h
アドレス           1      00h（「5.2 通信フォーマットの詳細」参照）
 ACK           1      30h
データ長           1      01h
データ部           1      1Ah（詳細コマンド）
 ETX           1      03h
 SUM           1      SUM 値（「5.3 SUM の計算方法」参照）
  CR           1      0Dh


［NACK レスポンス］
 「7.6 NACK レスポンスとエラーコード」参照。


［コマンド／レスポンス例］
      (例) [UHF_BlockWrite]コマンドを使用して以下のパラメータを書き込む場合
         データ種類                              数値／パラメータ                   コマンド列
         BlockWrite コマンドを使用                 使用する                       01
         MemBank                            11: User                   03
         書き込み開始 Word アドレス                   0                          00 00 00 00
         書き込み Word 数                        2                          00 02
         書き込みデータ                            12 34 56 78                12 34 56 78

  •    コマンド
       02 00 55 0D 1A 01 03 00 00 00 00 00 02 12 34 56 78 03 9B 0D
  •    レスポンス
       02 00 30 01 1A 03 50 0D
```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_BlockWrite / UHF_Encode / RF / TDR / MNL / PRC / STX / MSB / ETX / SUM / CR / ACK / NACK / AI / ISO18000 / RAG / PDF / EPC / UII / TID / LSB / 55H / 1AH / 09H / 02H / 00H / 01H / 03H / 0DH / 30H / 通信フォーマット / リーダライタ / RFタグ / レスポンス / MemBank / Lock / Write / 55 1A / 551A / 55_1A / 55h 1Ah / UHF BlockWrite
