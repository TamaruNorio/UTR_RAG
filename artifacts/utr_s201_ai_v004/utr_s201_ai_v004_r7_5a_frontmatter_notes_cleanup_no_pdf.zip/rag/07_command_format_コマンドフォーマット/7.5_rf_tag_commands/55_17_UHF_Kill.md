---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 17】UHF_Kill
topic: RFタグ通信コマンド
chapter: '07'
source_section: 7.5.5
source_pages: 276-277
category: RFタグ通信コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
command_name: UHF_Kill
command_code: 55h
detail_command: 17h
command_label: 55 17
operation_type: kill_tag
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_KILL
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_KILL
executable_hex_output: prohibited
checksum_policy: placeholder_only
ai_code_generation: implementation_prohibited
automatic_send_allowed: false
requires_actual_device_check: true
requires_explicit_user_permission: true
requires_pdf_confirmation: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Kill
- UHF_Write
- UHF_BlockWrite
- UHF_Encode
- RF
- TDR
- MNL
- PRC
- STX
- MSB
- ETX
- SUM
- CR
- ACK
- NACK
- AI
- RAG
- PDF
- ISO18000
- 55H
- 17H
- 05H
- 02H
- 03H
- 0DH
- 30H
- 00H
- 01H
- 通信フォーマット
- リーダライタ
- RFタグ
- レスポンス
- Kill
- Write
- 55 17
- '5517'
- '55_17'
- 55h 17h
- UHF Kill
- uhf_kill
- 55h
- 17h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
- 書き込み
- EPC書き換え
- WordPtr
aliases:
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Kill
- UHF_Write
- UHF_BlockWrite
- UHF_Encode
- ACK
- NACK
- 55H
- Kill
- 55 17
- '5517'
- '55_17'
- 55h 17h
- UHF Kill
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 17】UHF_Kill.md
optimized_path: 07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_17_UHF_Kill.md
---
# 【55 17】UHF_Kill

## コマンドの要約

RFタグをKillして無効化するコマンドです。Killed状態になったRFタグは以降すべてのRFタグ通信コマンドに応答しません。元に戻せないため、実運用・検証ともに最重要注意コマンドです。

## 何に使うコマンドか

RFタグのKill Passwordと一致するKill Passwordを指定し、RFタグを恒久的に無効化する。

## 基本情報

| 項目 | 内容 |
|---|---|
| シリーズ | UTR |
| チップセット | R2000 |
| 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
| 参照章 | 7.5.5 |
| 参照ページ | 276-277 |
| コマンド区分 | RFタグ通信コマンド |
| コマンド | 55h |
| 詳細コマンド | 17h |
| データ長 | 05h |
| 操作種別 | kill_tag |
| リスク目安 | critical |

## コマンドフレーム要点

| 項目 | バイト数 | 内容 |
|---|---:|---|
| STX | 1 | 02h |
| アドレス | 1 | 通常00h |
| コマンド | 1 | 55h |
| データ長 | 1 | 05h |
| データ部 | 1 | 17h: 詳細コマンド |
| Kill Password | 4 | MSBファースト |
| ETX | 1 | 03h |
| SUM | 1 | SUM値 |
| CR | 1 | 0Dh |

## ACKレスポンス要点

- ACKレスポンス: コマンド30h、詳細コマンド17h。成功後、RFタグはKilled状態になります。

## NACKレスポンス

NACKレスポンスとエラーコードは、仕様書の「7.6 NACK レスポンスとエラーコード」を参照してください。

## 生成AI向けの重要ポイント

- 一度Killed状態になったRFタグは元に戻せません。サンプルコードや手順書では必ず警告を出してください。
- RFタグ側のKill Passwordが0000 0000h以外に設定されており、コマンド指定のKill Passwordと一致する必要があります。
- 対象RFタグを1枚に絞らずに実行すると、意図しないタグを無効化する危険があります。

## 対応状況メモ

6.2.3の対応表では、対象UTR-S201シリーズ機種で対応。

## RAG検索キーワード

Kill, 無効化, Killed状態, Kill Password, 不可逆, 30h 17h

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
7.5.5   UHF_Kill
  RFタグをKill（無効化）するコマンドです。
  Kill（無効化）されたRFタグは、Killed状態に遷移し、全ての「RFタグ通信コマンド」に対して応
  答を返さなくなります。
    ※RFタグの状態遷移については、「4.1 RFタグの状態遷移」をご参照ください。

  ・RFタグをKill（無効化）するためには、RFタグのKill Password (Reserved領域のWordアドレス
   [00]hから2[Word])に[0000 0000]h以外を書き込んだ状態で本コマンドを実行し、RFタグのKill
   Passwordと、本コマンドのコマンドパラメータで指定するKill Passwordが、一致する必要があり
   ます。
  ・RFタグへ設定するKill Passwordは、[UHF_Write], [UHF_BlockWrite], [UHF_Encode]コマンド
   などを使用して事前に書き込みます。
  ・一度Killed状態となったRFタグは、元に戻すことはできません。

  ・本コマンドを実行すると、ISO18000-63 規格で規定された、[Select], [Query], [Kill]などのコマン
   ドを、リーダライタが自動的に順次実行します。
        ・リーダライタと RF タグ間で実行されるコマンドの詳細は、
                                     「3.10 RF タグ通信コマンド実行時
         のリーダライタの内部処理」をご参照ください。
        ・読み書き対象の RF タグが 1 枚となるように、あらかじめ[Select]コマンドのマスク条件や
         [Query]コマンドのパラメータを設定した状態で本コマンドを実行してください。
         複数の RF タグが応答を返す状態でコマンドを実行すると、意図しない RF タグに対して
         コマンドが実行されたり、コマンドの実行に失敗したりする可能性があります。


 ［コマンド］
 ラベル名 バイト数                                内容
  STX          1   02h
 アドレス          1   00h（「5.2 通信フォーマットの詳細」参照）
 コマンド          1   55h
 データ長          1   05h
               1   17h（詳細コマンド）
 データ部              Kill Password
               4
                     MSB ファーストでセットする
   ETX         1   03h
   SUM         1   SUM 値（「5.3 SUM の計算方法」参照）
    CR         1   0Dh


  ＜コマンドパラメータ＞
   ● Kill Password
       リーダライタからの[Kill]コマンドに設定するKill Passwordを指定します。
       RFタグをKill（無効化）するためには、RFタグのKill Password (Reserved領域のWordアド
       レス[00]hから2[Word])に書かれている内容と同じ内容を指定する必要があります。


［ACK レスポンス］
ラベル名 バイト数                                       内容
 STX          1      02h
アドレス          1      00h（「5.2 通信フォーマットの詳細」参照）
 ACK          1      30h
データ長          1      01h
データ部          1      17h（詳細コマンド）
 ETX          1      03h
 SUM          1      SUM 値（「5.3 SUM の計算方法」参照）
  CR          1      0Dh


［NACK レスポンス］
 「7.6 NACK レスポンスとエラーコード」参照。


［コマンド／レスポンス例］
       ● コマンド
          02 00 55 05 17 12 34 56 78 03 8A 0D
       ● レスポンス
          02 00 30 01 17 03 4D 0D
    ※Kill Password に[12 34 56 78]h を指定して[Kill]コマンドを実行し、
     Kill（無効化）に成功した場合
     →RF タグは ACK 応答を返した後、Killed 状態となります。
       Killed 状態となった RF タグは、以降の全ての RF タグ通信コマンドに対して応答を
       返さなくなります。
```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Kill / UHF_Write / UHF_BlockWrite / UHF_Encode / RF / TDR / MNL / PRC / STX / MSB / ETX / SUM / CR / ACK / NACK / AI / RAG / PDF / ISO18000 / 55H / 17H / 05H / 02H / 03H / 0DH / 30H / 00H / 01H / 通信フォーマット / リーダライタ / RFタグ / レスポンス / Kill / Write / 55 17 / 5517 / 55_17 / 55h 17h / UHF Kill / uhf_kill / 55h / 17h
