---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 1B】UHF_BlockErase
topic: RFタグ通信コマンド
chapter: '07'
source_section: 7.5.8
source_pages: 286-287
category: RFタグ通信コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
command_name: UHF_BlockErase
command_code: 55h
detail_command: 1Bh
command_label: 55 1B
operation_type: erase_memory_multi_word
source_status: pdf_cross_checked
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_BLOCK_ERASE
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_BLOCK_ERASE
executable_hex_output: prohibited
checksum_policy: placeholder_only
ai_code_generation: explanation_only_by_default
automatic_send_allowed: false
requires_explicit_user_permission: true
requires_pdf_confirmation: true
requires_actual_device_check: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_BlockErase
- UHF_BlockWrite
- UHF_Encode
- RF
- TDR
- MNL
- PRC
- STX
- MSB
- ETX
- SUM
- CR
- ACK
- NACK
- AI
- RAG
- PDF
- ISO18000
- EPC
- UII
- TID
- LSB
- 55H
- 1BH
- 08H
- 02H
- 03H
- 0DH
- 30H
- 00H
- 通信フォーマット
- リーダライタ
- RFタグ
- レスポンス
- MemBank
- パスワード
- Write
- 55 1B
- 551B
- 55_1B
- 55h 1Bh
- UHF BlockErase
- uhf_blockerase
- 55h
- 1Bh
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
- 31h
- エラーコード
- 異常応答
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_BlockErase
- UHF_BlockWrite
- UHF_Encode
- ACK
- NACK
- 55H
- 55 1B
- 551B
- 55_1B
- 55h 1Bh
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 1B】UHF_BlockErase.md
optimized_path: 07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_1B_UHF_BlockErase.md
---
# 【55 1B】UHF_BlockErase

## コマンドの要約

MemBank、消去開始Wordアドレス、消去Word数を指定し、RFタグの連続する複数Wordを消去するコマンドです。BlockEraseはRFタグのオプションコマンドであり、対応タグが限られます。

## 何に使うコマンドか

対象RFタグ1枚に対して、指定領域をWord単位で消去する。

## 基本情報

| 項目 | 内容 |
|---|---|
| シリーズ | UTR |
| チップセット | R2000 |
| 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
| 参照章 | 7.5.8 |
| 参照ページ | 286-287 |
| コマンド区分 | RFタグ通信コマンド |
| コマンド | 55h |
| 詳細コマンド | 1Bh |
| データ長 | 08h |
| 操作種別 | erase_memory_multi_word |
| リスク目安 | high |

## コマンドフレーム要点

| 項目 | バイト数 | 内容 |
|---|---:|---|
| STX | 1 | 02h |
| アドレス | 1 | 通常00h |
| コマンド | 1 | 55h |
| データ長 | 1 | 08h |
| データ部 | 1 | 1Bh: 詳細コマンド |
| パラメータ1 | 1 | MemBank指定 |
| 消去開始Wordアドレス | 4 | MSBファースト |
| 消去Word数 | 2 | MSBファースト |
| ETX | 1 | 03h |
| SUM | 1 | SUM値 |
| CR | 1 | 0Dh |

## ACKレスポンス要点

- ACKレスポンス: コマンド30h、詳細コマンド1Bh。

## NACKレスポンス

NACKレスポンスとエラーコードは、仕様書の「7.6 NACK レスポンスとエラーコード」を参照してください。

## 生成AI向けの重要ポイント

- 消去後の値はRFタグのデータシートに依存します。アプリ側で固定値を仮定しないでください。
- BlockErase非対応タグでは、UHF_BlockWriteやUHF_Encodeで代用することを検討します。
- 消去操作はデータ破壊を伴うため、実行前に対象タグと対象領域を必ず確認してください。

## 対応状況メモ

6.2.3の対応表では、対象UTR-S201シリーズ機種で対応。

## RAG検索キーワード

BlockErase, 消去, MemBank, Wordアドレス, オプションコマンド, 30h 1Bh

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
7.5.8   UHF_BlockErase
  RFタグの連続する複数Wordのデータを消去するコマンドです。
  MemBankと、消去するアドレスおよびWord数を指定して実行します。
  消去後の値の詳細は、RFタグのデータシートをご参照ください。

  本コマンドを実行すると、ISO18000-63 規格で規定された、[Select], [Query], [Access],
  [BlockErase]などのコマンドを、リーダライタが自動的に順次実行します。
    ※リーダライタと RF タグ間で実行されるコマンドの詳細は、
                                 「3.10 RF タグ通信コマンド実行時の
     リーダライタの内部処理」をご参照ください。
    ※読み書き対象の RF タグが 1 枚となるように、あらかじめ[Select]コマンドのマスク条件や
     [Query]コマンドのパラメータを設定した状態で本コマンドを実行してください。
     複数の RF タグが応答を返す状態でコマンドを実行すると、意図しない RF タグに対して
     コマンドが実行されたり、コマンドの実行に失敗したりする可能性があります。
    ※リーダライタの Access パスワードに[0000 0000]h 以外が設定されている場合には、書き込みす
     る MemBank によらず、必ず、[Access]コマンドが発行されます。

  ※リーダライタからRFタグに対して、[BlockErase]コマンドを発行します。
   [BlockErase]コマンドは、ISO18000-63ではRFタグのオプションコマンドのため、一部のRFタグ
   のみ対応しています。詳細は「4.2.7 RFタグオプションコマンド対応表」または使用するRFタグ
   Chipのデータシートを参照ください。
    ・[BlockErase]コマンドに対応していないRFタグの内容を消去する場合には、
     [UHF_BlockWrite]コマンドや[UHF_Encode]コマンドで代用してください。

  ［コマンド］
 ラベル名 バイト数                               内容
  STX    1          02h
 アドレス    1          00h（「5.2 通信フォーマットの詳細」参照）
 コマンド    1          55h
 データ長    1          08h
               1    1Bh（詳細コマンド）
                    パラメータ 1
                           MemBank ※左側が上位 bit
                           00     ：Reserved
                    bit0
               1           01     ：EPC(UII)
                    bit1
                           10     ：TID
 データ部                      11     ：User
                    bit2-7 将来拡張のための予約（通常は 0）
                    消去開始 Word アドレス
               4
                    RF タグのメモリ上の消去開始位置（Word 単位）
                    消去 Word 数
               2    1 バイト目：上位バイト（MSB）
                    2 バイト目：下位バイト（LSB）
   ETX         1    03h
   SUM         1    SUM 値（「5.3 SUM の計算方法」参照）
    CR         1    0Dh


＜コマンドパラメータ＞
  ● MemBank
     消去するメモリ領域を指定します。
     詳細は、 「4.2RF タグのメモリ構造」の項を参照ください。
  ● 消去開始Wordアドレス
     消去するメモリの開始 Word アドレスを指定します。
  ● 消去 Word 数
     消去するメモリのサイズを Word 長（2 [byte]単位）で指定します。


［ACK レスポンス］
ラベル名 バイト数                                             内容
 STX         1      02h
アドレス         1      00h（「5.2 通信フォーマットの詳細」参照）
 ACK         1      30h
データ長         1      01h
データ部         1      1Bh（詳細コマンド）
 ETX         1      03h
 SUM         1      SUM 値（「5.3 SUM の計算方法」参照）
  CR         1      0Dh


［NACK レスポンス］
 「7.6 NACK レスポンスとエラーコード」参照。


［コマンド／レスポンス例］

    (例) User 領域の Word アドレス[00]h から 1[Word]を消去する場合
        データ種類                             数値／パラメータ           コマンド列
        MemBank                           11: USER           03
        消去開始 Word アドレス                    0                  00 00 00 00
        消去 Word 数                         1                  00 01
    • コマンド
       02 00 55 08 1B 03 00 00 00 00 00 01 03 E9 0D
    • レスポンス
       02 00 30 01 1B 03 51 0D
```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_BlockErase / UHF_BlockWrite / UHF_Encode / RF / TDR / MNL / PRC / STX / MSB / ETX / SUM / CR / ACK / NACK / AI / RAG / PDF / ISO18000 / EPC / UII / TID / LSB / 55H / 1BH / 08H / 02H / 03H / 0DH / 30H / 00H / 通信フォーマット / リーダライタ / RFタグ / レスポンス / MemBank / パスワード / Write / 55 1B / 551B / 55_1B / 55h 1Bh / UHF BlockErase
