---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: '1.17'
manual_date: '2025-06-16'
language: ja
encoding: UTF-8
public_protocol: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-S201
- UTR-SHR201
do_not_confuse_with:
- UTRXシリーズ
- TR3XMシリーズ
- TR3Xシリーズ
- UTR-S101シリーズ
- MS710/E710系チップセット
title: 【55 16】UHF_Write
topic: RFタグ通信コマンド
chapter: '07'
source_section: 7.5.4
source_pages: 274-275
category: RFタグ通信コマンド
chunk_type: command_spec
rag_priority: high
risk_level: critical
command_name: UHF_Write
command_code: 55h
detail_command: 16h
command_label: 55 16
operation_type: write_memory_single_word
source_status: pdf_cross_checked
ai_code_generation: implementation_prohibited_by_default
automatic_send_allowed: false
requires_actual_device_check: true
requires_explicit_user_permission: true
requires_pdf_confirmation: true
keywords:
- UTR
- UTR-S201
- UTR-S201シリーズ
- R2000
- UHF
- RFID
- ISO18000-63
- EPCglobal Class1 Generation2
- TDR-MNL-PRC-UTR-S201-117
- Ver.1.17
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UTRXではない
- TR3XMではない
- MS710ではない
- E710ではない
- UHF_Write
- UHF_BlockWrite
- UHF_Encode
- UHF_Read
- RF
- TDR
- MNL
- PRC
- STX
- MSB
- ETX
- SUM
- CR
- ACK
- NACK
- AI
- RAG
- PDF
- ISO18000
- EPC
- UII
- TID
- LSB
- 55H
- 16H
- 08H
- 02H
- 03H
- 0DH
- 30H
- 00H
- 通信フォーマット
- リーダライタ
- RFタグ
- レスポンス
- MemBank
- パスワード
- Lock
- Read
- Write
- 55 16
- '5516'
- '55_16'
- 55h 16h
- UHF Write
- uhf_write
- 55h
- 16h
- 通信
- インターフェース
- シリアル通信
- TCP/IP
- USB
- Bluetooth
- Wi-Fi
- COMポート
- データ長
- チェックサム
- SUM計算
- STXからETXまでの合計
- 下位1バイト
- 30h
aliases:
- EPC
- UII
- PC+EPC
- StoredPC
- EPC(UII)
- RFタグ
- UHFタグ
- タグ
- リーダライタ
- Reader Writer
- RW
- コマンド
- command
- frame
search_boost_terms:
- UTR-S201
- UTR-S201シリーズ
- TDR-MNL-PRC-UTR-S201-117
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201
- UHF_Write
- UHF_BlockWrite
- UHF_Encode
- UHF_Read
- ACK
- NACK
- 55H
- Lock
- 55 16
- '5516'
- '55_16'
- 55h 16h
- 55h
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 16】UHF_Write.md
optimized_path: 07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_16_UHF_Write.md
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_WRITE
executable_hex_output: prohibited
checksum_policy: placeholder_only
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_WRITE
---
## R6 integration note

This chunk now references the central command safety matrix and source traceability matrix. If local metadata conflicts with the matrix, use the stricter safety profile.

# 【55 16】UHF_Write

## コマンドの要約

MemBankと書き込み開始Wordアドレスを指定し、RFタグへ1 Wordのデータを書き込むコマンドです。複数Wordを書き込む場合はUHF_BlockWrite、複数MemBankやLock処理をまとめたい場合はUHF_Encodeを検討します。

## 何に使うコマンドか

対象RFタグ1枚に対して、指定メモリ領域の1 Wordを書き換える。

## 基本情報

| 項目 | 内容 |
|---|---|
| シリーズ | UTR |
| チップセット | R2000 |
| 仕様書 | TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 |
| 参照章 | 7.5.4 |
| 参照ページ | 274-275 |
| コマンド区分 | RFタグ通信コマンド |
| コマンド | 55h |
| 詳細コマンド | 16h |
| データ長 | 08h |
| 操作種別 | write_memory_single_word |
| リスク目安 | medium |

## コマンドフレーム要点

| 項目 | バイト数 | 内容 |
|---|---:|---|
| STX | 1 | 02h |
| アドレス | 1 | 通常00h |
| コマンド | 1 | 55h |
| データ長 | 1 | 08h |
| データ部 | 1 | 16h: 詳細コマンド |
| パラメータ1 | 1 | MemBank指定 |
| 書き込み開始Wordアドレス | 4 | MSBファースト |
| 書き込みデータ | 2 | 1 Word、MSBファースト |
| ETX | 1 | 03h |
| SUM | 1 | SUM値 |
| CR | 1 | 0Dh |

## ACKレスポンス要点

- ACKレスポンス: コマンド30h、詳細コマンド16h。

## NACKレスポンス

NACKレスポンスとエラーコードは、仕様書の「7.6 NACK レスポンスとエラーコード」を参照してください。

## 生成AI向けの重要ポイント

- 書き込み対象がWriteロックされている場合、RFタグと同じAccessパスワードをリーダライタへ設定してから実行する必要があります。
- 複数のRFタグが応答する状態では、意図しないRFタグに書き込む危険があります。必ず対象を1枚に絞ってください。
- ACKレスポンスは30h/16hのみで、書き込んだ値はレスポンスには含まれません。必要に応じてUHF_Readでベリファイしてください。

## 対応状況メモ

6.2.3の対応表では、対象UTR-S201シリーズ機種で対応。

## RAG検索キーワード

Write, 書き込み, MemBank, Wordアドレス, Accessパスワード, ベリファイ, 30h 16h

## 公式仕様抜粋

以下は、原本PDFの該当節から抽出したテキストです。表の罫線や改行はPDF抽出の都合で原本と完全には一致しない場合があります。数値・ビット定義・注意事項は原本確認用として残しています。

```text
7.5.4   UHF_Write
  MemBankとWordアドレスを指定し、RFタグにWord単位でデータを書き込むコマンドです。
  一度に1[Word]のみの書き込みが可能です。
        ※複数Wordの書き込みをおこなう場合は、[UHF_BlockWrite]コマンドを併せてご検討くださ
         い。
        ※複数MemBankへの書き込みをおこなう場合や、続けてLock処理をおこなう場合は、
         [UHF_Encode]コマンドを併せてご検討ください。

  本コマンドを実行すると、ISO18000-63 規格で規定された、[Select], [Query], [Access], [Write]など
  のコマンドを、リーダライタが自動的に順次実行します。
    ※リーダライタと RF タグ間で実行されるコマンドの詳細は、
                                 「3.10 RF タグ通信コマンド実行時の
     リーダライタの内部処理」をご参照ください。
    ※読み書き対象の RF タグが 1 枚となるように、あらかじめ[Select]コマンドのマスク条件や
     [Query]コマンドのパラメータを設定した状態で本コマンドを実行してください。
     複数の RF タグが応答を返す状態でコマンドを実行すると、意図しない RF タグに対して
     コマンドが実行されたり、コマンドの実行に失敗したりする可能性があります。
    ※リーダライタの Access パスワードに[0000 0000]h 以外が設定されている場合には、書き込みす
     る MemBank によらず、必ず、[Access]コマンドが発行されます。


 ［コマンド］
 ラベル名 バイト数                                内容
  STX   1           02h
 アドレス   1           00h（ 「5.2 通信フォーマットの詳細」参照）
 コマンド   1           55h
 データ長   1           08h
              1     16h（詳細コマンド）
                    パラメータ 1
                             MemBank ※左側が上位 bit
                             00     ：Reserved
                    bit0
              1              01     ：EPC(UII)
                    bit1
                             10     ：TID
 データ部                        11     ：User
                    bit2-7   将来拡張のための予約（通常は 0）
                    書き込み開始 Word アドレス
              4
                      RF タグのメモリ上の書き込み開始位置（Word 単位）
                    書き込みデータ
              2       1 バイト目：上位バイト（MSB）
                     2 バイト目：下位バイト（LSB）
   ETX        1     03h
   SUM        1     SUM 値（「5.3 SUM の計算方法」参照）
    CR        1     0Dh


＜注意事項＞
 ・書き込み対象のRFタグの指定MemBankがWriteロックされている場合、RFタグのAccessパス
  ワードと同じAccessパスワードがリーダライタに設定された状態で本コマンドを実行する必要
  があります。リーダライタにAccessパスワードを設定する場合、[Accessパスワードの書き込み]
  コマンドを使用します。
  ・リーダライタに[0000 0000]h以外のAccessパスワードが設定されている場合、本コマンド実行
   時に[Access]コマンドを発行します。RFタグのAccessパスワードと一致しない場合、[Accessパ
   スワードエラー]となり、NACK応答が返ります。


＜コマンドパラメータ＞
 ● MemBank
    書き込むメモリ領域を指定します。
    詳細は、  「4.2 RF タグのメモリ構造」の項を参照ください。

  ● 書き込み開始Wordアドレス
     書き込みを開始する RF タグ上のメモリの Word アドレスを指定します。

  ● 書き込みデータ
     書き込むデータを指定します。


［ACKレスポンス］
ラベル名 バイト数                                           内容
 STX          1      02h
アドレス          1      00h（「5.2 通信フォーマットの詳細」参照）
コマンド          1      30h（ACK）
データ長          1      01h
データ部          1      16h（詳細コマンド）
 ETX          1      03h
 SUM          1      SUM 値（「5.3 SUM の計算方法」参照）
  CR          1      0Dh

［NACK レスポンス］
 「7.6 NACK レスポンスとエラーコード」参照。


［コマンド／レスポンス例］
    (例) [UHF_Write]コマンドを使用して以下のパラメータを書き込む場合
         データ種類                        数値／パラメータ           コマンド列
         MemBank                      01: EPC(UII)       01
         書き込みアドレス                     01h                00 00 00 01
         書き込みデータ                      30 00              30 00
       ● コマンド
          02 00 55 08 16 01 00 00 00 01 30 00 03 AA 0D
       ● レスポンス
          02 00 30 01 16 03 4C 0D
       ※EPC(UII)領域の Word アドレス 01h への[30 00]h の書き込みに成功した場合
```

## RAG検索キーワード（最適化）

UTR / UTR-S201 / UTR-S201シリーズ / R2000 / UHF / RFID / ISO18000-63 / EPCglobal Class1 Generation2 / TDR-MNL-PRC-UTR-S201-117 / Ver.1.17 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 / UTRXではない / TR3XMではない / MS710ではない / E710ではない / UHF_Write / UHF_BlockWrite / UHF_Encode / UHF_Read / RF / TDR / MNL / PRC / STX / MSB / ETX / SUM / CR / ACK / NACK / AI / RAG / PDF / ISO18000 / EPC / UII / TID / LSB / 55H / 16H / 08H / 02H / 03H / 0DH / 30H / 00H / 通信フォーマット / リーダライタ / RFタグ / レスポンス / MemBank / パスワード / Lock / Read / Write / 55 16 / 5516
