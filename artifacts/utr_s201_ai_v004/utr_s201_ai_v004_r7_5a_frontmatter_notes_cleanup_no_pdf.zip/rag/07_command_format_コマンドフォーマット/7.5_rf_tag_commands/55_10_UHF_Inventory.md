---
series: UTR
series_family: UTR-S201
chipset: R2000
manual_id: TDR-MNL-PRC-UTR-S201-117
manual_title: UTR-S201シリーズ 通信プロトコル説明書
manual_version: "1.17"
manual_date: "2025-06-16"
language: ja
encoding: UTF-8
public_protocol: true
source_pdf: TDR-MNL-PRC-UTR-S201-117.pdf
source_of_truth: PDF正本
markdown_role: AI参照補助資料
markdown_is_authoritative: false
requires_pdf_verification_for_final_answer: true
document_scope: UTR-S201シリーズ公開通信プロトコル
target_models:
  - UTR-SUN02-4CH
  - UTR-SUN02V-8CH
  - UTR-SUN02-8CH
  - UTR-S201
  - UTR-SHR201
do_not_confuse_with:
  - UTRXシリーズ
  - TR3XMシリーズ
  - TR3Xシリーズ
  - UTR-S101シリーズ
  - MS710/E710系チップセット
title: 【55 10】UHF_Inventory
topic: RFタグ通信コマンド
chapter: "07"
source_section: "7.5.1"
source_pages: "262-265"
category: RFタグ通信コマンド
chunk_type: command_spec
chunk_profile: command_single
rag_priority: high
risk_level: low
safety_class: read_inventory_no_persistent_change
command_name: UHF_Inventory
command_code: 55h
detail_command: 10h
command_label: "55 10"
operation_type: read_inventory
writes_to_reader_setting: false
writes_to_flash: false
writes_to_tag_memory: false
persistent_effect: false
requires_explicit_user_permission: false
ai_code_generation: allowed_with_caution
related_commands:
  before_use:
    - UHF_GetInventoryParam
    - UHF_GetSelectParam
  can_affect_behavior:
    - UHF_SetInventoryParam
    - UHF_SetSelectParam
  response_reference:
    - NACKレスポンスとエラーコード
primary_retrieval_questions:
  - UTR-S201でEPCまたはUIIを読み取るにはどのコマンドを使うか
  - UHF_Inventoryのレスポンス6Ch/09hと30h/10hの違いは何か
  - Inventory応答からRSSI、ANGLE、PC+EPCをどう読むか
keywords:
  - UHF_Inventory
  - 55 10
  - 55_10
  - 5510
  - 6Ch 09h
  - 30h 10h
  - PC+EPC
  - PC+UII
  - Stored PC
  - EPC(UII)
  - RSSI
  - ANGLE
  - 読み取り完了レスポンス
  - インベントリ読み取り
search_boost_terms:
  - UHF_Inventory
  - "55 10"
  - "55h 10h"
  - "6Ch 09h"
  - "30h 10h"
  - PC_UII
  - EPC_UII
negative_keywords:
  - UHF_SetInventoryParam
  - UHF_Write
  - UHF_Kill
  - UHF_Lock
  - TR3XM
  - UTRX
aliases:
  - Inventory
  - UHF Inventory
  - インベントリ
  - EPC読み取り
  - UII読み取り
optimized_path: rag/07_command_format_コマンドフォーマット/7.5_rf_tag_commands/55_10_UHF_Inventory.md
original_path: 07_コマンドフォーマット/7.5_RFタグ通信コマンド/公開_UTR版_【55 10】UHF_Inventory.md
optimization_note: v004 C工程でRAG検索語を絞り込み、危険操作との差別化メタデータを追加。
---

# 【55 10】UHF_Inventory

## このファイルの役割

このMarkdownは、UTR-S201シリーズの `UHF_Inventory` を生成AIが参照しやすくするための補助資料です。正本はPDFの通信プロトコル説明書です。数値、バイト位置、注意事項の最終判断はPDF正本で確認してください。

## コマンドの要約

`UHF_Inventory` は、アンテナ範囲内のRFタグをインベントリし、Stored PCおよびEPC(UII)を取得する読み取り系コマンドです。

タグを読み取った場合は、RFタグごとのデータレスポンスと、最後の読み取り完了レスポンスが分かれて返ります。

## AIが誤読しやすい点

| 誤読しやすい点 | 正しい扱い |
|---|---|
| `55 10` を設定変更コマンドと混同する | `55 10` は読み取り系のInventoryコマンドです。 |
| タグデータレスポンスと完了レスポンスを1つのACKとして扱う | タグごとの `6Ch / 09h` と、完了時の `30h / 10h` を分けて解析します。 |
| RSSIを単なる16進文字列として表示する | 符号付き16ビット整数として扱い、必要に応じてdBm換算します。 |
| `UHF_SetInventoryParam` の設定値を同時に変更する | Inventory実行と設定変更は別処理です。設定変更は明示許可なしに行いません。 |

## 基本情報

| 項目 | 内容 |
|---|---|
| コマンド名 | UHF_Inventory |
| コマンドラベル | 55 10 |
| コマンド | 55h |
| 詳細コマンド | 10h |
| 操作種別 | read_inventory |
| 危険度 | low |
| 永続設定変更 | なし |
| RFタグメモリ書き込み | なし |
| 参照章 | 7.5.1 |
| 参照ページ | 262-265 |

## レスポンス解析の要点

| 種別 | コマンド/詳細 | 主な内容 | 用途 |
|---|---|---|---|
| RFタグデータレスポンス | 6Ch / 09h | RSSI、ANGLE、PC+EPC(UII) | タグ1枚ごとの読取結果 |
| 読み取り完了レスポンス | 30h / 10h | 読み取り枚数、チャンネル番号など | Inventory処理の終了判定 |
| NACK | 31h | エラーコード | 異常時の原因判定 |

## 生成AI向け実装ガード

- 受信処理は、1回の `recv` / `read` で完結すると仮定しないでください。
- STX、データ長、ETX、SUM、CRを確認してフレームを切り出してください。
- `6Ch / 09h` が複数回返った後に、`30h / 10h` が返る前提で処理してください。
- NACK時は、NACKレスポンスとエラーコードの章を参照してください。
- 設定変更系コマンド、特に `UHF_SetInventoryParam` を自動送信するコードを混ぜないでください。

## RAG検索用の短い説明

UTR-S201でEPC(UII)を読み取るInventoryコマンド。タグごとの `6Ch / 09h` レスポンスと、完了時の `30h / 10h` レスポンスを分けて解析する。
