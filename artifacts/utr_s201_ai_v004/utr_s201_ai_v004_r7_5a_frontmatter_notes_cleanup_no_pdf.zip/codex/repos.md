# Codex参照リポジトリ

このパッケージでは、UTR制御Pythonサンプル生成・改善時の実装スタイルとして、以下のCodexリポジトリを参考情報として扱います。

## 参考リポジトリ

- LAN版: `TamaruNorio/UTR_LAN_Python_CodeX`  
  https://github.com/TamaruNorio/UTR_LAN_Python_CodeX

- USB版: `TamaruNorio/UTR_USB_Python_CodeX`  
  https://github.com/TamaruNorio/UTR_USB_Python_CodeX

## 注意

README内などに `_CodeX` が付かない旧リポジトリ名が残っている場合でも、このパッケージでは `_CodeX` 付きリポジトリを参考にしてください。

## 使い分け

| 用途 | 参照先 |
|---|---|
| USBシリアル接続サンプル生成 | `UTR_USB_Python_CodeX` |
| LAN/TCP接続サンプル生成 | `UTR_LAN_Python_CodeX` |
| プロトコル仕様確認 | `rag/` |
| ChatGPT Skill登録 | `skill/skill.zip` |
| Claude/Gemini/Copilot転用 | `prompts/` と `rules/` |

## Codexへ依頼する場合の基本方針

- まず `README.md`、`docs/usage_scope.md`、`rules/` を読ませる
- 仕様確認は `rag/` を参照させる
- コード生成時は、対象機種、接続方式、実装範囲、禁止操作を明示する
- FLASH初期化、Kill、Lock、RF出力変更、RFタグ書き込み系は、明示的な承認なしに実装させない
