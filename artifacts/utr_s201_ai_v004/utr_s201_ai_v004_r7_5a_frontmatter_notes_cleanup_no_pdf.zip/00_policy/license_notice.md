# License and document-rights notice

The communication protocol specification is a Takaya Corporation document and is treated as the official source document for this AI-assistance package.

This package distinguishes the following materials:

- Official protocol specification documents
- AI-support Markdown/YAML/CSV derived for RAG and review
- Sample source code
- ChatGPT Skill instructions and prompts

A source-code license such as MIT, if used for sample code, must not be read as automatically applying to protocol manuals, PDF source documents, or Takaya document rights. The purpose of this notice is to prevent license-boundary confusion, not to block internal or authorized use of the public Takaya protocol material.
