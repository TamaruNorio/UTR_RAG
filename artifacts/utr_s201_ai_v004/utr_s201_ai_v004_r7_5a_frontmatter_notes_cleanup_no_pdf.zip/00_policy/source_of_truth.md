# Source of truth policy

## Purpose

This package uses the Takaya communication protocol specification as the source of truth and provides RAG/Skill support material for implementation, review, and real-device verification.

## Authority order

1. Official Takaya communication protocol specification PDF
2. Source traceability matrix and structured data derived from the PDF
3. RAG command/safety Markdown
4. Sample code and GitHub implementation examples
5. AI-generated explanations, plans, and review comments

## Required behavior

The AI must not end with only "read the PDF". It must explain, from an implementation perspective, what the referenced specification section covers, what must be checked before coding, and what remains unresolved.

The AI must not treat Markdown extraction as authoritative when tables, bit fields, channel mappings, merged cells, ROM differences, or model differences are involved. Use structured data where available and mark unverified values as `requires_pdf_cross_check`.

## PDF availability

The protocol specification is a Takaya public/corporate document and may be registered into a controlled RAG environment. This integrated no-PDF package does not include the PDF body; page-level traceability fields are prepared for cross-checking.
