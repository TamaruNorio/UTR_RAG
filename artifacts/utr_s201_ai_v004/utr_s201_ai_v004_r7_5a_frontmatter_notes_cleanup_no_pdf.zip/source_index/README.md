# Source index

This directory connects the Takaya communication protocol specification, RAG chunks, structured data, and implementation-review annotations.

## Role

- The communication protocol specification is the source of truth.
- RAG Markdown and structured YAML/CSV are implementation-support material.
- The AI must explain the referenced specification content from an implementation perspective instead of ending with only "read the PDF".
- Page/section fields marked `要PDF照合` or `requires_pdf_cross_check` must not be guessed.

## Main indexes

- `../03_structured_data/source_traceability_matrix.yml`
- `../03_structured_data/command_safety_matrix.yml`
- `../03_structured_data/structured_data_schema_index.yml`
- `../03_structured_data/rag_chunk_index.yml`

## Full-source PDF note

This integrated package keeps the no-PDF packaging style. The UTR-S201 series protocol PDF itself was not present as a standalone source file in this working directory, so page-level fields remain traceability placeholders until PDF cross-check is performed.
