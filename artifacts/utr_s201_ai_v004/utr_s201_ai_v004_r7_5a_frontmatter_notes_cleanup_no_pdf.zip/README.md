# UTR-S201/202 AI assistance package v004 R7-4F pre-RC candidate preparation no-PDF

## Purpose

This package supports RFID control application implementation, review, and verification by making the Takaya UTR-S201/202 series communication protocol easier for AI systems to reference accurately.

The package is not a replacement for the official communication protocol specification. It connects the source specification to RAG chunks, structured YAML/CSV, response-mode controls, safety rules, and code-review annotations.

## What changed through R7-4F

R7-4F keeps the R1-R5 redesign and R6 integration body, then adds the R7 traceability and RAG safety synchronization fixes needed before the next pre-RC review:

1. R1 redesign requirements
2. R2 AI response-mode control
3. R3 central command safety matrix
4. R4 source traceability and code annotation policy
5. R5 structured data design for tables, bit fields, frequency/channel mapping, ROM/model differences, RAM/FLASH behavior, Q-value conditions, and checksum handling
6. R7-4F minimal RAG/front matter/index safety synchronization and no-PDF packaging preparation

## Source-grounded response policy

The AI must explain what the relevant protocol section covers and how it affects implementation. It must not end with only "read the PDF". If a page or table has not been cross-checked, the AI must mark it as `要PDF照合` or `requires_pdf_cross_check`.

## Safety policy

Use `03_structured_data/command_safety_matrix.yml` as the single source for command risk. If a RAG chunk and the matrix conflict, use the stricter rule and report the inconsistency.

The AI must not output send-ready Hex frames with concrete SUM bytes. Use `[MUST_RECALCULATE_SUM]` or a verified frame builder.

## Key files

- `00_policy/ai_response_modes.yml`
- `03_structured_data/command_safety_matrix.yml`
- `03_structured_data/source_traceability_matrix.yml`
- `03_structured_data/structured_data_design_policy.yml`
- `03_structured_data/rag_chunk_index.yml`
- `rules/00_response_mode_control.md`
- `rules/01_command_safety_matrix_usage.md`
- `rules/13_source_traceability_policy.md`
- `rules/15_structured_data_policy.md`
- `docs/code_annotation_guide.md`
- `docs/structured_data_guide.md`
- `docs/redesign/`

## Package status

Status: R7-4F pre-RC candidate preparation no-PDF. This is not a formal RC; real-device verification is not complete, and the authoritative PDF is not included in this package.
