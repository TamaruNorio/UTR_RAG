# CHANGELOG — v004_r6_integrated_pre_rc

## 2026-06-29 R6 integrated body update

### Added

- Integrated R1-R5 redesign files into the package body.
- Added AI response-mode control.
- Added central command safety matrix.
- Added source traceability matrix.
- Added code annotation schema and guide.
- Added structured data scaffolds for frequency/channel, bitfield, antenna, ROM, hardware, RAM/FLASH, Q-value, and checksum handling.
- Added canonical `rag_chunk_index.yml` and `.csv` generated from current RAG files.

### Changed

- README, MANIFEST, and VALIDATION now describe the integrated R6 state instead of obsolete G/I-stage values.
- Output power write and frequency write RAG chunks are set to `critical` and reference the command safety matrix.
- UHF_Read, UHF_Write, and UHF_BlockWrite large RAG chunks are moved to stricter safety profiles.
- Absolute refusal policy includes UHF_BlockErase and UHF_Encode.
- Source-of-truth language now emphasizes implementation explanation grounded in the protocol specification, not "read the PDF" only.

### Not complete

- Page-level PDF cross-check is not complete.
- UHF_Read 55_14 / 55_15 conflict is not resolved.
- Real-device verification is not complete.
