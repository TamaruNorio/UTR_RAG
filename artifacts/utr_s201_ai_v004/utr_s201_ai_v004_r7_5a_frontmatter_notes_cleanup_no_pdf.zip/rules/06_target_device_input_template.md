# 06. 対象機器入力テンプレート

生成AI、Codex、Claude、Gemini、Copilotに作業を依頼する前に、必要に応じて次のブロックを先頭に貼り付けてください。

## 標準テンプレート

```yaml
target_device:
  product_family: UTR
  model_name: ""
  rom_series: ""
  interface: "USB"
  antenna_profile: ""
  source_pdf: "UTR-S201シリーズ通信プロトコル説明書"
  real_device_available: true

work_scope:
  task_type: "investigation | read_only_sample | implementation | review"
  allow_write_operation: false
  allow_flash_write: false
  allow_output_power_change: false
  allow_frequency_change: false
  allow_set_inventory_param: false
  allow_rom_detection_logic_change: false
```

## 入力例: UTR-SUN02-8CH / USB

```yaml
target_device:
  product_family: UTR
  model_name: "UTR-SUN02-8CH"
  rom_series: "USM08"
  interface: "USB"
  antenna_profile: "external_8ch"
  source_pdf: "UTR-S201シリーズ通信プロトコル説明書"
  real_device_available: true

work_scope:
  task_type: "read_only_sample"
  allow_write_operation: false
  allow_flash_write: false
  allow_output_power_change: false
  allow_frequency_change: false
  allow_set_inventory_param: false
  allow_rom_detection_logic_change: false
```

## 入力例: 調査のみ

```yaml
target_device:
  product_family: UTR
  model_name: "要確認"
  rom_series: "要確認"
  interface: "USB"
  antenna_profile: "要確認"
  source_pdf: "UTR-S201シリーズ通信プロトコル説明書"
  real_device_available: false

work_scope:
  task_type: "investigation"
  allow_write_operation: false
  allow_flash_write: false
  allow_output_power_change: false
  allow_frequency_change: false
  allow_set_inventory_param: false
  allow_rom_detection_logic_change: false
```

## AIへの追加指示

```text
対象機種、ROMシリーズ名、アンテナ構成が未確定の場合、機種依存コマンドは生成しないでください。
UTR-S201とUTR-S202は同一仕様と仮定しないでください。
PDF正本で確認できない差分は「要確認」としてください。
```
