# 16_pdf_table_conversion_policy

## Purpose

This rule defines how PDF protocol tables should be converted into AI-ready structured data.

## Conversion steps

1. Identify the source PDF, manual number, version, section, and page.
2. Determine the table type:
   - bit field
   - channel/frequency mapping
   - command frame layout
   - response frame layout
   - antenna numbering
   - ROM-version difference
   - model/hardware difference
   - persistence behavior
3. Choose the matching R5 schema.
4. Enter values exactly as confirmed from the PDF.
5. Mark all uncertain values as `requires_pdf_cross_check`.
6. Record the result in `source_traceability_matrix.yml`.
7. Add or update the relevant RAG chunk so prose and structured data point to each other.

## Handling merged cells

Merged cells must not be flattened into ambiguous prose.
If a merged cell applies to multiple rows or columns, repeat the value explicitly in each structured row and add `merged_cell_source_note` if needed.

## Handling notes and footnotes

PDF notes and footnotes must be represented as explicit fields:

- `source_note`
- `restriction_note`
- `model_dependency_note`
- `rom_dependency_note`
- `safety_note`

Do not rely on nearby prose position to preserve footnote meaning.

## Handling uncertainty

If the converter cannot verify a value, use:

```yaml
source_status: requires_pdf_cross_check
```

Do not guess.

## Review requirements

A converted table is not release-ready until a reviewer confirms:

- source PDF document/version
- page range
- table or section title
- row/column relationships
- bit order
- reserved bits
- model/ROM notes
- safety notes
