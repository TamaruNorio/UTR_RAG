# 05. 機種依存コマンドポリシー

## 目的

機種・ROMシリーズ・アンテナ構成に依存するコマンドを、安全に扱うための実装可否ルールです。

## 実装前に対象機種固定が必要なコマンド群

以下は、対象機種が曖昧なまま実装してはいけません。

- ROMバージョンに基づく機種判定ロジック
- UHF_CheckAntenna
- 使用アンテナ番号の読み取り
- 使用アンテナ番号の書き込み
- アンテナ切替設定の読み取り/書き込み
- 外部アンテナ自動切替設定の読み取り/書き込み
- アンテナ個別送信出力設定
- UHF_SetInventoryParam
- 出力設定の書き込み
- 周波数設定の書き込み
- FLASH設定値の読み書き

## 実装許可の段階

| 段階 | 許可される内容 |
|---|---|
| desk_check | PDFの表、byte列、SUM計算、レスポンス解析の机上確認 |
| read_only_sample | ROM読み取り、設定読み取り、Inventoryなどの読み取り系サンプル |
| guarded_real_device_check | ユーザー確認プロンプト付きの実機確認コード |
| write_operation | 明示許可、PDF確認、復元手順、ログ、実機確認手順がそろった場合のみ |

## 原則

- 読み取り系でも、対象機種依存のレスポンス解析は機種スコープを固定する。
- 書き込み系は、機種スコープ固定だけでは不十分。明示許可と安全手順が必要。
- FLASH、周波数、送信出力、InventoryParam、Kill、Lockは高リスクまたはcriticalとして扱う。

## Codexへ渡す場合

Codex依頼には、必ず次の情報を入れてください。

```yaml
target_device:
  product_family: UTR
  model_name: "例: UTR-SUN02-8CH"
  rom_series: "例: USM08"
  interface: "USB"
  antenna_profile: "external_8ch"
allowed_scope:
  - read_only
  - desk_check
forbidden_scope:
  - flash_write
  - output_power_change
  - frequency_change
  - set_inventory_param
  - rom_detection_logic_change
```

## 不明時の対応

```text
対象機種またはROMシリーズが未確定のため、機種依存コマンドは実装しません。
PDF正本で対象機種の該当章を確認し、必要であれば対象機器情報を明示してください。
```
