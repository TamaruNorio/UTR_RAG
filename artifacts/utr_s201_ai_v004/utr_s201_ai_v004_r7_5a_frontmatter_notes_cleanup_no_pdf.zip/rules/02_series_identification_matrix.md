# シリーズ識別マトリクス

| series_key | family | band | chipset | primary_document | target_models | tag_standard | manager_tool | hard_stop_if_seen |
|---|---|---|---|---|---|---|---|---|
| UTR-S201 | UTR | UHF | R2000系として扱う | TDR-MNL-PRC-UTR-S201-117 / UTR-S201シリーズ通信プロトコル説明書 Ver.1.17 | UTR-SUN02-4CH, UTR-SUN02V-8CH, UTR-SUN02-8CH, UTR-S201, UTR-SHR201 | ISO/IEC18000-63, EPCglobal Class1 Generation2 | UTRRWManager.exe | UID, DSFID, ISO15693, Inventory2, TR3RWManager, EEPROM, AFI中心のHFタグ制御 |
| UTRX | UTRX | UHF | MS710 / E710系として別扱い | 要確認。UTR-S201資料を流用しない | 要確認 | 要確認。ただしUTR-S201用コマンドを無断流用しない | 要確認 | UTR-S201用のUSMxx判定、R2000前提、TDR-MNL-PRC-UTR-S201-117を根拠にした実装 |
| TR3XM | TR3 / TR3XM | HF中心。マルチプロトコル対応系 | UTR-S201 / R2000系ではない | TR3XMシリーズ通信プロトコル説明書など。UTR-S201資料ではない | TR3XMシリーズ対象機器。UTR-SUN02系ではない | ISO15693、ISO14443 TypeA、FeliCaなどを含む資料体系。UHF Gen2とは別 | TR3RWManager.exe | UID, DSFID, Inventory2, ISO15693, FeliCa, MifareClassic, TR3RWManager, EEPROM |
| TR3X | TR3X | HF中心。一部ISO18000-3 Mode3対応 | UTR-S201 / R2000系ではない | TDR-MNL-PRCX-110 / TR3Xシリーズ通信プロトコル説明書 | TR3X-MD01, TR3X-MU01, TR3X-MN01, TR3X-LN01等 | ISO/IEC15693, ISO/IEC18000-3 Mode1, 一部Mode3 | TR3RWManager.exe | ICODE, Tag-it, my-d, UID, DSFID, AFI, S6700互換モード, EEPROM |
| UTR-S101 | UTR | UHF | UTR-S201とは別世代として扱う | UTR通信プロトコル説明書。UTR-S201シリーズ通信プロトコル説明書ではない | UTR-SU01-3CH, UTR-SN01-3CH | 要該当資料確認 | UTRRWManager.exe想定だが要確認 | UMP01, UTR-SU01-3CH, UTR-SN01-3CH |
