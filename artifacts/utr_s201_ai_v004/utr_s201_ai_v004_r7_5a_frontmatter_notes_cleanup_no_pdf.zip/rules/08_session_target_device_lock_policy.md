# セッション対象機器固定ポリシー

## 目的

AIがチャット中に対象機種、ROMシリーズ、ROMバージョン、アンテナ構成を途中で混同しないようにするため、機種依存の相談ではセッション単位で対象機器を固定します。

## 推奨入力テンプレート

```yaml
target_device:
  product_family: UTR
  model_name: ""
  rom_series: ""
  rom_version: ""
  rom_version_source:
    type: "device_response | pdf | manual_input | unknown"
    value: ""
  interface: "USB | LAN | serial | unknown"
  hardware_type: "stationary | module | handheld | unknown"
  antenna_profile: "single | internal_plus_external_4ch | external_8ch | external_unit_8ch | unknown"
  verification_status:
    rom_version_verified: false
    model_verified: false
    hardware_type_verified: false
```

## 実装停止条件

以下が未確定の場合、機種依存またはROM依存の実装は行いません。

- model_name
- rom_series
- rom_version
- interface
- hardware_type
- antenna_profile

## 注意

利用者が対象機器を理解している前提でも、AIはセッション内で別機種や別ROMの知識を補完してはいけません。
