# Codex / GitHubレビュー用 混同防止ルール

## 1. PRレビューで必ず見るファイル

- `src/*.py`
- `README.md`
- `docs/**/*.md`
- `tests/**/*.py`
- `.gitignore`
- `tools/*.py`

## 2. grep推奨ワード

```powershell
Select-String -Path .\**\* -Pattern "UID","DSFID","Inventory2","ISO15693","TR3RWManager","EEPROM","TR3X","TR3XM","UTRX","MS710","E710","UMP01" -CaseSensitive:$false
```

上記がヒットした場合、UTR-S201向けの説明として正しいか確認する。比較・禁止例ならOK。実装ロジックに入っていたら原則NG。

## 3. PRで確認すること

- [ ] READMEの対象がCodeXリポジトリになっているか
- [ ] UTR-S201シリーズ / R2000系が明記されているか
- [ ] UTRX, TR3XM, TR3X, UTR-S101を混ぜない注意があるか
- [ ] `UHF_Inventory` を使っているか
- [ ] `Inventory2` を使っていないか
- [ ] `PC+UII` / `EPC(UII)` として解析しているか
- [ ] `UID` / `DSFID` として解析していないか
- [ ] `UTRRWManager` のログ比較手順があるか
- [ ] 初期実機確認で危険操作をしないか
- [ ] `logs/`, `.env`, 実IP入り設定がGit管理対象外か

## 4. PRコメント例

```markdown
UTR-S201向けのコードとして確認しました。現状、TR3X/TR3XM由来と思われる `UID` / `Inventory2` / `ISO15693` の混入がないか追加確認してください。UTR-S201では `EPC(UII)` / `PC+UII` / `UHF_Inventory` を基準にしてください。
```

```markdown
この変更は初期実機確認の範囲を超えています。FLASH書き込み、出力設定変更、周波数設定変更、UHF_Write/Kill/Lock系は、初期確認用サンプルには含めない方針です。読み取り専用の確認フローへ戻してください。
```
