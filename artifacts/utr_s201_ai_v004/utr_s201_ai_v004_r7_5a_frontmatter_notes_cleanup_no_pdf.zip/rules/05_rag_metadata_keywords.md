# RAG登録用 metadata / keywords 推奨

## 1. 推奨YAML front matter

```yaml
---
title: "UTR-S201シリーズ混同防止ルール"
series: "UTR-S201"
family: "UTR"
band: "UHF"
chipset: "R2000"
source_type: "confusion_prevention_rule"
primary_manual: "TDR-MNL-PRC-UTR-S201-117"
not_for:
  - "UTRX"
  - "TR3XM"
  - "TR3X"
  - "UTR-S101"
keywords:
  - "UTR-S201"
  - "UTR-SUN02-4CH"
  - "UTR-SUN02V-8CH"
  - "UTR-SUN02-8CH"
  - "UTR-SHR201"
  - "USM01"
  - "USM02"
  - "USM05"
  - "USM06"
  - "USM08"
  - "UHF_Inventory"
  - "EPC(UII)"
  - "PC+UII"
  - "R2000"
  - "UTRRWManager"
negative_keywords:
  - "UTRX"
  - "MS710"
  - "E710"
  - "TR3XM"
  - "TR3X"
  - "UID"
  - "DSFID"
  - "Inventory2"
  - "ISO15693"
  - "TR3RWManager"
  - "EEPROM"
---
```

## 2. RAG検索で強く拾わせる語

- `UTR-S201 混同防止`
- `UTR UTRX 違い`
- `UTR TR3XM 混同禁止`
- `UTR-S201 EPC UII UID 違い`
- `UHF_Inventory Inventory2 違い`
- `UTRRWManager TR3RWManager 違い`
- `RAM FLASH EEPROM 違い UTR TR3X`
- `USM01 USM02 USM05 USM06 USM08 UMP01 違い`

## 3. RAG回答時の優先順位

1. 混同防止ルール
2. シリーズ識別マトリクス
3. UTR-S201通信プロトコルMarkdown
4. CodeXリポジトリのREADME / src
5. 過去の会話メモ

AIが別シリーズの文書を見つけた場合でも、対象がUTR-S201ならUTR-S201資料を優先する。
