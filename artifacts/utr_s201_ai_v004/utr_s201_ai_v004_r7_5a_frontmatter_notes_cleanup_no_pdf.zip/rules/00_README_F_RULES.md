# F工程 README - 対象機種・ROMシリーズ・アンテナ構成スコープ固定ルール

## 目的

このフォルダは、生成AI・Codex・ChatGPT Skill・Claude Project・Gemini Gems・Copilot Custom Instructions などに登録して使うための、**対象機種スコープ固定ルール集**です。

利用者は、TR3 / UTR / LTR などの機器種別を理解し、正しいSkillや資料を読み込ませる前提です。  
このルールの目的は、利用者の機器選択ミスを防ぐことではなく、**生成AIが似たシリーズ・似たコマンド・似たアンテナ制御を推測で混ぜることを防ぐ**ことです。

特に、UTR-S201 と UTR-S202 は大分類として近く見えても、アンテナ制御などでコマンドやパラメータの扱いが異なる可能性があります。そのため、このパッケージでは「UTR-S201/202シリーズ」と一括りにして機種依存実装を生成しません。

## 基本原則

1. **対象機種が未指定なら、機種依存コマンドを生成しない。**
2. **UTR-S201 と UTR-S202 を同一仕様として扱わない。**
3. **ROMシリーズ名、アンテナ構成、インターフェースが不明な場合は、推測しない。**
4. **PDF正本に根拠がない差分は「要確認」とする。**
5. **GitHub実装例は参考にできるが、仕様の正本ではない。**

## このルールで防ぐミス

- UTR-S201向けのアンテナ制御をUTR-S202へ推測流用する
- UTR-SUN02-4CHのANT0〜ANT3制御を、UTR-SUN02-8CHへ流用する
- UTR-SUN02-8CHの使用アンテナ番号体系を、単アンテナ機や4CH機へ流用する
- UTR-SUN02V-8CHとUTR-SUN02-8CHを同じ8CH機として扱い、内部/外部アンテナ番号の差分を無視する
- TR3X/TR3XM/HF系のUID/DSFID/Inventory2処理を、UTR/UHF系へ混ぜる
- ROMシリーズ名が不明なのに、機種判定ロジックを推測実装する

## ファイル一覧

| ファイル | 用途 |
|---|---|
| `01_target_model_scope.md` | 開発対象機種を固定する基本ルール |
| `02_rom_series_scope.md` | ROMシリーズ名を機種判定の根拠として扱うルール |
| `03_antenna_profile_scope.md` | 単アンテナ/4CH/8CHのアンテナ構成差分ルール |
| `04_no_cross_model_inference.md` | 似た機種・似たコマンドの推測流用禁止ルール |
| `05_model_specific_command_policy.md` | 機種依存コマンドの実装可否ルール |
| `06_target_device_input_template.md` | AIやCodexへ作業前に渡す対象機器入力テンプレート |
| `01_UTR_UTRX_TR3XM_混同防止ルール.md` | 既存のシリーズ混同防止ルール。継続使用 |
| `02_series_identification_matrix.md` | 既存のシリーズ識別表。継続使用 |
| `03_ai_pre_answer_checklist.md` | AI回答前チェックリスト。F工程で対象機種確認を追加 |
| `04_coding_guardrails_for_UTR.md` | UTRコード生成時のガードレール。F工程で機種依存条件を追加 |

## 構造化データ

| ファイル | 用途 |
|---|---|
| `03_structured_data/model_scope_matrix.yml` | 対象機種ごとの扱いをAIが読める形で整理 |
| `03_structured_data/rom_series_model_matrix.yml` | ROMシリーズ名と機種の対応、注意点 |
| `03_structured_data/antenna_profile_matrix.yml` | アンテナ構成別の注意点 |
| `03_structured_data/model_specific_command_matrix.yml` | 機種依存コマンドと実装条件 |
| `03_structured_data/source_priority.yml` | PDF、構造化データ、GitHub実装例、Markdownの優先順位 |

## 使い方

RAG登録では、F工程で追加した `01_target_model_scope.md`〜`06_target_device_input_template.md` を優先的に登録してください。Codexへ作業依頼する場合は、`06_target_device_input_template.md` の内容を作業指示の先頭へ貼り付けると、機種差分の推測実装を抑制できます。
