# ChatGPT Skill追記案 - 混同防止ルール

D工程で作成した `takaya_utr_s201_protocol` Skill に追記する場合は、`SKILL.md` の冒頭または `references/` に以下を追加してください。

## 追記文

```markdown
## Series confusion guard

Before answering or generating code, determine whether the user is asking about UTR-S201 series, UTRX, TR3XM, TR3X, or UTR-S101. For this skill, treat only UTR-S201 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201, or ROM series codes USM01 / USM02 / USM05 / USM06 / USM08, as in-scope.

Do not mix UTR-S201 with UTRX, TR3XM, TR3X, or UTR-S101. If terms such as UID, DSFID, Inventory2, ISO15693, TR3RWManager, EEPROM, FeliCa, MifareClassic, UMP01, MS710, or E710 appear, pause and verify the target series before proceeding.

For UTR-S201, use EPC(UII), PC+UII, StoredPC, RSSI, UHF_Inventory, UTRRWManager, and RAM/FLASH terminology. Do not use TR3X/TR3XM examples or commands unless explicitly comparing and clearly labeling them as not for UTR-S201.
```

## Skill references推奨配置

```text
references/
└─ confusion_rules/
   ├─ 01_UTR_UTRX_TR3XM_混同防止ルール.md
   ├─ 02_series_identification_matrix.md
   ├─ 03_ai_pre_answer_checklist.md
   └─ 04_coding_guardrails_for_UTR.md
```
