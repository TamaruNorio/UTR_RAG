# 他AI転用プロンプトスニペット

## 1. 最短版

```text
対象はUTR-S201シリーズ / R2000系です。UTRX、TR3XM、TR3X、UTR-S101の仕様を混ぜないでください。EPC(UII)を読むUHF_Inventoryを使い、TR3X/TR3XMのUID/DSFID/Inventory2/ISO15693/EEPROM/TR3RWManagerを混入させないでください。判断に迷う場合は、型式、ROMバージョンのシリーズ名コード、参照マニュアル番号を確認してください。
```

## 2. Claude Project向け

```text
このプロジェクトでは、UTR-S201シリーズの通信プロトコルとPython制御コードだけを扱います。対象型式は UTR-S201 / UTR-SUN02-4CH / UTR-SUN02V-8CH / UTR-SUN02-8CH / UTR-SHR201 です。ROMシリーズ名コードは USM01 / USM02 / USM05 / USM06 / USM08 をUTR-S201シリーズとして扱います。UMP01はUTR-S101なので別資料扱いです。UTRX、TR3XM、TR3Xのコマンド・レスポンス・サンプルコードを流用しないでください。特に UID、DSFID、Inventory2、ISO15693、TR3RWManager、EEPROM という語が出たら混同を疑って停止してください。
```

## 3. Codex向け

```text
このリポジトリではUTR-S201シリーズ / R2000系のPythonコードだけを扱ってください。参照実装は TamaruNorio/UTR_USB_Python_CodeX と TamaruNorio/UTR_LAN_Python_CodeX です。UTRX、TR3XM、TR3X、UTR-S101向けの仕様・コマンド・サンプルを混ぜないでください。UTR-S201ではEPC(UII) / PC+UII / RSSIを扱い、UID / DSFID / Inventory2 / ISO15693 を使わないでください。初期実機確認ではFLASH書き込み、FLASH初期化、RF出力設定変更、周波数設定変更、UHF_Write/Kill/Lock系を追加しないでください。
```

## 4. レビュー依頼用

```text
以下のコードがUTR-S201シリーズ専用として安全かレビューしてください。特に、UTRX/TR3XM/TR3X/UTR-S101の仕様混入がないか確認してください。チェック項目は、EPC(UII)とUIDの取り違え、UHF_InventoryとInventory2の取り違え、UTRRWManagerとTR3RWManagerの取り違え、RAM/FLASHとEEPROMの取り違え、危険操作の初期実機確認への混入です。
```
