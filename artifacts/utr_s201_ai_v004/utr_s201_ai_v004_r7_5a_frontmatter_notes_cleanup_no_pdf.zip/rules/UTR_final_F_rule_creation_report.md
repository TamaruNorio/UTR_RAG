# UTR final F - 混同防止ルールファイル作成レポート

作成日時: 2026-06-11T07:44:49.021345+00:00

## 実施内容

F工程として、UTR / UTRX / TR3XM / TR3X / UTR-S101を混同しないためのルールファイル群を作成しました。

## 方針

- 主対象は UTR-S201シリーズ / R2000系
- CodeXリポジトリは `TamaruNorio/UTR_USB_Python_CodeX` と `TamaruNorio/UTR_LAN_Python_CodeX` を正とする
- UTRXは本プロジェクト内に正式仕様資料を含めていないため、MS710/E710系の別扱いとして「要確認」に寄せる
- TR3XM/TR3XはHF/マルチプロトコル系として、UTR-S201のUHF Gen2系とは別に扱う
- UTR-S101は `UMP01` としてUTR-S201資料内でも「本書ではありません」とされるため別資料対象とする

## 成果物

- ルール本体
- シリーズ識別マトリクス
- AI回答前チェックリスト
- Pythonコード生成ガードレール
- RAG metadata / keywords 推奨
- Claude / Gemini / Copilot / Codex転用スニペット
- Codexレビュー用ルール
- Skill追記案
- CSV / YAML / JSON形式の識別表

## 注意

UTRXについては、今回のF工程では正式通信プロトコル資料を確認していません。そのため、具体的なコマンド仕様やレスポンス仕様は記載せず、UTR-S201資料を流用しないための停止ルールとして整理しています。
