# UTR / UTRX / TR3XM 混同防止ルール

## 1. 最上位ルール

**UTR-S201シリーズのコード・説明・RAG回答では、UTRX、TR3XM、TR3X、UTR-S101の仕様を混ぜない。**

AIが迷った場合は、推測して進めず、以下の順に確認する。

1. 型式名
2. ROMバージョン文字列のシリーズ名コード
3. 参照している通信プロトコル説明書のマニュアル番号
4. コマンド名と詳細コマンド
5. タグ識別名が `EPC/UII` なのか `UID` なのか
6. 設定保存先が `RAM/FLASH` なのか `EEPROM` なのか
7. ユーティリティ名が `UTRRWManager` なのか `TR3RWManager` なのか

## 2. UTR-S201シリーズとして扱ってよい条件

以下のいずれかが明示されている場合だけ、UTR-S201シリーズとして扱う。

- 型式が `UTR-S201`, `UTR-SUN02-4CH`, `UTR-SUN02V-8CH`, `UTR-SUN02-8CH`, `UTR-SHR201` のいずれか
- ROMバージョン読み取り結果のシリーズ名が `USM01`, `USM02`, `USM05`, `USM06`, `USM08` のいずれか
- 参照資料が `TDR-MNL-PRC-UTR-S201-117` または UTR-S201シリーズ通信プロトコル説明書
- コマンド体系が `UHF_Inventory`, `UHF_Read`, `UHF_Write`, `UHF_Kill`, `UHF_Lock` など `UHF_` 系である
- タグ識別が `EPC(UII)` / `PC+UII` / `StoredPC` / `RSSI` 中心である

## 3. 即停止ワード

UTR-S201シリーズの回答・コード生成中に次の語が出たら、**別シリーズ混入の疑い**として一度停止する。

### TR3XM / TR3X 混入疑い

- `UID`
- `DSFID`
- `Inventory2`
- `ISO15693`
- `Tag-it`
- `ICODE SLI`
- `my-d`
- `AFI`
- `S6700互換モード`
- `TR3RWManager`
- `EEPROM`
- `ReadSingleBlock`
- `WriteSingleBlock`
- `ReadMultiBlock`
- `ISO15693ThroughCmd`
- `FeliCa`
- `MifareClassic`

### UTR-S101 混入疑い

- `UMP01`
- `UTR-SU01-3CH`
- `UTR-SN01-3CH`
- `UTR通信プロトコル説明書 ※本書ではありません`

### UTRX 混入疑い

- `UTRX`
- `MS710`
- `E710`
- `E710系`
- `MS710系`

UTRXは本工程の対象外です。UTRXの正式資料を確認するまで、UTR-S201のコマンド・レスポンス・SUM例を流用してはいけません。

## 4. UTR-S201で使うべき語彙

- RFIDタグの識別: `EPC(UII)`, `PC+UII`, `StoredPC`, `TID`, `User`, `MemBank`
- プロトコル: `ISO/IEC18000-63`, `EPCglobal Class1 Generation2`
- コマンド: `UHF_Inventory`, `UHF_InventoryRead`, `UHF_Read`, `UHF_Write`, `UHF_Kill`, `UHF_Lock`, `UHF_BlockWrite`, `UHF_BlockErase`, `UHF_BlockWrite2`, `UHF_Encode`, `UHF_ThroughCmd`
- 設定: `RAM値`, `FLASH値`
- ツール: `UTRRWManager.exe`
- 通信: `USB仮想COM`, `UART`, `LAN/TCP`, `Wi-Fi`, `Bluetooth`

## 5. UTR-S201で避ける語彙

UTR-S201制御コードの文脈では、原則として以下を使わない。

- `UIDを読む`
- `DSFIDを読む`
- `Inventory2を実行する`
- `ISO15693タグ`
- `TR3RWManagerで確認する`
- `EEPROM設定を書き込む`
- `AFIで判別する`

ただし、比較説明や「使ってはいけない例」として出す場合は可。その場合は必ず「これはUTR-S201用ではない」と明記する。

## 6. 回答時の自己チェック文

AIはUTR-S201関連の回答を出す前に、内部的に次を確認する。

```text
対象型式はUTR-S201シリーズか？
参照資料はTDR-MNL-PRC-UTR-S201系か？
EPC/UIIではなくUIDと書いていないか？
UHF_InventoryではなくInventory2を書いていないか？
UTRRWManagerではなくTR3RWManagerを書いていないか？
RAM/FLASHではなくEEPROMを書いていないか？
危険操作を初期実機確認に入れていないか？
```

## 7. 初期実機確認での安全ルール

初期実機確認では以下だけを許可する。

- 接続確認
- ROMバージョン読み取り
- シリーズ名コード確認
- コマンドモード設定
- 設定値の読み取り
- UHF_Inventory 1回
- ACK/NACK解析
- TX/RXログ保存

初期実機確認では以下を禁止する。

- FLASH書き込み
- FLASH初期化
- RF出力設定変更
- 周波数設定変更
- UHF_Write
- UHF_Kill
- UHF_Lock
- UHF_BlockWrite
- UHF_BlockErase
- UHF_Encode
- 連続Inventory
- リスタート

## 8. 判断できない場合の回答テンプレート

```text
この情報だけでは、対象がUTR-S201シリーズか、UTRX/TR3XM/TR3X/UTR-S101かを確定できません。
型式、ROMバージョン読み取り結果のシリーズ名コード、参照している通信プロトコル説明書のマニュアル番号を確認してください。
確認できるまで、UTR-S201用のUHF_InventoryやFLASH関連コマンドは実行しない前提で進めます。
```
