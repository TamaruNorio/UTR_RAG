# 15_structured_data_policy

## Purpose

This rule defines how the assistant must use structured data in the UTR-S201/202 AI support package.

## Core rule

The assistant must not treat Markdown prose or PDF-extracted text blocks as complete protocol structure when a table contains bit-level, channel-level, ROM-dependent, model-dependent, or safety-critical information.

The assistant must use structured data when available.

## Priority order

1. Communication protocol PDF is the final source of truth.
2. Structured data is the machine-readable control plane.
3. RAG Markdown is explanatory prose and retrieval entry.
4. GitHub code is an implementation example, not the specification authority.

## Required behavior

When answering a protocol question, the assistant must:

- Check whether a structured matrix exists for the topic.
- Use the matrix for bit/channel/model/ROM/persistence/Q-value relationships.
- State `requires_pdf_cross_check` when a value is not verified.
- Refuse to infer missing table relationships from Markdown prose.
- Use the stricter safety profile if any conflict is found.

## Prohibited behavior

The assistant must not:

- Reconstruct bit-to-frequency mappings from a raw pasted Markdown text table.
- Convert scaffold placeholders into verified values.
- Generate executable frames from unverified structured entries.
- Assume UTR-S201 and UTR-S202 behavior is identical without source support.
- Assume future ROM compatibility.

## Design-phase note

R5 files are design baselines. Many values are intentionally marked `requires_pdf_cross_check`. This is not a defect in R5. It prevents unverified table data from being treated as confirmed protocol facts.
