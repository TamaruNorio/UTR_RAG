# UTR-S201 Pythonコード生成ガードレール

> F工程追記: 機種依存処理では、対象機種、ROMシリーズ名、アンテナ構成を確認してください。UTR-S201とUTR-S202を同一仕様と仮定しないでください。PDF正本で確認できない差分は要確認とし、送信可能コードを生成しないでください。


## 1. 対象

このガードレールは、UTR-S201シリーズ向けPythonコードを生成・レビューするためのものです。

対象リポジトリは以下を正とする。

- `TamaruNorio/UTR_USB_Python_CodeX`
- `TamaruNorio/UTR_LAN_Python_CodeX`

README内に旧リポジトリ名が残っている場合でも、CodeX付きリポジトリを正とする。

## 2. 共通アーキテクチャ

USB版とLAN版で共通化できるもの:

- コマンド定義
- SUM計算
- フレーム検証
- ACK/NACK解析
- NACKエラー表示
- UHF_Inventoryレスポンス解析
- PC+UII抽出
- RSSI変換
- ログ保存
- 入力値検証

USB版とLAN版で分けるもの:

- USB: `serial.Serial`, COMポート一覧, pyserial依存
- LAN: `socket`, TCPクライアント, IP/ポート入力, 接続確認, mock TCPサーバー

## 3. 禁止する実装

初期版・検証版では以下を実装しない。

- FLASH書き込み
- FLASH初期化
- RF出力設定変更
- 周波数設定変更
- UHF_Write
- UHF_Kill
- UHF_Lock
- UHF_BlockWrite
- UHF_BlockErase
- UHF_Encode
- 無限連続Inventory
- 自動リスタート
- 実IPや顧客名を初期値にしたコード

## 4. 必須実装

- `calculate_sum_value(data: bytes) -> int`
- `verify_sum_value(frame: bytes) -> bool`
- `build_frame(command: int, data: bytes) -> bytes` または同等処理
- 1バイト単位またはフレーム単位の受信検証
- STX/ETX/CR/SUM/データ長の検証
- ACK/NACK判定
- NACKエラーコード表示
- タイムアウト処理
- TX/RXのHEXログ
- 実機接続前の注意表示
- UTRRWManagerログとの比較手順

## 5. レスポンス解析の表現

UTR-S201では以下の表現を使う。

- `EPC(UII)`
- `PC+UII`
- `StoredPC`
- `RSSI`
- `読み取り枚数`

以下の表現は原則使わない。

- `UID`
- `DSFID`
- `ISO15693 UID`

## 6. 実機確認フロー

1. UTRRWManagerで接続確認
2. UTRRWManagerでROMバージョン読み取り
3. UTRRWManagerでUHF_Inventory 1回
4. UTRRWManagerのTX/RXログを保存
5. Pythonサンプルで同じ順に実行
6. TX/RXを比較
7. NACKやタイムアウトがあれば、コードではなく通信条件から切り分ける

## 7. コードレビュー時のNG例

```python
# NG: TR3X/TR3XMのUID前提をUTR-S201に混ぜている
uid = data[1:9]
```

```python
# NG: UTR-S201なのにInventory2を使っている
COMMANDS['INVENTORY_2'] = bytes.fromhex('02007803F0400103B10D')
```

```python
# NG: 初期確認でFLASH初期化を実行する
COMMANDS['FLASH_INIT'] = ...
```

## 8. コードレビュー時のOK例

```python
# OK: UTR-S201のEPC(UII)前提
pc_uii_length = frame[8]
pc_uii_data = frame[9:9 + pc_uii_length]
```

```python
# OK: SUMは固定値ではなく計算する
def calculate_sum_value(data: bytes) -> int:
    return sum(data) & 0xFF
```
