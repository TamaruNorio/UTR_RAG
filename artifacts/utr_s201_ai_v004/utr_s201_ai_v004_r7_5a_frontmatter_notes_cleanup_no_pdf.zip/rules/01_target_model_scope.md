# 01. 対象機種スコープ固定ルール

## 目的

このルールは、生成AIがUTR内の機種差分を推測で補完しないようにするためのものです。

利用者は、自分が使用している機器を理解している前提です。  
ただし、AIは「UTR-S201/202」「UTRシリーズ」「8CH」などの大きな語だけを見ると、似た機種の知識を混ぜる可能性があります。

## 必須入力

機種依存の実装・コマンド生成・Codex依頼を行う前に、次の情報を固定してください。

```yaml
target_device:
  product_family: UTR
  model_name: "要入力"
  rom_series: "要入力またはPDF正本で要確認"
  interface: "USB | LAN | Serial | 要確認"
  antenna_profile: "single | internal_1ch_external_3ch | external_8ch | external_unit_8ch | 要確認"
  source_pdf: "UTR-S201シリーズ通信プロトコル説明書など、正式名称を記載"
```

## 機種依存実装の停止条件

以下のいずれかに該当する場合、AIは機種依存コマンドを生成してはいけません。

- `model_name` が未指定
- `rom_series` が不明
- `antenna_profile` が不明
- UTR-S201 と UTR-S202 の差分をPDF正本で確認していない
- 4CH機と8CH機のアンテナ番号体系を同一扱いしている
- GitHub実装例だけを根拠に、別機種へ流用しようとしている

## UTR-S201 と UTR-S202 の扱い

UTR-S201 と UTR-S202 は、名称が近くても同一仕様として扱ってはいけません。

特に、以下はPDF正本または実機確認なしに共通化しないでください。

- アンテナ制御
- 使用アンテナ番号の読み取り/書き込み
- アンテナ切替設定
- UHF_CheckAntenna
- Inventory関連パラメータ
- 周波数設定
- 送信出力設定
- FLASH/RAM設定

## 回答時の表現

不明な場合は、次のように明示してください。

```text
対象機種が UTR-S201 なのか UTR-S202 なのか、またROMシリーズ名とアンテナ構成が未確定のため、機種依存コマンドは生成しません。
PDF正本で対象機種の該当章を確認してください。
```
