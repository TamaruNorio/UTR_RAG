# Command Safety Matrix Usage Rule

## Purpose

`03_structured_data/command_safety_matrix.yml` is the single authoritative source for AI safety classification of command-like operations in this package.

Do not independently redefine `risk_level`, code-generation permission, executable Hex output permission, or automatic-send permission in multiple Markdown files.

## Rule

When a RAG chunk, large extracted Markdown file, Skill instruction, prompt, or validation report discusses a command, it must follow this order:

1. Resolve the command identity.
2. Look up the command in `command_safety_matrix.yml`.
3. Use the matrix value for:
   - `risk_level`
   - `allowed_response_modes`
   - `code_generation_policy`
   - `executable_hex_output`
   - `completed_checksum_output`
   - `automatic_send_allowed`
   - `safety_guards`
4. If the command is missing from the matrix, do not infer safety status from the Markdown body.
5. If the matrix and a RAG chunk conflict, the matrix wins for AI safety classification.
6. If the matrix and the PDF conflict on command specification, the PDF wins for protocol correctness, and the matrix must be updated after review.

## Scope

This rule is for AI behavior and review consistency. It does not make the matrix the source of truth for the protocol specification itself.

The communication protocol specification remains the final authority for:

- command codes,
- data formats,
- response formats,
- bit definitions,
- ROM-version behavior,
- model-specific behavior,
- timing and hardware behavior.

## Required front matter pattern

Command RAG chunks should avoid duplicating complete safety policy. They should reference the matrix.

```yaml
---
chunk_type: command_reference
command_profile_ref: command_safety_matrix.yml#UHF_INVENTORY_55_10
risk_level: derived_from_command_safety_matrix
response_modes: derived_from_command_safety_matrix
source_status: requires_pdf_page_mapping
markdown_is_authoritative: false
---
```

If a file temporarily contains explicit `risk_level`, it must be validated against the matrix. Temporary duplication is allowed only while migrating older files.

## Migration rule for old large files

Large extracted Markdown files may keep explanatory content, but AI must not rely on their local `risk_level` field if a `command_profile_ref` exists.

Migration steps:

1. Add `command_profile_ref`.
2. Replace local safety fields with `derived_from_command_safety_matrix` where possible.
3. Keep local notes only for source explanation, page traceability, or PDF cross-check status.
4. Mark unresolved command-code mismatch as `requires_pdf_confirmation`.

## Handling unresolved command identities

If file names or command codes disagree, such as `55_14` vs `55_15`, do not choose by inference.

Use a profile such as:

```yaml
command_profile_ref: command_safety_matrix.yml#UHF_READ_55_14_OR_55_15_REQUIRES_PDF_CHECK
source_status: requires_pdf_confirmation_for_command_code
```

The AI may explain the issue and list the PDF fields to check, but it must not generate implementation code or executable Hex until the mismatch is resolved.

## Response mode linkage

- `low` can allow read-only helper code after scope is clear.
- `medium` requires target/model/antenna context when applicable.
- `high` uses `high_risk_safety_output` by default and requires explicit scope before planning.
- `critical` uses `absolute_refusal_safety_output` or `high_risk_safety_output`; implementation code and executable Hex are prohibited by default.

## Completed Hex and SUM rule

The matrix prohibits executable Hex output and completed checksum output for all command profiles.

If a frame example is needed, use:

```text
02 ... 03 [MUST_RECALCULATE_SUM] 0D
```

Do not output a completed SUM value for an executable frame.

## Review checklist

When reviewing a RAG chunk or Skill prompt, confirm:

- [ ] command has a `command_profile_ref` or is explicitly out of scope,
- [ ] `risk_level` does not conflict with the matrix,
- [ ] critical commands do not allow code generation,
- [ ] high/critical commands do not output executable Hex,
- [ ] source status is clear,
- [ ] PDF page/section mapping is tracked or marked as not cross-checked,
- [ ] unresolved command-code mismatch is not silently resolved.
