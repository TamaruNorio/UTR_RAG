# MANIFEST — v004 R7-4F pre-RC candidate preparation no-PDF

## Package status

- status: R7-4F pre-RC candidate preparation no-PDF
- base: v004 R7-4D/R7-4D-2 no-PDF working package
- total_files: 278
- pdf_files: 0
- formal_RC: false
- real_device_verification: not_complete

## Integrated stages

- R1: redesign requirements
- R2: AI response-mode control
- R3: command safety matrix
- R4: source traceability and code annotation
- R5: structured data design
- R7-4F: RAG/front matter/index safety synchronization and pre-RC preparation

## Primary control files

- README.md
- VALIDATION.md
- 00_policy/ai_response_modes.yml
- 00_policy/high_risk_response_templates.yml
- 03_structured_data/command_safety_matrix.yml
- 03_structured_data/source_traceability_matrix.yml
- 03_structured_data/rag_chunk_index.yml
- 03_structured_data/structured_data_schema_index.yml
- rules/00_response_mode_control.md
- rules/01_command_safety_matrix_usage.md
- rules/13_source_traceability_policy.md
- rules/14_code_source_annotation_policy.md
- rules/15_structured_data_policy.md
- rules/16_pdf_table_conversion_policy.md
- docs/code_annotation_guide.md
- docs/structured_data_guide.md
- docs/redesign/

## Review focus for next pass

- Does the package now avoid "PDFを読め" responses by using source-grounded implementation explanations?
- Does the command safety matrix prevent risk-level divergence?
- Does source traceability connect RAG, structured data, and code annotations?
- Does structured data address PDF table/bitfield loss?
- Are unresolved PDF cross-check items clearly marked?
