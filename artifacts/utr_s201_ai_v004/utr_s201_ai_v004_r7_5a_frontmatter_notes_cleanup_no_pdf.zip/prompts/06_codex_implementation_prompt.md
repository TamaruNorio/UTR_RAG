
> F工程追記: 機種依存処理では、対象機種、ROMシリーズ名、アンテナ構成を確認してください。UTR-S201とUTR-S202を同一仕様と仮定しないでください。PDF正本で確認できない差分は要確認とし、送信可能コードを生成しないでください。

---
title: "Codex小規模実装依頼プロンプト"
type: "prompt"
target: "codex"
mode: "implementation"
operation_policy: "small_safe_change"
---

# Codex小規模実装依頼プロンプト

Codexに小さな実装を依頼する場合に使います。危険操作は対象外です。

```text
あなたは、GitHub上の既存Pythonリポジトリを安全に改修するCodexエージェントです。

# 作業種別

小規模実装です。
mainブランチを直接変更しないでください。

# 対象リポジトリ

ユーザーが指定した以下いずれかのリポジトリを対象にしてください。

- TamaruNorio/UTR_USB_Python_CodeX
- TamaruNorio/UTR_LAN_Python_CodeX

# 目的

UTR-S201シリーズ / R2000系 RFIDリーダライタ制御用Pythonサンプルを、初心者でも安全に実機確認しやすい形に改善してください。

# 正本と補助資料

- プロトコル仕様の正本はUTR-S201シリーズ通信プロトコル説明書PDFです。
- MarkdownやAI補助資料はPDF参照補助資料です。
- 仕様値、bit定義、コマンドHEX、レスポンス仕様を推測で変更しないでください。
- PDF正本が確認できない箇所は、要確認として保留してください。

# 対象シリーズ

対象はUTR-S201シリーズ / R2000系です。
UTRX、TR3XM、TR3X、TR3、UTR-S101の仕様やコマンドを混ぜないでください。

# 変更してよい範囲

今回の依頼範囲内で、ユーザーが指定したファイルのみ変更してください。
指定がない場合は、以下のような安全な改善に限定してください。

- READMEの手順追記
- .gitignoreの安全な追記
- ログ保存先の整理
- NACK表示の改善
- SUM計算テストの追加
- mock受信フレーム解析テストの追加
- コメント改善

# 変更してはいけない範囲

以下は禁止です。

- FLASHへの設定書き込み
- FLASH初期化
- 送信出力設定変更
- 送信出力の一時変更コードの新規追加・拡張・安全ガード緩和
- 周波数設定変更
- UHF_SetInventoryParam の自動送信
- RFタグ書き込み
- Kill
- Lock
- ThroughCmd
- リスタート
- 常時連続Inventory
- ROMシリーズ判定ロジックの変更
- 安全ガードの削除または緩和
- 既存コマンドHEXの根拠なき変更
- 実機IP、顧客情報、認証情報、実機ログのコミット


補足:

- 既存の送信出力一時変更実装を調査するだけなら可能です。
- 既存実装のバグ修正は、対象ファイル、変更範囲、復元条件、実機確認条件がユーザーから明示された場合のみ扱ってください。
- 新規追加、対象機種拡大、送信出力ガード緩和は、この小規模実装プロンプトでは扱いません。

# 作業前コマンド

PowerShellで以下を実行してください。

```powershell
git status --short
git branch --show-current
git switch main
git pull --ff-only
git switch -c work/utr-safe-small-fix
```

既に作業ブランチが指定されている場合は、ユーザー指定を優先してください。

# 作業後コマンド

```powershell
git diff
git diff --check
git status --short
python -m pytest
```

pytestが存在しない場合は、以下を報告してください。

- 実行したコマンド
- エラー内容
- 代替で実施した確認

# 報告形式

## 変更概要

## 変更ファイル

## 変更していない危険操作

## テスト結果

## git diff --check 結果

## git status --short 結果

## PDF正本確認が必要な点

## 実機確認が必要な点

## コミットメッセージ案
```

## v004_i3 追加禁止事項

以下は今回の明示依頼がない限り実装禁止です。

- 未知ROMまたは将来ROMに対するバージョン依存処理
- 既知ROMの仕様を上位互換として将来ROMへ適用する処理
- UHF_Kill / UHF_Lock / UHF_ThroughCmd / FLASH書き込み / FLASH初期化の実装コード
- 上記コマンドの完成Hexフレーム、SUM計算済みフレーム、自動送信処理
- 高リスクコマンドのCodex実装依頼文生成
- AIが暗算したSUM値を実機送信用として採用すること

SUM値は検証済みスクリプトまたは既存コードで再計算してください。
