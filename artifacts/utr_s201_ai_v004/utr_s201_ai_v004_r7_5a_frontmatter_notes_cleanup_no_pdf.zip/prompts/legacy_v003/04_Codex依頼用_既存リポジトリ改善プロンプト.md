---
title: "Codex依頼用 既存リポジトリ改善プロンプト"
type: "prompt"
target: "codex github workflow"
---

# Codex依頼用 既存リポジトリ改善プロンプト

GitHub上のCodeXリポジトリを改修する場合に使います。`main`を直接変更せず、作業ブランチ前提で依頼してください。

```text
あなたは、GitHub上の既存Pythonリポジトリを安全に改修するCodexエージェントです。

# 対象リポジトリ

次のどちらかを対象にしてください。

- TamaruNorio/UTR_USB_Python_CodeX
- TamaruNorio/UTR_LAN_Python_CodeX

作業対象のリポジトリは、ユーザーが指定したものを正としてください。
README内に旧リポジトリ名が残っていても、CodeX付きリポジトリを正として扱ってください。

# 目的

UTR-S201シリーズ / R2000系 RFIDリーダライタ制御用Pythonサンプルを、初心者でも実機確認しやすく、保守しやすい構成に改善してください。

# 対象シリーズ

対象は UTR-S201シリーズ / R2000系 です。
UTRX、TR3XM、TR3X、UTR-S101の仕様やコマンドを混ぜないでください。

# 作業ルール

1. `main` ブランチを直接変更しない
2. 作業ブランチを作成する
3. 変更前にファイル構成を確認する
4. 変更範囲を小さくする
5. 既存の実機通信仕様を壊さない
6. 危険操作を勝手に追加しない
7. 実機IP、顧客情報、ログ、認証情報をコミットしない
8. 変更後にpytestまたは既存チェックを実行する
9. 変更内容、動作確認方法、未確認事項をまとめる

# 初期版で禁止する操作

以下は実装しないでください。

- FLASH書き込み
- FLASH初期化
- FLASH設定復元
- RF出力設定変更
- 周波数設定変更
- Kill
- Lock
- RFタグ書き込み系コマンド
- 連続Inventoryの常時実行
- リスタート

# 改善してほしい観点

必要に応じて、以下を改善してください。

- README内の旧リポジトリ名をCodeX名へ修正
- `src/` のサンプルコードのコメント改善
- STX / ETX / SUM / CR 検証のテスト追加
- NACKエラーコード表示の改善
- ログ保存先の整理
- `logs/`、`.env`、実機ログの `.gitignore` 対応
- VS Code用 `.vscode/launch.json` の追加または改善
- mockサーバー/テストの説明改善
- 実機確認手順の安全確認を強化

# 変更してはいけない箇所

- プロトコル仕様を推測で変更しない
- 既存のコマンドHEXを根拠なく変更しない
- 実機で未確認の危険操作を追加しない
- UTRX/TR3XM/TR3X系のコマンドに置き換えない

# 完了条件

作業後に以下を報告してください。

1. 変更したファイル一覧
2. 変更理由
3. 実行したテスト/チェック
4. 実機確認が必要な箇所
5. 危険操作を追加していないことの確認
6. コミットメッセージ案
7. Pull Request本文案

# PR本文案に含めること

- Summary
- Changes
- Safety notes
- Test results
- Hardware verification status
- Not included / intentionally out of scope
```
