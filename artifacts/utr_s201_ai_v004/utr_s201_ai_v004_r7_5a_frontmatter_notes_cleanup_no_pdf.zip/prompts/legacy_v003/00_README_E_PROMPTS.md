---
title: "UTR-S201 Pythonサンプル生成プロンプト集"
project: "UTR-S201 protocol markdown project"
phase: "E"
status: "final"
target_series: "UTR-S201 series / R2000"
source_repositories:
  - "TamaruNorio/UTR_LAN_Python_CodeX"
  - "TamaruNorio/UTR_USB_Python_CodeX"
---

# UTR-S201 Pythonサンプル生成プロンプト集

## 目的

このフォルダは、生成AIに **UTR-S201シリーズ向けPython制御サンプル** を作らせるためのプロンプト集です。

対象は **UTR-S201シリーズ / R2000系** です。

対象機種:

- UTR-S201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201

## 正として参照するCodeXリポジトリ

このE工程では、以下の **CodeX付きリポジトリ** を正として扱います。

```text
TamaruNorio/UTR_LAN_Python_CodeX
TamaruNorio/UTR_USB_Python_CodeX
```

README内に旧リポジトリ名が残っていても、このプロンプト集では `_CodeX` 付きのリポジトリを正とします。

## 使い分け

| ファイル | 用途 |
|---|---|
| `01_UTR_S201_Python生成_共通マスタープロンプト.md` | USB/LAN共通の生成AI向け基本プロンプト |
| `02_UTR_USB_Python生成プロンプト_CodeX参照版.md` | USBシリアル接続版サンプルを生成させるプロンプト |
| `03_UTR_LAN_Python生成プロンプト_CodeX参照版.md` | LAN/TCP接続版サンプルを生成させるプロンプト |
| `04_Codex依頼用_既存リポジトリ改善プロンプト.md` | GitHub/Codexで既存リポジトリを改修させるプロンプト |
| `05_Claude_Gemini_Copilot転用プロンプト.md` | ChatGPT以外のAIに貼るための転用プロンプト |
| `06_生成AI出力レビュー観点.md` | AIが生成したコードをレビューするチェックリスト |

## 最重要ルール

生成AIに依頼する際は、必ず次を明記してください。

```text
対象はUTR-S201シリーズ / R2000系です。
UTRX、TR3XM、TR3X、UTR-S101の仕様やコマンドを混ぜないでください。
プロトコル仕様の正は、UTR-S201シリーズ通信プロトコル説明書由来のMarkdownです。
実装スタイルの参考は TamaruNorio/UTR_LAN_Python_CodeX と TamaruNorio/UTR_USB_Python_CodeX です。
```

## 初期版で禁止する操作

初期実機確認用のPythonサンプルでは、以下を実装しない方針にしてください。

- FLASH書き込み
- FLASH初期化
- FLASH設定復元
- RF出力設定変更
- 周波数設定変更
- Kill
- Lock
- RFタグ書き込み系コマンド
- 連続Inventoryの常時実行
- リスタート

必要になった場合は、別タスクとして、確認プロンプト・ログ保存・明示的な `YES` 入力・危険操作フラグを付けて実装してください。
