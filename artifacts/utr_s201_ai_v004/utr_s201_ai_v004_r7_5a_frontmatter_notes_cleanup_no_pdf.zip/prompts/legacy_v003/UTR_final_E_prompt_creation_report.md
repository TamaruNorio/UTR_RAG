---
title: "UTR final E prompt creation report"
phase: "E"
created_at: "2026-06-11T07:41:21.753763+00:00"
---

# UTR final E prompt creation report

## 実施内容

E工程として、UTR-S201シリーズ制御用Pythonサンプル生成に使えるプロンプト集を作成しました。

## 参照したCodeXリポジトリ

- `TamaruNorio/UTR_LAN_Python_CodeX`
- `TamaruNorio/UTR_USB_Python_CodeX`

## 反映した要点

- CodeX付きリポジトリを正として扱う
- README内の旧リポジトリ名は正としない
- USB版は `pyserial` / COMポート選択 / ACK-NACK処理を重視
- LAN版は TCPクライアント / IP・ポート指定 / mock TCPサーバー / 実機確認前の安全確認を重視
- プロトコル仕様の正はUTR-S201シリーズ通信プロトコル説明書由来Markdownとする
- UTRX / TR3XM / TR3X / UTR-S101との混同を禁止
- 初期実機確認では危険操作を禁止

## 作成ファイル

- `00_README_E_PROMPTS.md`
- `01_UTR_S201_Python生成_共通マスタープロンプト.md`
- `02_UTR_USB_Python生成プロンプト_CodeX参照版.md`
- `03_UTR_LAN_Python生成プロンプト_CodeX参照版.md`
- `04_Codex依頼用_既存リポジトリ改善プロンプト.md`
- `05_Claude_Gemini_Copilot転用プロンプト.md`
- `06_生成AI出力レビュー観点.md`

## 次工程

次はF工程として、UTR / UTRX / TR3XMを混同しないためのルールファイルを作成します。
