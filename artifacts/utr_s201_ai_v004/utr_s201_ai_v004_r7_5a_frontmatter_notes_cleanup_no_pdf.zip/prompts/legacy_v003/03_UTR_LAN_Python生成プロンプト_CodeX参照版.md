---
title: "UTR LAN Python生成プロンプト CodeX参照版"
type: "prompt"
connection: "tcp lan"
reference_repo: "TamaruNorio/UTR_LAN_Python_CodeX"
---

# UTR LAN Python生成プロンプト CodeX参照版

LAN/TCP接続版のPythonサンプルを生成AIに作らせる場合は、以下を貼り付けてください。

```text
あなたは、タカヤ製 UTR-S201シリーズ / R2000系 RFIDリーダライタをLAN/TCP接続で制御するPythonサンプルを作るエンジニアです。

# 1. 参照リポジトリ

実装スタイルの参考は、次のCodeXリポジトリです。

- TamaruNorio/UTR_LAN_Python_CodeX

README内に旧リポジトリ名が残っていても、CodeX付きリポジトリを正として扱ってください。

このリポジトリの以下の考え方を踏襲してください。

- USB版サンプルの構造を踏襲し、通信層のみTCPに置き換える
- UTR-S201シリーズをLAN/TCP経由で制御する
- ROMバージョン確認、コマンドモード切替、送信出力値/周波数チャンネル取得、UHF_Inventory、RSSIとPC+UII抽出、ログ保存を実装する
- 受信フレームは1バイトずつ読み取り、STX / ETX / SUM / CR を検証して確定する
- 実機確認前にUTRRWManagerでTX/RXログを保存し、PythonサンプルのTX/RXと比較する
- 初期実機確認では危険操作をしない

# 2. 作成するLAN版サンプルの目的

LAN接続されたUTR-S201シリーズリーダライタに対して、以下を行うPythonサンプルを作成してください。

1. IPアドレスとTCPポートを入力またはコマンドライン引数で受け取る
2. TCPクライアントとして接続する
3. ROMバージョン確認
4. コマンドモード設定
5. UHF_Inventoryを1回または指定回数実行
6. タグのPC+UII / EPC(UII)を表示
7. RSSIが取得できる場合は表示
8. ACK / NACK / タイムアウトを表示
9. 送信HEX / 受信HEXをログ保存
10. TCP切断

# 3. 接続条件

以下を仮定してください。

- OS: Windows 10 / 11
- Python: 3.10以上
- 接続方式: LAN / TCP
- 本プログラムはTCPクライアント
- UTR側はTCPサーバー相当
- 既定ポート例: 9004。ただし装置設定に依存するため、UTRRWManagerで事前確認すること
- IPアドレスはデフォルト値をコードに固定しない。ユーザー入力または引数で指定する

# 4. 必須の関数・クラス構成

以下の構成で作ってください。

- `calculate_sum_value(data: bytes) -> int`
- `verify_sum_value(frame: bytes) -> bool`
- `build_frame(command: int, data: bytes = b"", address: int = 0x00) -> bytes`
- `parse_frame(buffer: bytes) -> list[bytes]`
- `parse_nack_response(frame: bytes) -> str`
- `parse_inventory_response(response: bytes) -> ...`
- `TcpSession` クラス
  - `connect()`
  - `send(command: bytes)`
  - `receive(timeout: float) -> bytes`
  - `communicate(command: bytes, timeout: float) -> bytes`
  - `close()`
- `main() -> None`

# 5. コマンド定義

既存LAN CodeXサンプルのコマンド定義を参考にしてください。
最低限、以下を用意してください。

- ROM_VERSION_CHECK
- COMMAND_MODE_SET
- UHF_INVENTORY
- UHF_GET_INVENTORY_PARAM
- UHF_READ_OUTPUT_POWER
- UHF_READ_FREQ_CH

ただし、初期実機確認用では、RF出力設定変更や周波数設定変更などの書き込み系コマンドは実行しないでください。

# 6. 実機接続時の安全確認

127.0.0.1以外に接続する場合は、実行前に以下を表示し、ユーザーが `YES` と入力した場合のみ接続してください。

- 接続先IP
- TCPポート
- 実行するコマンド一覧
- 実行しない危険操作一覧
- ログ保存先
- 期待する結果

# 7. mock TCPサーバー

実機なしでもテストできるように、可能であれば以下も作成してください。

```text
tools/mock_utr_tcp_server.py
tools/mock_client_check.py
```

mockサーバーでは最低限、以下のシナリオを用意してください。

- one-tag: タグ1枚読み取り相当
- no-tag: タグなし相当
- nack: NACK応答相当

mock応答のHEXは仮値でよい場合でも、SUMは必ず正しく計算してください。
仮値の場合は、READMEに「実機ログではない」と明記してください。

# 8. 危険操作の禁止

初期版では以下を実装しないでください。

- FLASH書き込み
- FLASH初期化
- FLASH設定復元
- RF出力設定変更
- 周波数設定変更
- Kill
- Lock
- RFタグ書き込み系コマンド
- 連続Inventoryの常時実行
- リスタート

# 9. 出力してほしいファイル

以下のファイルを、完全な内容で提示してください。

```text
UTR_LAN_Python_sample_generated/
├─ src/
│  └─ UTR_LAN_sample_generated.py
├─ tools/
│  ├─ mock_utr_tcp_server.py
│  └─ mock_client_check.py
├─ tests/
│  └─ test_protocol_frame.py
├─ requirements-dev.txt
├─ README.md
├─ .gitignore
└─ .vscode/
   └─ launch.json
```

# 10. READMEに必ず書くこと

READMEには以下を書いてください。

- 対象機種
- UTRX/TR3XMと混同しない注意
- 必要環境
- TCP/IP設定の確認方法
- UTRRWManagerで事前に確認すること
- UTRRWManagerのTX/RXログとPython側ログを比較すること
- mock TCPサーバーの使い方
- 実機確認ツールの使い方
- 初期実機確認で禁止している危険操作
- `logs/real_device/` をGit管理しないこと

# 11. 回答スタイル

初心者でもそのまま作業できるように、日本語で、手順と完全なコードを省略せず出してください。
```
