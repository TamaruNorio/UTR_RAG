---
title: "UTR USB Python生成プロンプト CodeX参照版"
type: "prompt"
connection: "usb serial"
reference_repo: "TamaruNorio/UTR_USB_Python_CodeX"
---

# UTR USB Python生成プロンプト CodeX参照版

USBシリアル接続版のPythonサンプルを生成AIに作らせる場合は、以下を貼り付けてください。

```text
あなたは、タカヤ製 UTR-S201シリーズ / R2000系 RFIDリーダライタをUSBシリアル接続で制御するPythonサンプルを作るエンジニアです。

# 1. 参照リポジトリ

実装スタイルの参考は、次のCodeXリポジトリです。

- TamaruNorio/UTR_USB_Python_CodeX

README内に旧リポジトリ名が残っていても、CodeX付きリポジトリを正として扱ってください。

このリポジトリの以下の考え方を踏襲してください。

- UTR-S201シリーズをUSBシリアル接続で制御する
- Windows 10/11を主対象にする
- Python 3.8以上またはPython 3.10以上を想定する
- `pyserial` を使う
- `serial.tools.list_ports` でCOMポート一覧を表示する
- ROMバージョン確認、コマンドモード切替、UHF_Inventory、送信出力読み取り、周波数チャンネル読み取りの流れを参考にする
- 受信データ内部の STX / ETX / SUM / CR を確認する
- タイムアウトまたはACK/NACK受信で受信ループを抜ける

# 2. 作成するUSB版サンプルの目的

USB接続されたUTR-S201シリーズリーダライタに対して、以下を行うPythonサンプルを作成してください。

1. COMポート一覧表示
2. ユーザーによるCOMポート選択
3. シリアルポート接続
4. ROMバージョン確認
5. コマンドモード設定
6. UHF_Inventoryを指定回数実行
7. タグのPC+UII / EPC(UII)を表示
8. RSSIが取得できる場合は表示
9. ACK / NACK / タイムアウトを表示
10. 送信HEX / 受信HEXをログ保存
11. シリアルポート切断

# 3. 接続条件

以下を仮定してください。

- OS: Windows 10 / 11
- Python: 3.10以上
- ライブラリ: pyserial
- 接続方式: USBシリアル
- ボーレート: UTR-S201シリーズ仕様および既存サンプルを確認して設定する。判断できない場合は要確認と明記する
- データ長: 8bit
- パリティ: none
- ストップビット: 1
- フロー制御: なし

# 4. 必須の関数構成

以下の関数を作ってください。

- `calculate_sum_value(data: bytes) -> int`
- `verify_sum_value(frame: bytes) -> bool`
- `build_frame(command: int, data: bytes = b"", address: int = 0x00) -> bytes`
- `parse_frame(buffer: bytes) -> list[bytes]`
- `parse_nack_response(frame: bytes) -> str`
- `parse_inventory_response(response: bytes) -> ...`
- `list_serial_ports() -> list[...]`
- `open_serial_port(...) -> serial.Serial`
- `communicate(ser: serial.Serial, command: bytes, timeout: float) -> bytes`
- `main() -> None`

# 5. コマンド定義

既存USB CodeXサンプルのコマンド定義を参考にしてください。
最低限、以下を用意してください。

- ROM_VERSION_CHECK
- COMMAND_MODE_SET
- UHF_INVENTORY
- UHF_GET_INVENTORY_PARAM
- UHF_READ_OUTPUT_POWER
- UHF_READ_FREQ_CH

ただし、初期実機確認用では、RF出力設定変更や周波数設定変更などの書き込み系コマンドは実行しないでください。

# 6. 危険操作の禁止

初期版では以下を実装しないでください。

- FLASH書き込み
- FLASH初期化
- FLASH設定復元
- RF出力設定変更
- 周波数設定変更
- Kill
- Lock
- RFタグ書き込み系コマンド
- リスタート

# 7. 出力してほしいファイル

以下のファイルを、完全な内容で提示してください。

```text
UTR_USB_Python_sample_generated/
├─ src/
│  └─ utr_usb_sample_generated.py
├─ requirements.txt
├─ README.md
├─ .gitignore
└─ .vscode/
   └─ launch.json
```

# 8. READMEに必ず書くこと

READMEには以下を書いてください。

- 対象機種
- UTRX/TR3XMと混同しない注意
- 必要環境
- pyserialのインストール方法
- VS Codeでの実行方法
- COMポート確認方法
- 実機確認前にUTRRWManagerでTX/RXログを取得すること
- Python側の送信HEX/受信HEXとUTRRWManagerログを比較すること
- 初期版で禁止している危険操作

# 9. 回答スタイル

初心者でもそのまま作業できるように、日本語で、手順と完全なコードを省略せず出してください。
```
