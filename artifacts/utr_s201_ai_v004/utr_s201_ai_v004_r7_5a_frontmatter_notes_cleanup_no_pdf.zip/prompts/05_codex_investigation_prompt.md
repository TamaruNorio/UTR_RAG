---
title: "Codex調査のみ依頼プロンプト"
type: "prompt"
target: "codex"
mode: "investigation_only"
---

# Codex調査のみ依頼プロンプト

Codexに既存リポジトリを読ませるが、変更させない場合に使います。

```text
あなたは、GitHubリポジトリを調査するCodexエージェントです。

# 作業種別

調査のみです。
実装、修正、新規作成、削除、コミット、プッシュ、Pull Request作成は禁止です。

# 対象リポジトリ

ユーザーが指定した以下いずれかのリポジトリを対象にしてください。

- TamaruNorio/UTR_USB_Python_CodeX
- TamaruNorio/UTR_LAN_Python_CodeX

# 目的

UTR-S201シリーズ / R2000系 RFIDリーダライタ制御用Pythonサンプルについて、現状の構成、通信処理、安全面、テスト、READMEの不足点を調査してください。

# 正本と補助資料

- プロトコル仕様の正本はUTR-S201シリーズ通信プロトコル説明書PDFです。
- リポジトリ内MarkdownやAI補助資料はPDF参照補助資料です。
- PDF正本がリポジトリに無い場合、仕様断定は避け、「PDF正本確認が必要」と明記してください。

# 調査前に実行するコマンド

```powershell
git status --short
git branch --show-current
git log --oneline -5
```

# 調査観点

1. 対象シリーズがUTR-S201として明確か
2. UTRX/TR3XM/TR3X/UTR-S101の混同がないか
3. 接続、送信、受信、切断の流れが明確か
4. STX/ETX/SUM/CR検証があるか
5. ACK/NACK処理があるか
6. NACKエラーコード表示があるか
7. UHF_Inventoryの解析が妥当か
8. PC+UII/EPC(UII)、RSSIの扱いが妥当か
9. ログ保存があるか
10. 実機なしで確認できるテストがあるか
11. READMEに実行手順があるか
12. 危険操作が混入していないか
13. .gitignoreに実機ログ、.env、秘密情報が含まれているか

# 初期版で禁止すべき危険操作

以下が入っていないか確認してください。

- FLASHへの設定書き込み
- FLASH初期化
- 送信出力設定変更
- 周波数設定変更
- UHF_SetInventoryParam の自動送信
- RFタグ書き込み
- Kill
- Lock
- ThroughCmd
- リスタート
- 常時連続Inventory

# 出力形式

## 結論

## 調査対象ファイル

## 良い点

## 問題点

## 危険操作の混入確認

## PDF正本確認が必要な箇所

## 次に実装するなら優先すべき小タスク

## 実装依頼用プロンプト案

# 完了条件

- ファイルを変更していないこと
- `git status --short` が調査前から変化していないこと
```

## v004_i3 追加確認: ROMバージョンと将来ROM

調査時は、対象機種だけでなく、ROMシリーズ、ROMバージョン、ROMバージョンの取得元を確認してください。

未知ROMまたは将来ROMの場合、既知ROMの仕様を上位互換として適用しないでください。バージョン依存挙動は「PDF正本または更新資料で要確認」としてください。
