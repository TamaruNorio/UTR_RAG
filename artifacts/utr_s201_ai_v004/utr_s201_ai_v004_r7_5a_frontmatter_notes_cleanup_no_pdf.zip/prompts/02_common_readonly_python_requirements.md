
> F工程追記: 機種依存処理では、対象機種、ROMシリーズ名、アンテナ構成を確認してください。UTR-S201とUTR-S202を同一仕様と仮定しないでください。PDF正本で確認できない差分は要確認とし、送信可能コードを生成しないでください。

---
title: "UTR-S201 読み取り専用Python共通要件"
type: "prompt"
mode: "common_requirements"
target: "python sample generation"
operation_policy: "read_only_first"
---

# UTR-S201 読み取り専用Python共通要件

USB版、LAN版のどちらにも共通する要件です。
生成AIにPythonコードを作らせる前に、この内容を渡してください。

```text
あなたは、タカヤ製 UTR-S201シリーズ / R2000系 RFIDリーダライタ制御、Python、通信プロトコル解析に詳しいエンジニアです。

# 目的

初期実機確認用として、UTR-S201シリーズの読み取り専用Pythonサンプルを作成してください。

# 正本と補助資料

- 仕様の正本はUTR-S201シリーズ通信プロトコル説明書PDFです。
- Markdown、YAML、CSV、JSONはPDF参照補助資料です。
- 不明な仕様は推測せず、「PDF正本確認が必要」と明記してください。
- 送信HEXを固定値で書く場合は、PDF正本または既存実機ログと照合してください。

# 対象シリーズ

対象は UTR-S201シリーズ / R2000系です。
UTRX、TR3XM、TR3X、TR3、UTR-S101の仕様を混ぜないでください。

UTR-S201では、以下の用語を優先してください。

- UHF
- ISO/IEC18000-63
- EPCglobal Class1 Generation2
- EPC(UII)
- PC
- RSSI
- FLASH
- UHF_Inventory

TR3X/TR3XM系のHF、ISO15693、UID、Inventory2、EEPROM前提で実装しないでください。

# 初期版で許可する処理

初期版では、原則として以下のみ許可します。

1. 接続
2. ROMバージョン読み取り
3. コマンドモード設定
4. UHF_Inventory実行
5. UHF_GetInventoryParamなどの読み取り専用コマンド
6. 送信出力値の読み取り
7. 周波数設定の読み取り
8. 受信フレーム解析
9. NACK解析
10. ログ保存
11. 切断

# 初期版で禁止する処理

以下は実装しないでください。

- FLASHへの設定書き込み
- FLASH初期化
- FLASH設定復元
- 送信出力設定の変更
- 周波数設定の変更
- UHF_SetInventoryParam の自動送信
- インベントリパラメータの自動変更
- RFタグへの書き込み
- Kill
- Lock
- BlockErase
- Encode
- ThroughCmdによる任意コマンド実行
- 連続Inventoryの常時実行
- リスタート
- 安全ガードの削除または緩和

# 通信フレーム共通ルール

フレーム構造は次の前提です。

- STX: 0x02
- アドレス: 通常 0x00。ただし設定により変わる可能性あり
- コマンド
- データ長
- データ部
- ETX: 0x03
- SUM: STXからETXまでの合計値の下位1バイト
- CR: 0x0D

# 必須関数

以下の関数を作成してください。

- calculate_sum_value(data: bytes) -> int
- verify_sum_value(frame: bytes) -> bool
- build_frame(command: int, data: bytes = b"", address: int = 0x00) -> bytes
- extract_frames(buffer: bytes) -> list[bytes]
- parse_nack_response(frame: bytes) -> str
- parse_inventory_response(frames: list[bytes]) -> dict
- write_log(message: str) -> None
- main() -> None

# ログ要件

- 送信HEXを保存する
- 受信HEXを保存する
- タイムアウトを保存する
- NACKエラーコードを保存する
- SUM不一致を保存する
- 実機確認日時を保存する
- COMポート、IPアドレスなどは必要に応じてマスクできるようにする

# 出力してほしい成果物

1. 完全なPythonコード
2. requirements.txt
3. README.md
4. .gitignore
5. VS Code実行手順
6. PC上だけで確認できるテスト手順
7. 実機確認手順
8. よくあるエラーと対処
9. 危険操作が含まれていないことの自己チェック結果
```
