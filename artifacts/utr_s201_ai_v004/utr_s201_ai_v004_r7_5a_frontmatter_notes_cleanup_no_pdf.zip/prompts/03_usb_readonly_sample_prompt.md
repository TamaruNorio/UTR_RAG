---
title: "UTR-S201 USB読み取り専用Python生成プロンプト"
type: "prompt"
connection: "usb serial"
operation_policy: "read_only_first"
---

# UTR-S201 USB読み取り専用Python生成プロンプト

USBシリアル接続版の読み取り専用Pythonサンプルを生成させるためのプロンプトです。

```text
あなたは、タカヤ製 UTR-S201シリーズ / R2000系 RFIDリーダライタをUSBシリアル接続で制御するPythonサンプルを作るエンジニアです。

# 目的

Windows PCからUSBシリアル接続でUTR-S201シリーズを制御し、初期実機確認として読み取り専用の処理を行うPythonサンプルを作成してください。

# 正本と補助資料

- 仕様の正本はUTR-S201シリーズ通信プロトコル説明書PDFです。
- Markdown、YAML、CSV、JSONはPDF参照補助資料です。
- 不明な値、bit定義、byte位置、レスポンス仕様は推測しないでください。
- 必要な箇所は「PDF正本確認が必要」と明記してください。

# 対象シリーズ

対象は UTR-S201シリーズ / R2000系です。
UTRX、TR3XM、TR3X、TR3、UTR-S101の仕様を混ぜないでください。

# 接続条件

- OS: Windows 10 / 11
- Python: 3.10以上
- 接続方式: USBシリアル
- ライブラリ: pyserial
- COMポート: ユーザーが一覧から選択
- ボーレート: PDF正本または既存サンプルで確認。判断できない場合は要確認と明記
- データ長: 8bit
- パリティ: none
- ストップビット: 1
- フロー制御: なし

# 実装する処理

1. COMポート一覧を表示
2. ユーザーがCOMポートを選択
3. シリアルポートを開く
4. ROMバージョン読み取り
5. コマンドモード設定
6. UHF_Inventoryを指定回数実行
7. PC+UII / EPC(UII)を表示
8. RSSIが取得できる場合は表示
9. ACK/NACKを判定
10. NACKエラーコードを表示
11. タイムアウトを処理
12. 送信HEX/受信HEXをログ保存
13. シリアルポートを確実に閉じる

# 実装しない処理

以下は絶対に入れないでください。

- FLASHへの設定書き込み
- FLASH初期化
- 送信出力設定の変更
- 周波数設定の変更
- UHF_SetInventoryParam の自動送信
- RFタグ書き込み
- Kill
- Lock
- ThroughCmd
- リスタート
- 常時連続Inventory

# 必須ファイル

以下を完全な形で出してください。

- main.py
- requirements.txt
- README.md
- .gitignore

# main.py 必須構成

以下の関数を含めてください。

- list_serial_ports()
- select_serial_port()
- open_serial_port()
- calculate_sum_value()
- verify_sum_value()
- build_frame()
- receive_frames_from_serial()
- communicate()
- parse_nack_response()
- parse_inventory_response()
- run_inventory()
- main()

# PC上だけで確認できる内容

実機なしでも以下を確認できるようにしてください。

- SUM計算テスト
- フレーム組み立てテスト
- mock受信フレーム解析テスト
- NACK解析テスト

# 実機確認手順

READMEに以下を含めてください。

1. UTRRWManagerで対象COMポートを確認
2. UTRRWManagerでROMバージョン読み取りログを保存
3. Pythonで同じコマンドを実行
4. 送信HEXと受信HEXを比較
5. UHF_Inventoryを1回だけ実行
6. 複数回実行は1回実行で正常確認後に行う
7. NACKまたはタイムアウト時はログを保存して終了

# 出力形式

コードは断片ではなく、コピーして使える完全なファイルとして出してください。
初心者向けに日本語コメントを多めに入れてください。
```
