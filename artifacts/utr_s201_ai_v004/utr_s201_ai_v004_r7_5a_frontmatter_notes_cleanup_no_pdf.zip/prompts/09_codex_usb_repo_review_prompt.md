# Codex依頼用プロンプト: UTR USB版リポジトリ調査・レビュー

## 目的

GitHubリポジトリ `TamaruNorio/UTR_USB_Python_CodeX` のUSB版サンプルについて、変更せずに調査・レビューしてください。

## 重要

この依頼は **調査のみ** です。
ファイル変更、新規作成、削除、コミット、プッシュ、設定変更は行わないでください。

## 前提

- 対象リポジトリ: `TamaruNorio/UTR_USB_Python_CodeX`
- 対象ブランチ: 最新の作業ブランチまたはmain
- 対象: UTR-S201シリーズ USB版 Pythonサンプル
- PDF正本: UTR-S201シリーズ通信プロトコル説明書
- GitHub実装は仕様正本ではなく、実装例・実機確認済み挙動として扱う

## 確認してほしい観点

1. `src/utr_usb_sample.py` の標準入口が想定どおり動く構造か
2. `src/utr_usb_inventory_with_output_power.py` の送信出力一時変更と復元処理が安全か
3. 変更送信後、読み戻し例外が発生しても復元計画が保持されるか
4. `src/utr_8ch_sequential_inventory_cli.py` の8CH順次Inventoryで、Ctrl+Cや例外時も復元が試みられるか
5. 復元前の受信バッファクリア、ACK/NACKなし時の1回再試行が妥当か
6. FLASH書き込み、周波数変更、`UHF_SET_INVENTORY_PARAM` 自動送信が含まれていないか
7. UTR-S201 / UTR-S202 / UTR-SUN02-4CH / UTR-SUN02-8CH / UTR-SUN02V-8CH の差分を推測していないか
8. READMEと実装の説明が一致しているか
9. 実PC+UIIがログやコミット対象に残るリスクがないか
10. テストで確認できる範囲と、実機確認が必要な範囲が分かれているか

## 実行してよいコマンド

```powershell
git status --short
git diff --check
py -m pytest
powershell -ExecutionPolicy Bypass -File scripts/dev_check.ps1
```

環境により `py` が使えない場合は、`python -m pytest` を試してください。

## 報告フォーマット

以下の形式で報告してください。

```markdown
# 調査結果

## 結論

## 確認したファイル

## 良い点

## 懸念点

## 実機確認が必要な点

## テスト結果

## 変更提案

※この依頼では実装しないこと。
```

