# Codex依頼用プロンプト: UTR USB版リポジトリ小規模修正

## 目的

GitHubリポジトリ `TamaruNorio/UTR_USB_Python_CodeX` について、指定された1テーマだけを小さく修正してください。

## 作業前提

- mainブランチを直接変更しない
- 最新のmainから作業ブランチを作る
- 作業前に `git status --short` を確認する
- 1回の依頼で複数テーマを混ぜない
- PDF正本に根拠がない仕様変更は行わない
- 実機確認が必要な処理は、机上テストだけで完了扱いしない

## 今回の対象テーマ

```text
ここに今回修正したい1テーマを書く。
例:
- READMEの説明と現在の8CH自動復元実装の表現を合わせる
- 送信出力復元処理の例外時メッセージを明確にする
- テストを1件追加する
```

## 変更してよい範囲

```text
ここに対象ファイルを書く。
例:
- README.md
- docs/inventory_with_temporary_output_power_check.md
- src/utr_usb_inventory_with_output_power.py
- tests/test_output_power_restore_state.py
```

## 変更してはいけない範囲

以下は明示許可なしに変更しないでください。

- FLASH書き込み処理の追加
- 周波数設定変更処理の追加
- `UHF_SET_INVENTORY_PARAM` 自動送信処理の追加
- 送信出力変更対象機種の拡大
- UTR-SUN02-8CH / USM08 以外への8CH実送信対象拡大
- ROMシリーズ判定ロジックの変更
- 安全ガードの削除または緩和
- 実PC+UIIをログやREADMEへ記載すること
- mainブランチへの直接コミット

## 必須確認

作業後に以下を実行してください。

```powershell
git diff --check
py -m pytest
powershell -ExecutionPolicy Bypass -File scripts/dev_check.ps1
git status --short
git diff --stat
```

環境都合で実行できないものがある場合は、実行できなかった理由を明記してください。

## 完了条件

- 変更範囲が依頼テーマに限定されている
- READMEまたはdocsと実装の説明が矛盾しない
- 危険操作が追加されていない
- テストまたは机上確認結果が報告されている
- 実機確認が必要な点が分離されている

## 報告フォーマット

```markdown
# 作業報告

## 結論

## 変更したファイル

## 変更内容

## 変更していないこと

## テスト結果

## 実機確認が必要な点

## git diff --stat

## 次に確認してほしい点
```

