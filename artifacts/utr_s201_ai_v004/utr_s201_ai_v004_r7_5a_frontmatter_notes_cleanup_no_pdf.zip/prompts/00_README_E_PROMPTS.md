---
title: "UTR-S201 AIプロンプト集 v004"
project: "UTR-S201 AI補助パッケージ"
phase: "E"
status: "draft"
target_series: "UTR-S201 series / R2000"
source_of_truth: "PDF正本"
markdown_role: "AI参照補助資料"
---

# UTR-S201 AIプロンプト集 v004

## 目的

このフォルダは、生成AIに **UTR-S201シリーズ / R2000系 RFIDリーダライタ制御** に関する調査、Pythonサンプル作成、Codex作業、レビューを依頼するためのプロンプト集です。

v003までの反省を踏まえ、v004では以下を徹底します。

- PDF正本を最上位の根拠とする
- Markdown、YAML、CSV、JSONを「正本」扱いしない
- 調査、実装、レビューを分ける
- USB版、LAN版を分ける
- Codex向けは、調査のみ依頼と実装依頼を分ける
- 危険操作を初期サンプルに入れない

## 対象シリーズ

対象は **UTR-S201シリーズ / R2000系** です。

代表対象機種:

- UTR-S201
- UTR-SUN02-4CH
- UTR-SUN02V-8CH
- UTR-SUN02-8CH
- UTR-SHR201

## PDF正本と補助資料の扱い

本プロンプト集では、仕様の正本を **UTR-S201シリーズ通信プロトコル説明書PDF** とします。

Markdown、YAML、CSV、JSON、Skill、プロンプトは、PDF正本の参照を補助する二次資料です。
最終判断、危険操作、実機影響、電波条件、設定変更、書き込み処理については、必ずPDF正本と実機確認を前提にしてください。

生成AIへ依頼する際は、可能な限りPDF正本または該当ページのスクリーンショット、該当表を併せて渡してください。

## 使い分け

| ファイル | 用途 |
|---|---|
| `01_investigation_only_prompt.md` | 仕様調査のみ。コード変更・新規作成・実装を禁止する場合 |
| `02_common_readonly_python_requirements.md` | USB/LAN共通の読み取り専用Pythonサンプル要件 |
| `03_usb_readonly_sample_prompt.md` | USBシリアル接続の読み取り専用Pythonサンプル生成 |
| `04_lan_readonly_sample_prompt.md` | LAN/TCP接続の読み取り専用Pythonサンプル生成 |
| `05_codex_investigation_prompt.md` | Codexにリポジトリ調査のみ依頼する場合 |
| `06_codex_implementation_prompt.md` | Codexに小さな実装を依頼する場合 |
| `07_ai_output_review_checklist.md` | 生成AI出力コードのレビュー観点 |
| `08_high_risk_change_request_template.md` | 危険操作を扱う場合の事前確認テンプレート |
| `09_codex_usb_repo_review_prompt.md` | GitHub USB版リポジトリを変更せずに調査・レビューする依頼 |
| `10_codex_usb_repo_fix_prompt.md` | GitHub USB版リポジトリの小規模修正依頼 |

## 初期版で禁止する操作

初期実機確認用サンプルでは、以下を実装しないでください。

- FLASHへの設定書き込み
- FLASH初期化
- FLASH設定復元
- 送信出力設定の変更
- 周波数設定の変更
- `UHF_SetInventoryParam` の自動送信
- インベントリパラメータの自動変更
- RFタグへの書き込み
- Kill
- Lock
- BlockErase
- Encode
- ThroughCmdによる任意コマンド実行
- 連続Inventoryの常時実行
- リスタート
- ROMシリーズ判定ロジックの変更
- 安全ガードの削除または緩和

## 推奨する進め方

1. `01_investigation_only_prompt.md` でPDF正本と補助資料の差分を調査する
2. 読み取り専用の範囲を確定する
3. USBまたはLANのどちらか一方に絞る
4. `03` または `04` のプロンプトでサンプルを生成する
5. `07_ai_output_review_checklist.md` でレビューする
6. 実機確認は送信HEX、受信HEX、UTRRWManagerログを比較して行う

## レガシー資料

v003相当の旧プロンプトは `legacy_v003/` に移動しました。
旧プロンプトには「Markdownを正として扱う」表現や、CodeX/GitHub環境に寄った記述が残る可能性があります。v004では本フォルダ直下のプロンプトを優先してください。


## G工程で追加したGitHub USB版向けプロンプト

G工程では、GitHub USB版の最新状態をAIパッケージへ反映したため、Codex向けプロンプトも2つ追加しました。

- 調査のみ: `09_codex_usb_repo_review_prompt.md`
- 小規模修正: `10_codex_usb_repo_fix_prompt.md`

どちらも、PDF正本を最終根拠とし、GitHub実装を仕様正本として扱わない前提です。
