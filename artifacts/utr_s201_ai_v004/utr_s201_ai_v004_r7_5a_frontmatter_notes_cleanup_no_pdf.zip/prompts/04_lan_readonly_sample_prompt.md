---
title: "UTR-S201 LAN読み取り専用Python生成プロンプト"
type: "prompt"
connection: "tcp lan"
operation_policy: "read_only_first"
---

# UTR-S201 LAN読み取り専用Python生成プロンプト

LAN/TCP接続版の読み取り専用Pythonサンプルを生成させるためのプロンプトです。

```text
あなたは、タカヤ製 UTR-S201シリーズ / R2000系 RFIDリーダライタをLAN/TCP接続で制御するPythonサンプルを作るエンジニアです。

# 目的

Windows PCからLAN/TCP接続でUTR-S201シリーズを制御し、初期実機確認として読み取り専用の処理を行うPythonサンプルを作成してください。

# 正本と補助資料

- 仕様の正本はUTR-S201シリーズ通信プロトコル説明書PDFです。
- Markdown、YAML、CSV、JSONはPDF参照補助資料です。
- 不明な値、bit定義、byte位置、レスポンス仕様は推測しないでください。
- 必要な箇所は「PDF正本確認が必要」と明記してください。

# 対象シリーズ

対象は UTR-S201シリーズ / R2000系です。
UTRX、TR3XM、TR3X、TR3、UTR-S101の仕様を混ぜないでください。

# 接続条件

- OS: Windows 10 / 11
- Python: 3.10以上
- 接続方式: LAN / TCP
- 本プログラムはTCPクライアント
- リーダライタ側はTCPサーバー相当
- IPアドレスはコードに固定しない
- TCPポートは引数またはユーザー入力で指定
- 既定ポート例がある場合も、装置設定に依存するためUTRRWManagerで確認する

# 実装する処理

1. IPアドレスとTCPポートを入力またはコマンドライン引数で受け取る
2. TCP接続する
3. ROMバージョン読み取り
4. コマンドモード設定
5. UHF_Inventoryを指定回数実行
6. PC+UII / EPC(UII)を表示
7. RSSIが取得できる場合は表示
8. ACK/NACKを判定
9. NACKエラーコードを表示
10. タイムアウトを処理
11. 送信HEX/受信HEXをログ保存
12. TCPソケットを確実に閉じる

# 実装しない処理

以下は絶対に入れないでください。

- FLASHへの設定書き込み
- FLASH初期化
- 送信出力設定の変更
- 周波数設定の変更
- UHF_SetInventoryParam の自動送信
- RFタグ書き込み
- Kill
- Lock
- ThroughCmd
- リスタート
- 常時連続Inventory

# 必須ファイル

以下を完全な形で出してください。

- main.py
- README.md
- .gitignore
- mock_tcp_server.py

# main.py 必須構成

以下の関数またはクラスを含めてください。

- TcpSession
  - connect()
  - communicate()
  - receive_frames()
  - close()
- calculate_sum_value()
- verify_sum_value()
- build_frame()
- extract_frames()
- parse_nack_response()
- parse_inventory_response()
- run_inventory()
- main()

# PC上だけで確認できる内容

実機なしでも以下を確認できるようにしてください。

- SUM計算テスト
- フレーム組み立てテスト
- mock TCPサーバーとの送受信
- mock受信フレーム解析
- NACK解析

# 実機確認手順

READMEに以下を含めてください。

1. UTRRWManagerでIPアドレスとポートを確認
2. UTRRWManagerでROMバージョン読み取りログを保存
3. Pythonで同じコマンドを実行
4. 送信HEXと受信HEXを比較
5. UHF_Inventoryを1回だけ実行
6. 複数回実行は1回実行で正常確認後に行う
7. NACKまたはタイムアウト時はログを保存して終了

# 出力形式

コードは断片ではなく、コピーして使える完全なファイルとして出してください。
初心者向けに日本語コメントを多めに入れてください。
```
