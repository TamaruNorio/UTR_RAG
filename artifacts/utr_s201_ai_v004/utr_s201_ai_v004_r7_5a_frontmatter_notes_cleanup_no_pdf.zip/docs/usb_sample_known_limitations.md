---
title: "USB版サンプル 既知の制限と未確認項目"
project: "UTR-S201 AI補助パッケージ"
phase: "G"
status: "draft"
repo: "TamaruNorio/UTR_USB_Python_CodeX"
source_type: "verified_github_sample"
source_priority_rank: 3
---

# USB版サンプル 既知の制限と未確認項目

## 目的

このファイルは、GitHub USB版サンプルをAIが参照する際に、過剰に一般化しないための制限事項を整理するものです。

## 既知の制限

| 項目 | 制限 |
|---|---|
| 対象インターフェース | USB仮想COMポート前提。LAN接続処理とは分ける。 |
| 送信出力一時変更 | 現時点では UTR-SUN02-4CH / USM02 を対象。 |
| 8CH順次Inventory | 実送信CLIは UTR-SUN02-8CH / USM08 を対象。 |
| UTR-SUN02V-8CH | ROMシリーズ名と機種識別までは扱うが、UTR-SUN02-8CH用CLIの実送信対象ではない。 |
| FLASH | 書き込みしない。 |
| 周波数 | 変更しない。 |
| `UHF_SET_INVENTORY_PARAM` | 自動送信しない。 |
| 実タグID | GitHub、Issue、PR本文、公開ログへ載せない。 |

## 未確認または追加確認が望ましい項目

| 項目 | 確認理由 |
|---|---|
| Ctrl+C時の送信出力復元 | 復元計画保持は実装済みだが、全タイミングでの実機確認は別途必要。 |
| 送信出力復元後の読み戻し例外 | 復元処理は実装されているが、読み戻し失敗時の現場対応手順を明確化したい。 |
| UTR-SUN02V-8CH / USM06 | UTR-SUN02-8CH / USM08と同一扱いしない。 |
| UTR-S201 / UTR-S202の差分 | 同一仕様と仮定しない。PDF正本で対象機種差分を確認する。 |
| LAN版への展開 | USB版の通信フレームは参考になるが、接続・送受信・タイムアウト処理は別設計。 |

## AIへの禁止事項

GitHub実装を参照しても、AIは以下を行わないでください。

- 対象機種未指定でアンテナ制御コードを生成する
- UTR-S201とUTR-S202を同一仕様として扱う
- USM02、USM06、USM08の差分を推測で補完する
- UTR-SUN02-8CH / USM08 のアンテナ番号体系を他機種へ流用する
- FLASH、周波数、InventoryParam、送信出力変更を無断で実装する
- GitHub実装をPDF正本より上位の根拠として扱う

