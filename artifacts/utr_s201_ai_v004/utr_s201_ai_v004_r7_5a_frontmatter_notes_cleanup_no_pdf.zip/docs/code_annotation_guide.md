# Code Annotation Guide

作成日: 2026-06-29
工程: R4
対象: RFID制御アプリ実装者 / コードレビュアー / Codex作業指示

---

## 1. このガイドの目的

RFID制御サンプルでは、コードだけを見ても、どの通信プロトコル仕様書のどの内容に基づく実装なのか分かりにくくなる。

そのため、プロトコル定数、フレーム生成関数、レスポンス解析関数、高リスク操作には、標準コメントを付ける。

目的は次の3つである。

1. 仕様根拠を追えるようにする
2. 対象機種・ROM・I/F・アンテナ構成を明示する
3. 高リスク操作や実機確認が必要な処理をレビューで見落とさない

---

## 2. 標準コメントタグ

| タグ | 意味 |
|---|---|
| `@AI_SOURCE` | 参照した通信プロトコル仕様書の情報 |
| `@AI_SCOPE` | この処理が想定している対象機器・接続条件 |
| `@AI_RISK` | この処理のリスクと自動送信可否 |
| `@AI_FRAME` | コマンドフレームの構成情報 |
| `@AI_REVIEW` | レビュー時に確認する項目 |
| `@AI_TEST` | 机上確認・実機確認の項目 |
| `@AI_LIMITATION` | 未確認事項や適用外条件 |

---

## 3. 最小構成

読み取り系の低リスク処理では、最低限以下を入れる。

```python
# @AI_SOURCE:
#   document: UTR-S201/202 series communication protocol specification
#   manual_no: 要確認
#   version: 要確認
#   section: UHF_Inventory
#   page: 要PDF照合
#   status: not_cross_checked
#
# @AI_SCOPE:
#   product_family: UTR
#   model_name: 要指定
#   rom_version: 要指定
#   interface: USB_or_LAN_or_SERIAL
#   antenna_profile: 要指定
#   operation_type: read_only
#
# @AI_RISK:
#   risk_level: low
#   automatic_send_allowed: conditional
#   executable_hex_output: prohibited
#
# @AI_REVIEW:
#   reviewer_should_check:
#     - コマンドコードが正本と一致しているか
#     - ACK/NACK解析があるか
#     - タイムアウト処理があるか
```

---

## 4. 関数docstring例

```python
def build_uhf_inventory_command() -> bytes:
    """UHF_Inventoryコマンドフレームを生成する。

    実装観点:
        RFタグ探索を要求する読み取り系コマンドを生成する。
        実機送信する場合は、対象機種、ROM、I/F、アンテナ構成、
        レスポンスタイムアウトを確認する。

    @AI_SOURCE:
        document: UTR-S201/202 series communication protocol specification
        manual_no: 要確認
        version: 要確認
        section: UHF_Inventory
        page: 要PDF照合
        status: not_cross_checked

    @AI_FRAME:
        command_code: 0x55
        detail_command: 0x10
        checksum_policy: build_frame_only

    @AI_REVIEW:
        - SUMを固定値で直書きしていないこと
        - ACK/NACKとタグデータレスポンスを分けて解析すること
        - PC+UIIを公開ログへそのまま出さないこと
    """
    return build_frame(command_code=0x55, data=bytes([0x10]))
```

---

## 5. 高リスク処理のコメント例

```python
# @AI_SOURCE:
#   document: UTR-S201/202 series communication protocol specification
#   manual_no: 要確認
#   version: 要確認
#   section: Write frequency
#   page: 要PDF照合
#   status: not_cross_checked
#   source_traceability_ref: source_traceability_matrix.yml#trace_items.WRITE_FREQUENCY
#
# @AI_RISK:
#   risk_level: critical
#   code_generation: prohibited_by_default
#   automatic_send_allowed: false
#   executable_hex_output: prohibited
#   explicit_permission_required: true
#
# @AI_REVIEW:
#   reviewer_should_check:
#     - 対象機種とROMバージョンが固定されているか
#     - 周波数/チャンネル/bit対応表を構造化データで確認したか
#     - 電波条件・地域条件に影響しないか
#     - 復元手順があるか
#     - 実機確認前に責任者承認があるか
```

高リスク処理は、コメントを付けたから実装してよい、という意味ではない。コメントは、レビュー時に停止条件を見落とさないためのもの。

---

## 6. ページ番号が未照合の場合

ページ番号が未照合の場合は、推測せずに以下のように書く。

```yaml
page: 要PDF照合
status: not_cross_checked
```

禁止例:

```yaml
page: 123  # AIが推測したページ番号
status: pdf_cross_checked
```

`pdf_cross_checked` は、人間または検証スクリプトでPDF正本と照合した場合のみ使う。

---

## 7. レビューで見るポイント

コードレビューでは、以下を見る。

```text
1. @AI_SOURCE があるか
2. 正本文書名・section・page・status があるか
3. @AI_SCOPE に model_name / rom_version / interface / antenna_profile があるか
4. @AI_RISK が command_safety_matrix と一致しているか
5. high/critical処理で automatic_send_allowed: false になっているか
6. SUM込み完成Hexが直書きされていないか
7. 実機確認が必要な処理を机上確認だけで完了扱いにしていないか
8. UTR/TR3X/LTRなど別シリーズの仕様が混ざっていないか
```

---

## 8. Codexへ依頼するときの追加文

Codexへコード修正を依頼する場合、プロンプトに以下を追加する。

```text
プロトコル定数、フレーム生成関数、レスポンス解析関数を追加・変更する場合は、
該当箇所に @AI_SOURCE / @AI_SCOPE / @AI_RISK / @AI_REVIEW を付けてください。

@AI_SOURCE には、通信プロトコル仕様書の document / manual_no / version / section / page / status を記載してください。
ページ未照合の場合は page: 要PDF照合、status: not_cross_checked としてください。

SUM込みの完成Hexフレームを直書きしないでください。
SUMは build_frame() などの検証済み関数で計算し、説明例では [MUST_RECALCULATE_SUM] を使ってください。

実機送信が必要な処理は、PC上テストだけで完了扱いにしないでください。
```

---

## 9. 今後の展開

R7以降で既存v004本体へ反映する際は、以下の順で行う。

1. `source_traceability_matrix.yml` に正本PDFのsection/pageを登録
2. `command_safety_matrix.yml` と照合
3. 代表サンプルコードに `@AI_SOURCE` コメントを追加
4. Codex依頼プロンプトへコメント必須条件を追加
5. レビューで `@AI_SOURCE.status` が `not_cross_checked` のまま残っていないか確認
