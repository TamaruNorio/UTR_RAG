---
title: "USB版サンプル 実機確認済み挙動"
project: "UTR-S201 AI補助パッケージ"
phase: "G"
status: "draft"
repo: "TamaruNorio/UTR_USB_Python_CodeX"
source_type: "verified_github_sample"
source_priority_rank: 3
---

# USB版サンプル 実機確認済み挙動

## 目的

このファイルは、GitHub USB版サンプルで実機確認済みとして記録されている挙動を、AIが参照しやすい形に整理したものです。

これはPDF正本の代替ではありません。
実機確認済みの実装例として扱います。

## 実機確認済みとして扱う項目

| 分類 | 内容 | 対象 |
|---|---|---|
| 基本通信 | `ROM_VERSION_CHECK` のACK受信 | USB実機 |
| モード切替 | `COMMAND_MODE_SET` | USB実機 |
| Inventoryパラメータ読み取り | `UHF_GET_INVENTORY_PARAM` | USB実機 |
| Inventory | `UHF_INVENTORY` | USB実機 |
| ブザー制御 | ブザー応答確認 | USB実機 |
| 送信出力一時変更 | 24.0 dBm → 12.0 dBm → 24.0 dBm | UTR-SUN02-4CH / USM02 |
| 送信出力復元 | Inventory後に元値へ復元し、復元後に読み戻し | UTR-SUN02-4CH / USM02 |
| 8CH順次Inventory | ANT1 → ANT3 の順次Inventory | UTR-SUN02-8CH / USM08 |
| 8CH自動復元 | 開始前に読み取った使用アンテナ番号へ自動復元 | UTR-SUN02-8CH / USM08 |
| 8CH残留応答対策 | 復元前に受信バッファをクリアし、ACK/NACKなし時は1回再試行 | UTR-SUN02-8CH / USM08 |
| テスト | `pytest 234 passed` とREADMEに記録 | GitHub実装 |

## 重要な制約

実機確認済みであっても、以下は一般化してはいけません。

- UTR-SUN02-4CH / USM02 の挙動を UTR-S201 / UTR-S202 へ流用すること
- UTR-SUN02-8CH / USM08 のアンテナ番号体系を UTR-SUN02V-8CH / USM06 へ流用すること
- USB版実装をLAN版接続処理へそのまま流用すること
- GitHub実装がPDF正本と一致していると無条件に仮定すること

## AIが回答時に使う表現

推奨表現:

```text
GitHub USB版サンプルでは、UTR-SUN02-8CH / USM08 を対象に、開始前に読み取った使用アンテナ番号へ終了時に自動復元する実装例があります。ただし、仕様の最終確認はPDF正本で行ってください。
```

禁止表現:

```text
UTR-S201シリーズでは必ずこのアンテナ復元方式を使います。
```

理由:

- 対象機種、ROMシリーズ、アンテナ構成が限定されているため。
- GitHubは実装例であり、仕様正本ではないため。

