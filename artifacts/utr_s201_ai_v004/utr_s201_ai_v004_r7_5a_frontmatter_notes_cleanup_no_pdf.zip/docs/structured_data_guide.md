# structured_data_guide

## 1. Goal

This guide explains how to use the R5 structured-data files when preparing UTR-S201/202 AI support materials.

The goal is to keep protocol table meaning machine-readable. Markdown prose alone is not enough for bit fields, frequency tables, antenna mappings, ROM differences, model differences, Q-value conditions, or persistence behavior.

## 2. Where structured data is required

Create or update a structured matrix when the source contains:

- bit fields
- channel-to-frequency mappings
- enabled/disabled channel tables
- antenna number mappings
- command frame layouts
- response frame layouts
- ROM-version differences
- model/hardware differences
- RAM/FLASH persistence behavior
- Q-value and multi-tag conditions
- SUM/checksum positions

## 3. How to mark unverified values

Use `requires_pdf_cross_check` for any value not yet checked against the source PDF.

Do not leave blanks. A blank field can be misread as omission. A placeholder is explicit.

## 4. How AI should use these files

AI may use structured data to:

- explain command fields
- list implementation checks
- generate review checklists
- identify high-risk operations
- detect missing target device information
- detect missing ROM-version information
- detect missing tag-environment information

AI must not use scaffold structured data to:

- generate executable Hex frames
- choose frequencies
- change output power
- write FLASH
- infer unknown ROM behavior
- assume antenna numbering across models

## 5. Reviewer checklist

Before promoting structured data from scaffold to verified state, confirm:

- source PDF document title
- manual number
- PDF version or issue date
- section name
- page range
- table title
- bit numbering order
- byte offset origin
- merged cell handling
- footnote handling
- model/ROM applicability
- safety classification

## 6. Relation to R3 and R4

R3 defines command safety.
R4 defines source traceability.
R5 defines table structure.

A release-ready command chunk should reference all three:

```yaml
command_ref: UHF_INVENTORY
safety_profile_ref: 03_structured_data/command_safety_matrix.yml#commands.UHF_INVENTORY
source_traceability_ref: 03_structured_data/source_traceability_matrix.yml#UHF_INVENTORY
structured_data_refs:
  - 03_structured_data/q_value_collision_matrix.yml
```
