# R5_STRUCTURED_DATA_DESIGN_REPORT

Created: 2026-06-29
Phase: R5
Target: UTR-S201/202 AI support package v004 redesign
Status: design-only / not merged into v004_i3 package

---

## 1. Purpose

R5 defines how protocol tables, bit fields, channel mappings, model differences, ROM-version differences, and persistence behaviors should be represented as structured data instead of PDF-extracted Markdown text blocks.

The purpose is to prevent AI systems from reconstructing two-dimensional protocol tables by guesswork. R5 does not claim that every value is already verified. Unknown or not-yet-checked values remain explicitly marked as `requires_pdf_cross_check`.

---

## 2. Problems addressed by R5

R5 addresses these design problems:

1. PDF tables pasted into Markdown code blocks lose merged-cell relationships and two-dimensional meaning.
2. Bit-to-channel, bit-to-frequency, and bit-to-permission mappings are easy for AI to misread from plain text.
3. RAG chunks need machine-readable control data, not only prose.
4. Safety rules such as output power, frequency, antenna, ROM version, Q value, and FLASH/RAM behavior must be represented in a way that can be checked.
5. Structured data must link back to the source-traceability matrix created in R4.

---

## 3. Files created in R5

| File | Role |
|---|---|
| `03_structured_data/structured_data_design_policy.yml` | Top-level policy for structured data in this package |
| `03_structured_data/structured_data_schema_index.yml` | Index of R5 schemas and matrices |
| `03_structured_data/bitfield_matrix_schema.yml` | Common schema for bit-field tables |
| `03_structured_data/frequency_channel_matrix_schema.yml` | Common schema for frequency/channel mapping tables |
| `03_structured_data/antenna_number_matrix_schema.yml` | Common schema for antenna-number mapping tables |
| `03_structured_data/rom_version_behavior_matrix_schema.yml` | Common schema for ROM-version behavior differences |
| `03_structured_data/hardware_capability_matrix_schema.yml` | Common schema for hardware/model capability differences |
| `03_structured_data/parameter_persistence_matrix_schema.yml` | Common schema for RAM/FLASH/persistence behavior |
| `03_structured_data/checksum_frame_schema.yml` | Common schema for frame layout and SUM placeholder handling |
| `03_structured_data/q_value_collision_matrix_schema.yml` | Common schema for Q value and multi-tag conditions |
| `03_structured_data/frequency_channel_matrix.yml` | Design scaffold for frequency setting structure |
| `03_structured_data/inventory_param_bitfield_matrix.yml` | Design scaffold for inventory parameter bit fields |
| `03_structured_data/antenna_number_matrix.yml` | Design scaffold for usage/check antenna numbering |
| `03_structured_data/rom_version_behavior_matrix.yml` | Design scaffold for ROM-version behavior matrix |
| `03_structured_data/hardware_capability_matrix.yml` | Design scaffold for model/hardware capability matrix |
| `03_structured_data/parameter_persistence_matrix.yml` | Design scaffold for RAM/FLASH/persistence classification |
| `03_structured_data/q_value_collision_matrix.yml` | Design scaffold for Q-value and multi-tag read/write checks |
| `03_structured_data/source_structuring_priority_matrix.csv` | Prioritized list of protocol areas that must be structured first |
| `rules/15_structured_data_policy.md` | Rule for using structured data instead of Markdown-only tables |
| `rules/16_pdf_table_conversion_policy.md` | Rule for converting PDF tables into structured data |
| `docs/structured_data_guide.md` | Implementation and review guide for structured data |

---

## 4. Design rule

R5 uses this rule:

```text
PDF is the source of truth.
Structured data is the machine-readable control plane.
Markdown is explanatory prose.
AI must not reconstruct lost table structure from Markdown prose alone.
```

If a command table contains bit-level or multi-axis information, the table must have a corresponding structured-data entry before it is treated as AI-ready.

---

## 5. Source status values

R5 uses the following source-status values:

| Value | Meaning |
|---|---|
| `pdf_cross_checked` | Checked against the source PDF page/section |
| `requires_pdf_cross_check` | Scaffold exists, but value is not yet verified against the PDF |
| `conflict_detected_requires_pdf_confirmation` | Conflicting values exist and must be resolved against the PDF |
| `not_applicable` | Field does not apply to this item |

R5 artifacts intentionally use `requires_pdf_cross_check` in many places. This prevents AI from treating scaffolding as verified facts.

---

## 6. How R5 connects to previous phases

- R1 defines the redesign requirements.
- R2 defines response modes and output controls.
- R3 defines the command safety matrix.
- R4 defines source traceability and code annotations.
- R5 defines structured data schemas and scaffolds.

R5 does not replace R3 or R4. R5 data must reference:

- `command_safety_matrix.yml` for risk and output controls
- `source_traceability_matrix.yml` for PDF traceability
- `response_mode_transition.yml` for allowed AI behavior

---

## 7. Completion criteria for R5

R5 is complete when:

- Bit-field data has a standard schema.
- Frequency/channel mapping has a standard schema.
- Antenna numbering has a standard schema.
- ROM-version behavior has a standard schema.
- Hardware/model capability differences have a standard schema.
- Parameter persistence behavior has a standard schema.
- SUM/checksum handling uses placeholder rules.
- Q-value and multi-tag checks are machine-readable.
- All unverified values are marked as requiring PDF cross-check.

---

## 8. What R5 does not do yet

R5 does not perform full PDF cross-checking.
R5 does not update the existing v004_i3 package.
R5 does not modify Skill ZIP.
R5 does not update `VALIDATION.md`.
R5 does not resolve the UHF_Read 55_14/55_15 conflict.

These are handled in later phases.
