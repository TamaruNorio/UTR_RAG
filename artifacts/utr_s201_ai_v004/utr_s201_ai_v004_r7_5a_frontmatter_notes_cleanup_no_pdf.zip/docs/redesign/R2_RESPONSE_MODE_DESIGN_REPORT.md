# UTR-S201 AI補助パッケージ v004 R2 応答モード制御設計レポート

作成日: 2026-06-29  
対象: v004 i3 pre-RC以降の再設計  
前提: R1再設計要件定義書を上位要件とする

---

## 1. R2の目的

R2工程では、AIに単なる禁止リストを読ませるのではなく、ユーザーの依頼内容に応じて回答モードを切り替える制御設計を作成した。

目的は以下である。

- 対象機器情報が未固定でも、実装観点の説明や仕様参照補助は止めない
- 実装、コード生成、機種依存処理に入る前に対象機器情報を固定する
- 高リスク操作では自由回答を避け、固定テンプレートへ落とす
- SUMや完成Hexはプレースホルダーで扱う
- PDF正本の参照を「PDFを読め」で終わらせず、実装観点の説明へ変換する

---

## 2. 作成ファイル

```text
00_policy/ai_response_modes.yml
00_policy/high_risk_response_templates.yml
03_structured_data/response_mode_transition.yml
rules/00_response_mode_control.md
R2_RESPONSE_MODE_DESIGN_REPORT.md
```

---

## 3. 応答モードの概要

R2では、以下の9モードを定義した。

| mode | 目的 | コード生成 | 完成Hex | 対象機器固定 |
|---|---|---:|---:|---|
| implementation_context_explanation | 実装観点の概要説明 | 不可 | 不可 | 不要 |
| source_grounded_spec_explanation | 正本参照付き仕様説明 | 不可 | 不可 | 原則不要 |
| target_device_scoping | 対象機器情報の固定 | 不可 | 不可 | 固定作業 |
| safe_readonly_planning | 読み取り系・低リスク実装計画 | 不可 | 不可 | 条件付き必要 |
| low_risk_code_generation | 低リスクコード生成 | 可 | 不可 | 必須 |
| implementation_review | 実装レビュー | 原則不可 | 不可 | 内容による |
| high_risk_safety_output | 高リスク安全出力 | 不可 | 不可 | 評価には必要 |
| absolute_refusal_safety_output | 絶対拒絶・固定警告出力 | 不可 | 不可 | 不要 |
| checksum_placeholder_output | SUM・Hexプレースホルダー出力 | 不可 | 不可 | 内容による |

---

## 4. R1要件への対応

### 4.1 「PDFを読め」で終わらせない

`source_grounded_spec_explanation` では、正本の document / section / page / source_status を示しつつ、実装観点での説明を必須にした。

### 4.2 デッドロック回避

対象機器情報が未固定でも、`implementation_context_explanation` と `source_grounded_spec_explanation` は使用できる。  
実装、コード生成、機種依存処理に進む時だけ `target_device_scoping` へ遷移する。

### 4.3 高リスク時の自由回答抑制

`high_risk_safety_output` と `absolute_refusal_safety_output` を分けた。

- high risk: 説明、確認手順、レビュー観点は可能
- absolute refusal: 実装コード、完成Hex、Codex実装依頼文を固定的に拒絶

### 4.4 SUM・完成Hexのハルシネーション防止

`checksum_placeholder_output` を定義し、SUM位置には `[MUST_RECALCULATE_SUM]` を使う方針とした。

### 4.5 コードコメント根拠

`low_risk_code_generation` では、必要に応じて以下のアノテーションを要求する。

```text
@AI_SOURCE
@AI_SCOPE
@AI_REVIEW
```

---

## 5. モード選択順

`response_mode_transition.yml` では、以下の優先順位を定義した。

1. 絶対拒絶対象
2. 完成Hex / SUM計算済みフレーム要求
3. high / critical リスク操作
4. 対象機器情報不足
5. low risk コード生成
6. 実装レビュー
7. 実装計画
8. 正本参照付き仕様説明
9. 実装観点の概要説明

上位条件に該当する場合、下位モードには進まない。

---

## 6. 重要な設計判断

### 6.1 「説明は可、実装は不可」をモードで分離

従来は、高リスクや対象機器未固定時に全面停止しがちだった。  
R2では、説明、仕様確認、レビュー観点、実装計画、コード生成を分けた。

これにより、現場で使う際に「何も答えないAI」にはしない。

### 6.2 実装コードより先に対象機器固定

対象機種、ROMシリーズ、ROMバージョン、インターフェース、ハードウェア種別、アンテナ構成が不明な場合、機種依存実装には進めない。

ただし、説明は止めない。

### 6.3 高リスク操作はテンプレート化

高リスク時は自由文を避け、`high_risk_response_templates.yml` に定義したテンプレートを使う。

### 6.4 Hexはプレースホルダー化

フレーム構造説明は可能だが、AIがSUM値を計算して完成フレームとして提示することは禁止する。

---

## 7. 次工程 R3 で行うこと

R3工程では、以下を作成する。

```text
03_structured_data/command_safety_matrix.yml
rules/01_command_safety_matrix_usage.md
```

R3の目的は、各コマンドの `risk_level`、許可される応答モード、コード生成可否、Hex出力可否を1つの正規マトリクスで管理することである。

これにより、大ファイルと `rag/commands/` の `risk_level` 不整合を再発させない。

---

## 8. R2時点の制限

R2は応答モード設計であり、以下はまだ実施していない。

- 既存RAGファイルのfront matter修正
- `command_safety_matrix.yml` の作成
- `VALIDATION.md` の再生成
- Skill本体への反映
- ZIP再パッケージ
- PDF正本とのページ単位照合

これらはR3以降で段階的に進める。
