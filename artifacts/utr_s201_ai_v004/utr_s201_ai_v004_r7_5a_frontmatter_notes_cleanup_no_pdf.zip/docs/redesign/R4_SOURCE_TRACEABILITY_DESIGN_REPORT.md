# R4_SOURCE_TRACEABILITY_DESIGN_REPORT

作成日: 2026-06-29
工程: R4
対象: UTR-S201/202 系AI補助パッケージ v004 再設計
状態: design-only / not merged into v004_i3 package

---

## 1. R4の目的

R4では、通信プロトコル仕様書を正本としつつ、AIが「PDFを読んでください」で終わらせず、実装者が確認すべき内容を正本根拠つきで説明できるようにする。

R4の中心は、以下の3点である。

1. 仕様説明、RAGチャンク、構造化データ、コードコメントを正本参照で結び付ける
2. 「どの説明・処理が、通信プロトコル仕様書のどの節・ページを根拠にしているか」を追えるようにする
3. コードレビュー時に、レビュアーが仕様根拠・対象範囲・リスク・確認項目を確認できるコメント形式を標準化する

---

## 2. R4で作成したファイル

| ファイル | 役割 |
|---|---|
| `03_structured_data/source_traceability_matrix.yml` | 正本PDF、RAGチャンク、構造化データ、コード根拠コメントの対応表 |
| `03_structured_data/code_annotation_schema.yml` | `@AI_SOURCE` などのコードコメント用スキーマ |
| `rules/13_source_traceability_policy.md` | AIが正本参照つきで説明するためのルール |
| `rules/14_code_source_annotation_policy.md` | サンプルコードに仕様根拠コメントを入れるためのルール |
| `docs/code_annotation_guide.md` | 実装者・レビュアー向けのコードコメント運用ガイド |

---

## 3. R4の設計方針

### 3.1 PDF正本は根拠として扱う

通信プロトコル仕様書は正本であり、RAG/Skill/Markdown/構造化データ/サンプルコードは補助資料である。

ただし、AIは「正本を読め」で終わらせない。AIは、正本の該当箇所に基づき、実装観点で以下を整理して回答する。

- コマンドの目的
- 送信データ部の意味
- レスポンスで見るべき項目
- ACK/NACKやタイムアウトの扱い
- 機種差分・ROM差分・アンテナ構成差分
- 高リスク操作かどうか
- 実装可否とレビュー観点
- 正本の参照先

### 3.2 ページ番号を推測しない

PDF正本の該当ページが未照合の場合、AIはページ番号を推測しない。

未照合箇所は次のように扱う。

```yaml
source_status: not_cross_checked
page_start: 要PDF照合
page_end: 要PDF照合
```

R4時点では、設計のために主要コマンドのトレース項目を用意するが、ページ番号・節番号の完全な確定はR7以降のPDF逐条照合工程で行う。

### 3.3 full-source版とno-PDF版を分けられる設計にする

社内検証・RAG登録ではPDF正本を含めたfull-source版を想定する。
一方、軽量配布・レビュー用にはno-PDF版も作れるようにする。

いずれの場合も、`source_traceability_matrix.yml` により、各RAGチャンクやコードコメントがどの正本資料に由来するかを追える設計にする。

---

## 4. コード根拠アノテーション

R4では、サンプルコードに以下のコメントタグを使う設計にした。

| タグ | 目的 |
|---|---|
| `@AI_SOURCE` | 正本資料の文書名・マニュアル番号・節・ページ・照合状態 |
| `@AI_SCOPE` | 対象シリーズ・機種・ROM・I/F・アンテナ構成 |
| `@AI_RISK` | リスクレベル・自動送信可否・明示許可要否 |
| `@AI_FRAME` | コマンドコード、detail、subcommand、SUM扱い |
| `@AI_REVIEW` | レビュアーが確認すべき観点 |
| `@AI_TEST` | 机上確認・実機確認の項目 |
| `@AI_LIMITATION` | 未照合・未確認・適用外の制限事項 |

例:

```python
# @AI_SOURCE:
#   document: UTR-S201/202 series communication protocol specification
#   manual_no: 要確認
#   section: UHF_Inventory
#   page: 要PDF照合
#   status: not_cross_checked
#
# @AI_SCOPE:
#   product_family: UTR
#   model_name: 要指定
#   interface: USB_or_LAN_or_SERIAL
#   operation_type: read_only
#
# @AI_RISK:
#   risk_level: low
#   automatic_send_allowed: conditional
#   executable_hex_output: prohibited
#
# @AI_REVIEW:
#   reviewer_should_check:
#     - command_code
#     - data_length
#     - response_parser
#     - ack_nack_handling
#     - timeout_handling
```

---

## 5. R4の完成条件

R4は、以下を満たした時点で完了とする。

- 正本PDFと補助資料の対応を管理する `source_traceability_matrix.yml` がある
- コードコメント用の標準タグと必須項目が定義されている
- AIがページ番号を推測しないルールがある
- AIが「PDFを読め」で終わらず、正本根拠つきで実装観点を説明するルールがある
- 高リスク操作では正本参照、実装不可範囲、レビュー観点が出る
- 実装者・レビュアーがコード内コメントから仕様根拠を追える

---

## 6. R4でまだ行わないこと

R4は設計工程であり、以下はまだ実施しない。

- v004_i3本体の全ファイル修正
- PDF全ページの逐条照合
- UHF_Readの55_14/55_15齟齬確定
- Skill ZIPの更新
- VALIDATION.mdの上書き
- pre-RC再パッケージ

これらはR7以降で行う。

---

## 7. 次工程

次はR5工程に進む。

```text
R5: 構造化データ設計
```

R5では、周波数設定、bit定義、アンテナ番号、ROMバージョン差分、機種差分など、Markdown本文では誤読しやすい表形式情報をYAML/CSVで構造化する。
