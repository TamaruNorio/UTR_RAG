# R3 Command Safety Matrix Design Report

## Purpose

R3 creates the canonical command-level safety matrix for the UTR-S201 AI assistance package redesign.
The goal is to stop the recurring failure pattern where large PDF-derived Markdown files and `rag/commands/` files define conflicting `risk_level` or code-generation policies.

## Why this is needed

The latest Claude review identified repeated inconsistency issues:

- output power and frequency write commands became `critical` in large files but remained `high` in `rag/commands/`;
- `UHF_Read` had a risk mismatch and a `55_15` vs `55_14` file-name/code conflict;
- `UHF_Write` and `UHF_BlockWrite` remained weaker in large files than in command chunks;
- `VALIDATION.md` was stale;
- new i3 safety chunks were not registered in the RAG index.

R3 addresses the root cause by defining one canonical matrix and making RAG files reference it.

## Files created

```text
03_structured_data/command_safety_matrix.yml
03_structured_data/command_safety_matrix_schema.yml
03_structured_data/command_safety_matrix_traceability.csv
rules/01_command_safety_matrix_usage.md
```

## Design decisions

### 1. Safety profile references instead of duplicated risk fields

RAG command chunks should refer to:

```yaml
safety_profile_ref: "03_structured_data/command_safety_matrix.yml#commands.UHF_READ"
```

If `risk_level` is repeated in front matter for human readability, it must be generated from the matrix.

### 2. Executable Hex is blocked by default

Even low-risk commands should not have AI-generated completed Hex frames.
SUM values should be handled through the R2 checksum placeholder policy or verified frame-building code.

### 3. Conflicts become explicit states

For unresolved command-code conflicts, the matrix uses:

```yaml
command_code_status: conflict_detected_requires_pdf_confirmation
```

This allows explanation and review, but blocks executable implementation until the PDF is checked.

### 4. Critical commands route to fixed safety output

Critical commands prohibit implementation code, completed Hex frames, checksum-completed frames, automatic-send scripts, and Codex implementation prompts.

### 5. Validation must be matrix-aware

Future validation must verify consistency between:

- `command_safety_matrix.yml`;
- `rag/commands/*.md`;
- large PDF-derived command files;
- Skill safety gate;
- `rag_chunk_index.yml`;
- `VALIDATION.md`.

## Scope limitation

R3 is a design artifact, not a full package patch. It does not yet rewrite all existing RAG files.
The next step is R4/R5, where source traceability and RAG chunk structure can be aligned to this matrix.

## Next step

Proceed to R4: Source traceability and code annotation design.
