# UTR-S201 AI補助パッケージ v004 R1 再設計要件定義書

作成日: 2026-06-28  
対象: UTR-S201 AI補助パッケージ v004 i3 pre-RC 以降の再設計  
位置づけ: R工程の起点。以降のファイル修正・再パッケージ・レビュー依頼は、本書を上位要件として扱う。

---

## 1. R1の目的

本書は、v004 i3 pre-RC に対する中井さん、Gemini、Claude の指摘を踏まえ、AI補助パッケージの設計を再整理するための要件定義書である。

本パッケージの目的は、通信プロトコル仕様書を正本とし、RFID制御アプリ実装者が、生成AIを介して以下を確認しやすくすることである。

- コマンド仕様
- レスポンス仕様
- 機種差分
- ROMバージョン差分
- アンテナ構成差分
- 高リスク操作
- 実装時の注意点
- 実機確認観点
- コードレビュー観点

本パッケージは、通信プロトコル仕様書を置き換えない。  
ただし、AIが「PDFを読んでください」で終わる設計にもしてはならない。

AIは、通信プロトコル仕様書の該当箇所を根拠として参照しつつ、実装観点で整理された説明、注意点、確認手順、レビュー観点を提示できる必要がある。

---

## 2. 用語と表現方針

### 2.1 使わない表現

以後、パッケージ本体（README、RAG、Skill、プロンプト、公開向け説明）では、教育・入門を強調する表現は使わない。


### 2.2 使用する表現

以下の表現に統一する。

- 実装者向け
- 実装観点
- 仕様参照補助
- プロトコル読解補助
- 実装前提
- 実機確認観点
- レビュー観点
- RFID制御アプリ実装者

### 2.3 正本資料の扱い

通信プロトコル仕様書は、タカヤ株式会社の著作物であり、公開済みの正本資料として扱う。

本パッケージは、その正本資料を生成AIが参照しやすくするための補助資料である。

権利上の過剰な遠慮は不要だが、以下の混同は避ける。

- 通信プロトコル仕様書そのもの
- PDF由来の補助Markdown
- 構造化データ
- サンプルコード
- Skill
- プロンプト
- GitHubリポジトリのコードライセンス

コードライセンスと、仕様書・マニュアル類の著作権表示は分けて扱う。

---

## 3. 現状の主要課題

### 3.1 中井さん指摘からの課題

中井さんの指摘は、v004以降でも上位要件として残す。

#### NAKAI-01: 構造化不足

周波数設定のような、bit単位・チャンネル・周波数・許可/禁止の2次元対応関係を、Markdownコードブロック内のPDF抽出テキストとして置いただけでは、AI-readyとは言えない。

必要な対応:

- 表、bit定義、周波数、許可/禁止、機種差分、ROM差分は構造化データとして保持する。
- Markdown本文は説明用とし、AIの機械判定には構造化データを使う。
- 構造化未完了の項目は `not_structured` または `requires_pdf_cross_check` と明示する。

#### NAKAI-02: RAG設計不足

RAG登録向けMarkdownと呼ぶには、チャンク粒度、メタデータ、検索語、埋め込み方針が不足していた。

必要な対応:

- RAGチャンク設計ポリシーを定義する。
- 1チャンクの責務を限定する。
- 広すぎるキーワードのみを禁止する。
- `UTR`、`RFID`、`protocol` だけのような弁別力の低い検索語を避ける。
- `rag_chunk_index` を正規インデックスとして管理する。

#### NAKAI-03: プロンプトの環境固定

Git、VS Code、requirements.txt、特定リポジトリ前提の記述は、汎用プロンプトに混ぜない。

必要な対応:

- portable prompt
- environment profile prompt
- codex repository prompt

を分離する。

#### NAKAI-04: ライセンス・権利範囲の明確化

PDF、PDF由来資料、コード、Skill、プロンプトの権利範囲とライセンス境界を明確にする。

必要な対応:

- PDF正本の著作権表示
- コードライセンスとの境界
- PDF同梱版 / no-PDF版の扱い
- GitHubリポジトリ内にPDFを置く場合のREADME表現

を整理する。

#### NAKAI-05: ドキュメント重複

`intended_users`、`usage_scope`、`sdk_note` などに重複していた説明を整理する。

必要な対応:

- `docs/audience_and_scope.md`
- `docs/sdk_positioning.md`
- `docs/source_of_truth_summary.md`
- `docs/distribution_notes.md`

へ役割分担する。

---

### 3.2 Gemini指摘からの課題

Geminiの指摘は、ルール追加ではなく、AIの応答手順制御が必要という点に集約される。

#### GEMINI-01: 応答モード制御が必要

AIに「禁止事項」を大量に読ませるだけでは不十分である。  
AIがどの状態で何を回答できるかを、応答モードとして定義する必要がある。

必要な対応:

- 仕様説明モード
- 仕様参照モード
- 読み取り系実装計画モード
- コード生成モード
- 高リスク確認モード
- 固定警告テンプレートモード

を定義する。

#### GEMINI-02: デッドロックを避ける

対象機器情報が未固定でも、概要説明や仕様参照補助は可能にする。  
ただし、実装コード生成や機種依存処理は停止する。

必要な対応:

- 「説明は可、実装は不可」の境界をモードで定義する。
- 機器情報未固定時に全回答を止めない。
- 実装段階に入るときにだけ対象機器情報を要求する。

#### GEMINI-03: セーフティ出力テンプレート

高リスク操作では、AIの自由回答を避け、固定されたセーフティ出力テンプレートに落とす。

必要な対応:

- `high_risk_warning_template`
- `absolute_refusal_template`
- `checksum_placeholder_template`

を定義する。

#### GEMINI-04: SUMと完成Hexのプレースホルダー化

AIはSUM値や完成Hexを実機送信用として断定しない。

必要な対応:

- `[MUST_RECALCULATE_SUM]`
- `[VERIFY_WITH_SPEC]`
- `[CONFIRM_TARGET_DEVICE]`

などのプレースホルダーを定義する。

---

### 3.3 Claude指摘からの課題

Claudeの指摘は、主に整合性と検証品質である。

#### CLAUDE-01: VALIDATION.md が古い

`VALIDATION.md` が旧工程の内容のまま残ると、AIやレビュアーが現状を誤認する。

必要な対応:

- `VALIDATION.md` は常に最新工程の結果で上書きする。
- 古い検証結果を残す場合は `archive/validation_history/` に移す。
- 最新検証結果は1つの正規ファイルに集約する。

#### CLAUDE-02: risk_level の二重定義

大ファイルと `rag/commands/` で `risk_level` が異なると、RAGヒット順によりAIの判断が変わる。

必要な対応:

- `command_safety_matrix.yml` を正規データにする。
- 各RAGチャンクは `safety_profile_ref` でマトリクスを参照する。
- `risk_level` の手書き重複を減らす。

#### CLAUDE-03: rag_chunk_index の未同期

新規チャンクを追加しても `rag_chunk_index` に登録されていないと、検索基盤が拾えない。

必要な対応:

- 全RAGファイルを `rag_chunk_index.yml` に登録する。
- 未登録ファイルがある場合は検証エラーにする。

#### CLAUDE-04: 大ファイルとRAG入口の不整合

旧大ファイルを残す場合、RAG入口との安全メタデータ不整合を許容しない。

必要な対応:

- 大ファイルは `legacy_pdf_extract` または `source_extract` と明示する。
- 実装判断には `rag/commands/` と `command_safety_matrix.yml` を優先する。
- 大ファイルは検索優先度を下げるか、検索対象外にする。

---

## 4. 基本設計原則

### PRINCIPLE-01: PDF正本と補助資料の関係

PDF正本は最終根拠である。  
補助資料は、PDF正本を実装者が参照しやすくするためのナレッジであり、PDF正本の代替ではない。

ただし、AIは「PDFを読め」で終わってはならない。  
正本の該当箇所を根拠として、実装観点の説明、注意点、確認手順を提示する。

### PRINCIPLE-02: 構造化が必要な情報

以下はMarkdown本文だけで管理しない。

- bit定義
- 周波数チャンネル
- 許可/禁止
- コマンドフレーム
- レスポンスフレーム
- ROMバージョン差分
- 機種差分
- アンテナ構成差分
- RAM/FLASH挙動
- リスク判定
- 応答モード制御

### PRINCIPLE-03: 安全判定の正規データ化

コマンド安全判定は、`command_safety_matrix.yml` を正規データとする。

RAGチャンク、Skill、プロンプトは、このマトリクスを参照する。

### PRINCIPLE-04: 応答モード制御

AIはユーザー要求を直接実行するのではなく、まず応答モードを判定する。

### PRINCIPLE-05: 根拠追跡

各コマンド、各安全ポリシー、各実装例は、正本資料の参照位置と対応づける。

### PRINCIPLE-06: no-PDF版とfull-source版の分離

権利上の制約ではなく、用途上の理由により、次の2種類を分ける。

- full-source版: PDF正本をRAG登録対象に含める社内・検証用途
- no-PDF版: PDF正本を同梱せず、source index と traceability を含める軽量版

---

## 5. AI応答モード要件

### 5.1 応答モード一覧

| mode | 用途 | コード生成 | 完成Hex | 対象機器固定 |
|---|---|---:|---:|---:|
| `overview_explanation` | 仕様概要説明 | 不可 | 不可 | 不要 |
| `protocol_reference_explanation` | 正本内容の実装観点説明 | 不可 | 不可 | 原則不要 |
| `implementation_planning` | 実装方針整理 | 擬似コードまで | 不可 | 必要 |
| `read_only_code_generation` | 読み取り系サンプル生成 | 条件付き可 | 不可 | 必要 |
| `code_review` | 既存コードレビュー | 条件付き可 | 不可 | 必要 |
| `high_risk_review` | 高リスク仕様説明・確認 | 不可 | 不可 | 必要 |
| `absolute_refusal_or_fixed_warning` | Kill等の破壊的操作 | 不可 | 不可 | 必要 |

### 5.2 対象機器未固定時の扱い

対象機器が未固定でも、以下は可能とする。

- 仕様概要の説明
- 用語説明
- 正本の参照箇所の案内
- 実装前に確認すべき項目の整理
- 安全上の注意点の説明

対象機器が未固定の場合、以下は禁止する。

- 実装コード生成
- コマンドフレーム生成
- 完成Hex生成
- ROM依存挙動の断定
- 機種依存処理の断定
- 高リスク操作の実装支援

---

## 6. Source Traceability 要件

### 6.1 source_traceability_matrix.yml

次工程以降、以下を作成する。

```text
03_structured_data/source_traceability_matrix.yml
```

各項目には最低限以下を持たせる。

```yaml
item_id: UHF_Inventory
item_type: command
implementation_summary: "RFタグを探索し、読み取り結果を取得する基本的な読み取りコマンド"
source_pdf:
  document_title: "UTR-S201シリーズ通信プロトコル仕様書"
  manual_no: "要PDF照合"
  pdf_version: "要PDF照合"
  section: "UHF_Inventory"
  page_start: "要PDF照合"
  page_end: "要PDF照合"
source_status: not_cross_checked
derived_files:
  command_reference: "rag/commands/55_10_uhf_inventory.md"
  safety_reference:
    - "rag/safety/q_value_collision_policy.md"
  structured_data:
    - "03_structured_data/command_safety_matrix.yml#UHF_Inventory"
implementation_notes:
  - "レスポンス解析ではタグデータレスポンスとACK/NACKを分ける"
review_notes:
  - "コマンドコード、データ部、SUM計算、NACK処理を確認する"
```

### 6.2 source_status

`source_status` は以下のいずれかとする。

- `pdf_cross_checked`
- `not_cross_checked`
- `requires_pdf_confirmation`
- `structure_extracted_not_verified`
- `legacy_extract_only`

---

## 7. コードアノテーション要件

サンプルコードや生成コードには、必要に応じて以下のコメントブロックを付与できる設計にする。

```python
# @AI_SOURCE:
#   document: UTR-S201シリーズ通信プロトコル仕様書
#   section: UHF_Inventory
#   page: 要PDF照合
#   status: not_cross_checked
#
# @AI_SCOPE:
#   product_family: UTR
#   model_name: 要指定
#   rom_series: 要指定
#   rom_version: 要指定
#   interface: USB
#   operation_type: read_only
#
# @AI_RISK:
#   risk_level: low
#   executable_hex_output: prohibited
#
# @AI_REVIEW:
#   reviewer_should_check:
#     - コマンドコード
#     - データ部
#     - ACK/NACK解析
#     - SUM計算
#     - 機種/ROMバージョン差分
```

コードアノテーションは、仕様根拠・対象範囲・レビュー観点を残すためのものであり、コードを仕様正本として扱うためのものではない。

---

## 8. RAG要件

### 8.1 RAGチャンクの種類

| chunk_type | 役割 |
|---|---|
| `command_reference` | コマンド別仕様入口 |
| `concept_reference` | 実装前提・用語・処理概念 |
| `safety_policy` | 高リスク操作・禁止事項 |
| `workflow` | 実装・確認手順 |
| `source_traceability` | 正本参照関係 |
| `structured_matrix` | AIが機械判定に使う構造化データ |

### 8.2 RAGチャンク必須メタデータ

```yaml
chunk_id: ""
chunk_type: ""
target_models: []
operation_type: ""
safety_profile_ref: ""
source_pdf:
  document_title: ""
  manual_no: ""
  pdf_version: ""
  section: ""
  page_start: ""
  page_end: ""
source_status: ""
response_modes_allowed: []
keywords_specific: []
search_boost_terms: []
rag_priority: ""
```

### 8.3 禁止するRAG設計

- PDF抽出テキストをそのままコードブロックで置いただけの「構造化済み」扱い
- `UTR`、`RFID` など広すぎるキーワードのみ
- 大ファイルと薄いRAG入口で異なる安全判定
- `rag_chunk_index` 未登録のRAGファイル
- `VALIDATION.md` と実ファイル数の不整合

---

## 9. プロンプト設計要件

プロンプトは以下に分ける。

```text
prompts/portable/
prompts/environment_profiles/
prompts/codex_repo/
```

### portable

- GitHub前提なし
- VS Code前提なし
- requirements.txt前提なし
- 特定リポジトリ前提なし
- 仕様確認、説明、レビュー観点整理に使う

### environment_profiles

- Python USB
- Python LAN
- generic serial
- 実装環境別の前提を持つ

### codex_repo

- GitHubリポジトリ修正用
- 作業ブランチ
- git diff
- pytest
- PR説明
- 実機確認分離

を明示する。

---

## 10. ドキュメント整理要件

重複を避けるため、以下のように役割分担する。

| ファイル | 役割 |
|---|---|
| `docs/audience_and_scope.md` | 対象者・用途・前提 |
| `docs/sdk_positioning.md` | SDKとの関係 |
| `docs/source_of_truth_summary.md` | PDF正本と補助資料の関係 |
| `docs/distribution_notes.md` | 配布形態・full-source/no-PDF |
| `docs/code_annotation_guide.md` | コード内根拠コメントの書き方 |

READMEは詳細説明を重複して書かず、上記への導線にする。

---

## 11. ライセンス・権利境界要件

通信プロトコル仕様書はタカヤ株式会社の著作物・公開済み正本資料として扱う。

本パッケージでは以下を明記する。

- PDF正本の著作権表示
- 補助Markdownの位置づけ
- 構造化データの位置づけ
- サンプルコードのライセンス範囲
- GitHubリポジトリ上のコードライセンスとPDF文書の権利範囲の分離

「PDFを含めてMITで自由改変可」に見える表現は避ける。

---

## 12. 検証要件

次工程以降、VALIDATIONでは最低限以下を確認する。

- PDF同梱の有無
- nested zip内PDFの有無
- full-source版 / no-PDF版の区分
- 総ファイル数
- `MANIFEST.md` との整合
- `VALIDATION.md` 自身の工程名
- RAGファイル数
- `rag_chunk_index` 登録漏れ
- `command_safety_matrix` とRAG front matterの整合
- `source_traceability_matrix` 登録漏れ
- `risk_level` 不整合
- `response_mode` 未定義値
- `source_status` 未定義値
- Skill同期状態
- プロンプト分類状態

---

## 13. 次工程で作成する中心ファイル

R2以降で、以下を作成または再編する。

```text
00_policy/ai_response_modes.yml
00_policy/high_risk_response_templates.yml
00_policy/rag_design_policy.yml

03_structured_data/command_safety_matrix.yml
03_structured_data/response_mode_transition.yml
03_structured_data/source_traceability_matrix.yml
03_structured_data/rag_chunk_schema.yml
03_structured_data/rag_keyword_taxonomy.yml
03_structured_data/rag_chunk_index.yml
03_structured_data/code_annotation_schema.yml

rules/00_response_mode_control.md
rules/01_command_safety_matrix_usage.md
rules/12_rag_chunking_and_embedding_policy.md
rules/13_source_traceability_policy.md
rules/14_code_source_annotation_policy.md

docs/audience_and_scope.md
docs/sdk_positioning.md
docs/source_of_truth_summary.md
docs/distribution_notes.md
docs/code_annotation_guide.md
```

---

## 14. R1完了条件

本R1工程は、以下を満たせば完了とする。

- 中井さん指摘が要件化されている
- Gemini指摘が要件化されている
- Claude指摘が要件化されている
- 教育・入門を強調する表現を使わない方針が明記されている
- 通信プロトコル仕様書を公開済み正本資料として扱う方針が明記されている
- PDFを根拠としつつ「PDFを読め」で終わらない方針が明記されている
- 応答モード制御の必要性が明記されている
- Source Traceability の必要性が明記されている
- コードアノテーション方針が明記されている
- 次工程で作る中心ファイルが明記されている

---

## 15. R2への引き継ぎ

R2では、まず以下を作成する。

```text
00_policy/ai_response_modes.yml
00_policy/high_risk_response_templates.yml
03_structured_data/response_mode_transition.yml
rules/00_response_mode_control.md
```

R2の目的は、AIの回答を禁止文の羅列ではなく、モードと状態遷移で制御することである。

