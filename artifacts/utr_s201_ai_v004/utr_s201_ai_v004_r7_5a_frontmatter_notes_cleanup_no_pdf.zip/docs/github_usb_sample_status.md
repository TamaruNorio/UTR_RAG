---
title: "GitHub USB版サンプル 最新状態"
project: "UTR-S201 AI補助パッケージ"
phase: "G"
status: "draft"
source_type: "verified_github_sample"
source_priority_rank: 3
repo: "TamaruNorio/UTR_USB_Python_CodeX"
branch: "main"
last_reflected_pr: 72
pdf_role: "PDF正本が最終根拠"
github_role: "実装例・実機確認済み運用例"
---

# GitHub USB版サンプル 最新状態

## 目的

このファイルは、GitHub リポジトリ `TamaruNorio/UTR_USB_Python_CodeX` の USB版サンプルについて、AIパッケージ側で参照するための状態メモです。

GitHub実装は **仕様の正本ではありません**。
仕様の最終根拠は、タカヤ株式会社発行の UTR-S201シリーズ通信プロトコル説明書PDFです。

ただし、GitHub実装は以下の用途で有用です。

- Python実装例の確認
- 実機確認済みフローの確認
- Codexに修正依頼する際の作業前提
- テスト観点、ログ保存、例外時復元処理の確認

## 反映時点

| 項目 | 内容 |
|---|---|
| リポジトリ | `TamaruNorio/UTR_USB_Python_CodeX` |
| ブランチ | `main` |
| 反映工程 | G工程 |
| 反映対象 | PR #68〜#72 までのマージ済み内容 |
| 最新確認した主なPR | #72 `Record output power restore verification` |
| PDF同梱 | なし |

## mainブランチで確認した主な実行入口

| 実行入口 | 用途 | 実機影響 |
|---|---|---|
| `src/utr_usb_sample.py` | 標準Inventoryフロー | USB接続、ROM確認、コマンドモード、Inventory、必要に応じて送信出力一時変更 |
| `src/utr_8ch_sequential_inventory_cli.py` | UTR-SUN02-8CH / USM08向け複数アンテナ順次Inventory確認 | 使用アンテナ番号をコマンドモード用パラメータへ一時設定し、終了時に開始前設定へ自動復元 |

## 標準Inventoryフローの現状

標準入口 `src/utr_usb_sample.py` は、内部的に `src/utr_usb_inventory_with_output_power.py` の統合フローを起動します。

主な流れは以下です。

1. USBシリアル接続する。
2. ROMバージョンを読み取り、仕様書上の機種を確認する。
3. コマンドモードへ切り替える。
4. 現在の送信出力設定を読み取る。
5. UTR-SUN02-4CH / USM02 の場合、Inventory中だけ送信出力を一時変更するか確認する。
6. 変更する場合は、コマンドモード用パラメータだけを書き換える。
7. Inventory前の送信出力設定、周波数設定、Inventoryパラメータを表示する。
8. 必要に応じて、UTR-SUN02-4CH のアンテナ接続確認とANT別順次Inventoryを実行する。
9. Inventoryを実行する。
10. 終了時に送信出力を元の値へ復元する。
11. 復元後に送信出力設定を読み戻す。
12. アンテナ設定を変更した場合は、元のコマンドモード用アンテナ設定へ復元する。
13. 結果ファイルを保存し、シリアル接続を閉じる。

## 8CH順次Inventory CLIの現状

対象は **UTR-SUN02-8CH / USM08** です。

主な流れは以下です。

1. USBシリアル接続する。
2. ROMバージョンを読み取り、UTR-SUN02-8CH / USM08 であることを確認する。
3. コマンドモードへ切り替える。
4. Inventory前のリーダライタ設定を読み取り表示する。
5. `UHF_GET_INVENTORY_PARAM` を読み取り表示する。
6. 変更前の使用アンテナ番号を読み取り、終了時復元用に保持する。
7. 変更前設定を読み取れない場合は、順次Inventoryを開始しない。
8. ANT1〜ANT8の接続チェックを実行する。
9. 接続OKアンテナだけを候補表示する。
10. `1`、`1,3`、`all`、`q` の入力を受け付ける。
11. 選択した全ANTの使用アンテナ番号設定フレームを事前表示する。
12. 最初に1回だけ確認し、選択順に使用アンテナ番号設定を送信する。
13. ACKならそのANTでInventoryする。
14. NACKまたはACK/NACKなしなら、そのANTをスキップする。
15. ANT別に読み取り枚数、Inventory実行回数、スキップ回数を表示する。
16. 終了時に、開始前に読み取った使用アンテナ番号へ自動復元する。
17. Ctrl+Cや例外時も、可能な範囲でシリアルクローズ前に自動復元を試みる。
18. 復元前には、割り込み前のInventory応答が残らないよう受信バッファをクリアする。
19. 復元応答としてACK/NACK以外を受信した場合は、残留応答の可能性を考慮して1回だけ再試行する。
20. 必要に応じて、8CH順次InventoryサマリをCSV/JSONへ保存する。
21. シリアル接続を閉じる。

## 安全上の扱い

GitHub実装では、以下を行わない前提になっています。

- FLASHデータへの書き込み
- 周波数変更
- `UHF_SET_INVENTORY_PARAM` の自動送信
- 8CH設定の永続保存
- 実タグIDをGitHub、Issue、PR本文、公開ログへ掲載すること

ただし、以下は実機へ送信される可能性があります。

- 標準Inventoryフローでのコマンドモード用送信出力一時変更
- UTR-SUN02-4CHのアンテナ設定一時変更
- UTR-SUN02-8CH / USM08の使用アンテナ番号設定フレーム送信
- Inventoryコマンド
- ブザー制御コマンド

そのため、生成AIがこのGitHub実装を参照する場合でも、実機送信処理を生成・変更する前には、対象機種、ROMシリーズ、インターフェース、アンテナ構成を明確化してください。

## AIパッケージ側での扱い

AIパッケージ内では、GitHub USB版を以下のように扱います。

| 扱い | 方針 |
|---|---|
| 仕様正本 | しない |
| 実装例 | する |
| 実機確認済み挙動 | 参考にする |
| PDFとの矛盾時 | PDFを優先し、GitHub側を要確認とする |
| 他機種への横展開 | 禁止。対象機種・ROMシリーズを確認してから判断する |

