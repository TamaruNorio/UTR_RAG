# CHANGELOG v004 draft

## B step

- Removed PDF binaries from distribution draft.
- Added `00_policy/` with source-of-truth, license, distribution, third-party, and safety policy files.
- Added initial structured-data area for safety and RAG metadata.

## C step

- Optimized representative RAG command files:
  - `55_10_UHF_Inventory.md`
  - `55_41_UHF_GetInventoryParam.md`
  - `55_31_UHF_SetInventoryParam.md`
- Added structured bitfield and RAG metadata samples.
- Raised `UHF_SetInventoryParam` risk treatment to high.

## D step

- Rebuilt ChatGPT Skill package as `skill/skill.zip`.
- Added source-of-truth and safety-gate rules directly to `SKILL.md`.
- Added policy references and structured safety data into the Skill bundle.
- Replaced the Skill's representative RAG command files with the C-step optimized versions.
- Added `skill/SKILL_v004_D.md` as the unpacked D-step Skill entrypoint for review.

## E工程: プロンプト再設計

- `prompts/` をv004方針に合わせて再設計
- 旧プロンプトを `prompts/legacy_v003/` に退避
- PDF正本を最終根拠とし、Markdownを補助資料として扱う記述へ修正
- 調査のみ、USB読み取り専用、LAN読み取り専用、Codex調査、Codex実装、レビュー、高リスク操作確認に分割
- 初期実機確認用プロンプトでは、FLASH書き込み、送信出力変更、周波数変更、`UHF_SetInventoryParam` 自動送信、Kill、Lock、ThroughCmdを禁止

## F工程: 対象機種・ROMシリーズ・アンテナ構成スコープ固定

- UTR-S201とUTR-S202を同一仕様と仮定しないルールを追加しました。
- 対象機種、ROMシリーズ名、インターフェース、アンテナ構成が未確定の場合、機種依存コマンドを生成しない方針を追加しました。
- 4CH/8CH/単アンテナ/外部ユニット8CHのアンテナ構成差分を構造化しました。
- GitHub実装例は参考、PDF正本を最終根拠とする優先順位を再明記しました。

## G工程 - GitHub USB版最新状態の反映

- GitHub USB版 `TamaruNorio/UTR_USB_Python_CodeX` のマージ済みPR #68〜#72 をAI補助資料へ反映。
- GitHub実装を「仕様正本」ではなく「実装例・実機確認済み挙動」として位置づけ。
- 標準Inventory入口、8CH順次Inventory入口、送信出力復元強化、8CH自動復元、残留応答対策を整理。
- `docs/github_usb_sample_status.md`、`docs/usb_sample_verified_behaviors.md`、`docs/usb_sample_known_limitations.md` を追加。
- `03_structured_data/github_usb_repo_status.yml/csv` を追加。
- `rag/github/usb_sample_latest_status.md` を追加。
- Codex向けプロンプト `09` と `10` を追加。



## I工程: v004リリース候補化 (2026-06-27 11:45:35 JST)

- H工程までの成果物を `v004 release candidate no-PDF` として再パッケージ。
- `RELEASE_REPORT_v004_rc.md` を追加。
- `README.md` をリリース候補向けに更新。
- `PACKAGE_TREE.txt` と `CHECKSUMS_SHA256.txt` を再生成。
- PDF同梱なし、必須ファイル、RAG front matter、安全キーワードを検証。


## 2026-06-27 I補正工程

- Claudeレビュー指摘を受け、旧大ファイルRAG側の高リスク操作メタデータを補正。
- `55_33_01`、`55_33_02` を `critical` に統一。
- `55_38` を `high` に統一し、機種スコープと復元計画を必須化。
- `55_18_UHF_Lock`、`55_FF_UHF_ThroughCmd` を `critical` に昇格。
- `9.1_FLASHアドレス一覧.md` を `high` に変更。
- `rag/safety/` 全ポリシーへ `target_models` / `operation_type` を追加。
- Skill Safety Gate と Codex小規模実装プロンプトを強化。
- Gemini向けにZIP非対応を想定したレビューBundle Markdownを作成。

## v004 i3 pre-RC correction

- Geminiレビューを受け、release candidate 表記を pre-RC / beta 相当に見直し。
- ROMバージョン更新ポリシーを追加。
- 未知ROM・将来ROMを上位互換と仮定しないルールを追加。
- セッション対象機器固定スキーマを追加。
- 機種型式・ハードウェア制約マトリクスを追加。
- 破壊的・不可逆コマンドの絶対拒絶ポリシーを追加。
- SUM計算・完成Hexフレーム出力ポリシーを追加。
- UHF_Read / UHF_Write とQ値・複数タグ環境の安全チャンクを追加。
- FLASH寿命、RAM/FLASH/パラメータ挙動ポリシーを追加。
