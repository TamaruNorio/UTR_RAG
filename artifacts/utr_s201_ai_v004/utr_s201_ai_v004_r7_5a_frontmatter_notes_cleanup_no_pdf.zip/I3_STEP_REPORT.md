# UTR-S201 AI補助パッケージ v004 I3補正工程レポート

## 目的

Geminiレビューで指摘されたROMバージョン差分、将来ROM、機種型式、ハードウェア制約、SUM計算、Q値、絶対拒絶コマンドを反映し、v004 i2をpre-RCとして補正しました。

## 位置づけ

この成果物は正式RCではありません。ROMバージョンごとの詳細仕様、機種型式ごとの内部挙動、PDF正本との全コマンド逐条照合が未完了のため、pre-RC / beta相当です。

## 主な修正

1. ROMバージョンを将来更新される前提で扱うポリシーを追加。
2. 未知ROM・将来ROMを上位互換と仮定しないルールを追加。
3. セッション対象機器固定スキーマを追加。
4. 機種型式・ハードウェア制約マトリクスを追加。
5. UHF_Kill / UHF_Lock / UHF_ThroughCmd / FLASH書き込み / FLASH初期化の絶対拒絶ポリシーを追加。
6. SUM計算・完成Hexフレーム出力ポリシーを追加。
7. UHF_Read / UHF_Write とQ値・複数タグ環境ポリシーを追加。
8. FLASH寿命・RAM/FLASH/パラメータ挙動ポリシーを追加。
9. Skill ZIPへI3方針を同期。
10. Gemini/Claude再レビュー用プロンプトを更新。

## 検証概要

```text
release_status="pre-RC / beta"
total_files=234
pdf_files=[]
nested_pdf_entries=[]
missing_required_files=[]
safety_frontmatter_errors=[]
command_rom_dependency_errors=[]
rag_command_chunks=13
rag_safety_chunks=14
skill_contains_i3_files=["rom_version_update_policy.yml", "absolute_refusal_commands.yml", "checksum_policy.yml", "rom_version_dependency_policy.md"]
license_status="unconfirmed"
pdf_full_cross_check="not_completed"
```

## 残課題

- PDF正本との全コマンド逐条照合
- ROMバージョンごとの対応コマンド・内部挙動の精査
- 機種型式ごとのハードウェア制約の精査
- Skill公式バリデータの実行
- 社外配布可否・ライセンス確認
