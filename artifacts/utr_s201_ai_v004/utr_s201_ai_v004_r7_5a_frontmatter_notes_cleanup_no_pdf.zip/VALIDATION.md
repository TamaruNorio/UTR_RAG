# VALIDATION — v004_r6_integrated_pre_rc

Validation date: 2026-06-29

## Status

- release_status: integrated pre-RC
- base_package: utr_s201_ai_v004_i3_pre_rc_no_pdf.zip
- integrated_design_stages: R1, R2, R3, R4, R5
- formal_RC: false

## Counts

- total_files: 278
- pdf_files_in_package: 0
- rag_command_chunks: 13
- rag_safety_chunks: 15
- rag_chunk_index_entries: 131

## Required files checked

- 00_policy/ai_response_modes.yml: yes
- 00_policy/high_risk_response_templates.yml: yes
- 03_structured_data/command_safety_matrix.yml: yes
- 03_structured_data/source_traceability_matrix.yml: yes
- 03_structured_data/structured_data_design_policy.yml: yes
- 03_structured_data/rag_chunk_index.yml: yes
- rules/00_response_mode_control.md: yes
- rules/01_command_safety_matrix_usage.md: yes
- rules/13_source_traceability_policy.md: yes
- rules/15_structured_data_policy.md: yes

## Important unresolved items

- UTR-S201/202 protocol PDF page-level cross-check is not complete.
- R7-1 confirmed against TDR-MNL-PRC-UTR-S201-117 Ver.1.17 that 55h/14h = UHF_InventoryRead and 55h/15h = UHF_Read.
- R7-2 removes the obsolete `rag/commands/55_14_uhf_read.md` RAG index reference and aligns traceability/safety matrices to the PDF-confirmed command identifiers.
- R7-4A partially reinforces command safety matrix entries found incomplete in R7-3 and clarifies that hazardous commands must not produce complete Hex, SUM-calculated commands, or send-ready commands.
- R7-4A is not a formal RC; full source_traceability_matrix updates remain deferred to R7-4B or later.
- R7-4B-RETRY fixes the previous R7-4B detail-command conversion errors and reflects major-command PDF sections/pages in `source_traceability_matrix.yml` using fixed command-code/detail-command values.
- R7-4B-RETRY is not a formal RC; real-device verification is not complete and RAG body/front matter synchronization remains deferred to R7-4C or later.
- R7-4D synchronizes RAG Markdown front matter and `rag_chunk_index.yml/csv` with R7-4A/R7-4B-RETRY source and safety references.
- R7-4D minimally fixes `source_status: true`, risk underestimation, and missing source/safety references confirmed in R7-4C.
- R7-4D adds no permission for complete Hex output, SUM-calculated commands, or send-ready device code; real-device verification remains incomplete and R7-4D is not a formal RC.
- R7-4F applies the minimal fixes for the R7-4E HOLD reasons: R7-4D-3 safety wording, high/critical RAG Markdown front matter source/safety references, and README/MANIFEST version-status wording.
- R7-4F remains no-PDF, is not a formal RC, and real-device verification is not complete.
- R7-4F ZIP creation and ZIP-content inspection completed for `utr_s201_ai_v004_r7_4f_pre_rc_prep_no_pdf.zip`.
- R7-4F ZIP inspection confirmed: no PDF files included, obsolete safety wording not present, `55h/14h = UHF_InventoryRead` maintained, `55h/15h = UHF_Read` maintained, and obsolete `rag/commands/55_14_uhf_read.md` not present.
- R7-4F ZIP inspection judgment: R7_4F_PASS_WITH_NOTES. Real-device verification is not complete and this package is not a formal RC.
- R7-5A performed on 2026-07-02 using input ZIP `utr_s201_ai_v004_r7_4f_pre_rc_prep_no_pdf.zip`.
- R7-5A targeted the 18 high/critical RAG helper Markdown front matter items left as R7-5 notes. Source/status, source traceability, safety profile, and PDF cross-check ambiguity were resolved with either direct matrix references or explicit policy/matrix notes.
- R7-5A used policy_reference / matrix_reference handling for 18 items and did not force single-command references where the document is a cross-command safety policy or the source trace item is not registered as a single R7-5A trace item.
- R7-5A result: source_status ambiguity addressed, source_traceability_ref ambiguity addressed, safety_profile_ref ambiguity addressed, pdf_cross_checked ambiguity addressed, risk levels not relaxed, no command_safety_matrix conflict found.
- R7-5A confirmed `55h/14h = UHF_InventoryRead`, `55h/15h = UHF_Read`, no obsolete `rag/commands/55_14_uhf_read.md`, no PDF inclusion, real-device verification not complete, and not a formal RC. Judgment: R7_5A_PASS_WITH_NOTES.
- Real-device verification is not complete.
- Values in frequency/channel, bitfield, ROM behavior, hardware capability, parameter persistence, and Q-value matrices marked `requires_pdf_cross_check` must not be inferred by AI.

## Claude/Gemini review-response status

- Response-mode control added to avoid rule-sprawl and deadlock.
- Central command safety matrix added to avoid repeated risk-level drift.
- Source traceability matrix and code annotation schema added.
- Structured data scaffolds added for table/bit/channel data.
- VALIDATION.md updated from obsolete i3/G-draft information.

## Packaging note

This integrated ZIP remains no-PDF. It is ready for another Gemini/Claude review pass, not for final external release.
