# R8-2 Release Decision Table

この表は、R7-5A成果物を社内pre-RCまたはRC候補として判断するための確認表です。

判定は `PASS`、`HOLD`、`TODO`、`N/A` のいずれかで記録します。実機確認が必要な項目は初期状態では `TODO` とします。

| No | 確認項目 | 判定 | 必須度 | 確認方法 | 結果 | 備考 |
|---:|---|---|---|---|---|---|
| 1 | GitHub mainに成果物ZIPが存在する | PASS | 必須 | GitHub mainの成果物パス確認 | main登録済み | `artifacts/utr_s201_ai_v004/utr_s201_ai_v004_r7_5a_frontmatter_notes_cleanup_no_pdf.zip` |
| 2 | ZIP SHA256が一致する | PASS | 必須 | `Get-FileHash` またはGitHub記載値確認 | 一致 | `2103B818045608383FD94F0047B471D4B2E3A3610BC8E46EAA644DF29F738521` |
| 3 | README.mdから成果物とR8-1チェックリストを参照できる | PASS | 必須 | README.md確認 | 参照あり | R8-2/R8-3参照は本変更で追加 |
| 4 | docs/OPERATIONS.mdが存在する | PASS | 必須 | ファイル存在確認 | 存在 | 運用ルールあり |
| 5 | R8-1チェックリストが存在する | PASS | 必須 | ファイル存在確認 | 存在 | `docs/R8-1_PRE_RC_INTERNAL_SHARE_CHECKLIST.md` |
| 6 | PDFがGitHubに含まれていない | PASS | 必須 | 追加差分確認 | 追加なし | R8-2ではPDFを追加しない |
| 7 | 完成Hexが生成されていない | PASS | 必須 | 追加差分確認 | 生成なし | 生成禁止 |
| 8 | SUM計算済みコマンドが生成されていない | PASS | 必須 | 追加差分確認 | 生成なし | 生成禁止 |
| 9 | 実機送信用コードが生成されていない | PASS | 必須 | 追加差分確認 | 生成なし | 生成禁止 |
| 10 | 55h/14h = UHF_InventoryRead が維持されている | PASS | 必須 | 既存資料の対応関係確認 | 維持 | 本変更ではRAG本文を修正しない |
| 11 | 55h/15h = UHF_Read が維持されている | PASS | 必須 | 既存資料の対応関係確認 | 維持 | 本変更ではRAG本文を修正しない |
| 12 | rag/commands/55_14_uhf_read.md が存在しない | PASS | 必須 | ファイル存在確認 | 存在しない前提 | 誤命名防止 |
| 13 | 実機接続確認が完了している | PASS | 必須 | R8-3実機確認 | COM6 / 115200bpsでopen成功 | 送信なし、DTR/RTS無効 |
| 14 | 実機切断確認が完了している | PASS | 必須 | R8-3実機確認 | close成功、再接続後の再close成功 | 送信なし |
| 15 | 読み取り系確認が完了している | PASS | 必須 | R8-8A実機確認 | Inventoryに伴うタグ読み取り応答を確認 | `UHF_Read` 単体確認は未実施のためHOLD事項として継続 |
| 16 | Inventory系確認が完了している | PASS | 必須 | R8-8A実機確認 | Inventory 1回実行、タグ応答1件 | タグ固有IDは記録しない |
| 17 | タイムアウト時の挙動が確認されている | PASS | 必須 | R8-3C実機確認 | 送信なしの1秒ReadTimeoutを再確認 | タグ読み取りコマンドは送信していない |
| 18 | エラー時のログ確認ができる | PASS | 必須 | R8-3C実機確認 | open/close/reopen/timeoutログを結果本文に記録 | 外部ログファイルは保存していない |
| 19 | FLASH書き込みを行っていない | PASS | 必須 | 実施手順と差分確認 | 実施なし | 実施可能な手順として書かない |
| 20 | 周波数変更を行っていない | PASS | 必須 | 実施手順と差分確認 | 実施なし | 実施可能な手順として書かない |
| 21 | 送信出力変更を行っていない | PASS | 必須 | 実施手順と差分確認 | 実施なし | 実施可能な手順として書かない |
| 22 | UHF_SetInventoryParam自動送信を行っていない | PASS | 必須 | 実施手順と差分確認 | 実施なし | 自動送信しない |
| 23 | 8CHアンテナ自動切替を行っていない | PASS | 必須 | 実施手順と差分確認 | 実施なし | 実施可能な手順として書かない |
| 24 | 実機確認結果が記録されている | PASS | 必須 | R8-8A記録フォーマット確認 | 記録済み | `docs/real_device/results/R8-8A_REAL_DEVICE_COMMAND_SEND_CHECK_RESULT.md` にPASS_WITH_NOTES結果を記録 |
| 25 | ステータス取得系確認が完了している | PASS | 必須 | R8-8A実機確認 | ROM、送信出力、周波数チャンネル、Inventory Paramを取得 | 設定変更なし |
| 26 | 社内pre-RCリリース判断 | PASS | 必須 | R8-4レビュー | 共有可 | HOLD事項付きで社内pre-RCとして共有可能 |
| 27 | 正式RC判断 | HOLD | 必須 | R8-8A実機確認 | 不可 | `UHF_Read` 単体確認、アンテナ物理構成、実施場所、全コマンド網羅確認が未完了 |
| 28 | RC候補判断 | HOLD | 必須 | R8-8A実機確認 | HOLD | `UHF_Read` 単体確認、アンテナ物理構成、実施場所が未確認 |
| 29 | 全コマンド棚卸しが実施されている | PASS | 必須 | R8-7レビュー | 実施済み | command_safety_matrix基準で38件を抽出 |
| 30 | コマンド安全分類の不足が一覧化されている | PASS | 必須 | R8-7レビュー | 一覧化済み | safety matrix上は不足0、実行候補化はしない |
| 31 | コマンド根拠参照の不足が一覧化されている | PASS | 必須 | R8-7レビュー | 一覧化済み | traceability不足5件 |
| 32 | 全コマンド網羅確認は未完了またはHOLDである | HOLD | 必須 | R8-7レビュー | HOLD | PDF原本照合と不足補完が未完了 |
| 33 | 実機へのコマンド送信確認が完了している | PASS | 必須 | R8-8A実機確認 | 既存サンプルでステータス取得とInventoryを実施 | `UHF_Read` 単体確認は未実施のためHOLD事項として継続 |
| 34 | v005 full-command no-PDF package が作成されている | PASS | 必須 | R8-9成果物確認 | 作成済み | `artifacts/utr_s201_ai_v005/utr_s201_ai_v005_full_command_internal_release_no_pdf.zip` |
| 35 | v005 MANIFEST が作成されている | PASS | 必須 | R8-9成果物確認 | 作成済み | `artifacts/utr_s201_ai_v005/MANIFEST.md` |
| 36 | v005 SHA256 が記録されている | TODO | 必須 | R8-9成果物確認 | ZIP作成後に記録 | MANIFESTに記録する |
| 37 | UHF_Read standalone は HOLD | HOLD | 必須 | R8-8A実機確認 | 未実施 | 既存入口に含まれないため単体確認は未実施 |
| 38 | リリース判断者が確認している | TODO | 必須 | 判断者レビュー | 未実施 | R8-10以降で判断 |
